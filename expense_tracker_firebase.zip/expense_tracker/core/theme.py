"""
core/theme.py  (Sprint 4 — Live Theme + Currency)
──────────────────────────────────────────────────
Design tokens now delegate to AppState for live colour switching.

P.bg_primary   → AppState.bg_primary   (updates when theme changes)
TY, SP, R      → unchanged (fonts, spacing, radii)

To retheme: call AppState.set_theme("light") or AppState.set_theme("dark")
To change currency: call AppState.set_currency("$")
"""

from dataclasses import dataclass, field
from core.app_state import AppState

# ── Palette proxy — reads live from AppState ──────────────────────────────────
class _PaletteProxy:
    """
    Forwards attribute access to AppState.colors so every
    reference to P.bg_primary always gets the current theme value.
    """
    def __getattr__(self, name: str) -> str:
        colors = object.__getattribute__(AppState, "colors")
        if name in colors:
            return colors[name]
        raise AttributeError(f"Palette has no colour '{name}'")

    def __repr__(self):
        return f"<PaletteProxy theme={AppState.theme}>"


# ── Typography ────────────────────────────────────────────────────────────────
@dataclass(frozen=True)
class Typography:
    family:        str = "Segoe UI"
    family_mono:   str = "Consolas"
    family_alt:    str = "Helvetica Neue"

    size_xs:   int = 9
    size_sm:   int = 10
    size_base: int = 11
    size_md:   int = 13
    size_lg:   int = 16
    size_xl:   int = 22
    size_xxl:  int = 32

    weight_normal: str = "normal"
    weight_bold:   str = "bold"

    def h1(self):    return (self.family, self.size_xxl, self.weight_bold)
    def h2(self):    return (self.family, self.size_xl,  self.weight_bold)
    def h3(self):    return (self.family, self.size_lg,  self.weight_bold)
    def body(self):  return (self.family, self.size_base)
    def label(self): return (self.family, self.size_sm)
    def caption(self): return (self.family, self.size_xs)
    def mono(self):  return (self.family_mono, self.size_base)


# ── Spacing ───────────────────────────────────────────────────────────────────
@dataclass(frozen=True)
class Spacing:
    xs:  int = 4
    sm:  int = 8
    md:  int = 14
    lg:  int = 20
    xl:  int = 28
    xxl: int = 40


# ── Radii ─────────────────────────────────────────────────────────────────────
@dataclass(frozen=True)
class Radii:
    sm:  int = 4
    md:  int = 8
    lg:  int = 12
    xl:  int = 16


# ── Constants ─────────────────────────────────────────────────────────────────
PAYMENT_METHODS = ["UPI", "Cash", "Card", "Net Banking", "Wallet", "Cheque"]
GROUP_TYPES     = ["Needs", "Wants", "Savings/Debt"]
CATEGORY_ICONS  = [
    "💰","🍜","🚌","🛒","💡","🏠","🏥","🎬","🛍️","🍽️",
    "✈️","🏦","💳","📈","📦","⚽","📚","👗","🎮","🎵",
]

# ── Singleton exports ─────────────────────────────────────────────────────────
P  = _PaletteProxy()
TY = Typography()
SP = Spacing()
R  = Radii()
