"""
core/database.py  — Firebase Realtime Database (Sprint 4)
──────────────────────────────────────────────────────────
This file replaces SQLite entirely with Firebase Realtime Database.
All other files (tabs, main.py) import from this module unchanged.

How it works
────────────
  • Reads firebase_config.json on startup
  • Signs in with Email/Password to get an auth token
  • All reads/writes use Firebase REST API (requests library)
  • A local in-memory cache avoids repeated network calls per session
  • If firebase_config.json is missing or Firebase is unreachable,
    falls back to SQLite automatically so the app always works

Firebase data structure
───────────────────────
  /categories/{push_id}  → { name, color, group_type, icon, created_at }
  /expenses/{push_id}    → { amount, description, category_id,
                              expense_date, payment, notes, created_at }
  /budgets/{push_id}     → { category_id, month, amount }
  /recurring/{push_id}   → { description, amount, category_id, payment,
                              frequency, day_of_month, next_due, active, notes }

Setup
─────
  Create firebase_config.json next to main.py:
  {
    "database_url": "https://YOUR-PROJECT-default-rtdb.firebaseio.com",
    "api_key":      "AIzaSy...",
    "auth_email":   "you@email.com",
    "auth_password":"yourpassword"
  }
"""

import json
import os
import uuid
import sqlite3
from datetime import datetime, date
from collections import defaultdict
from typing import Optional, List, Dict, Any

try:
    import requests as _requests
    _REQUESTS_OK = True
except ImportError:
    _REQUESTS_OK = False

# ── Config path ───────────────────────────────────────────────────────────────
_BASE_DIR   = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
CONFIG_FILE = os.path.join(_BASE_DIR, "firebase_config.json")
DB_PATH     = os.path.join(_BASE_DIR, "expenses.db")   # SQLite fallback path

# ── Runtime state ─────────────────────────────────────────────────────────────
_fb_url:    str  = ""
_fb_token:  str  = ""
_use_fb:    bool = False
_cache:     Dict[str, Any] = {}   # simple in-memory cache for this session

# ── Row wrapper (dict with attribute access — matches sqlite3.Row behaviour) ──
class Row(dict):
    def __getattr__(self, name):
        try:    return self[name]
        except KeyError: raise AttributeError(name)

def _row(**kw) -> Row:
    return Row(kw)

def _new_id() -> str:
    return uuid.uuid4().hex[:20]

# ═════════════════════════════════════════════════════════════════════════════
# FIREBASE REST HELPERS
# ═════════════════════════════════════════════════════════════════════════════

def _fb_url_for(path: str) -> str:
    auth = f"?auth={_fb_token}" if _fb_token else ""
    return f"{_fb_url.rstrip('/')}/{path}.json{auth}"

def _fb_get(path: str) -> Optional[dict]:
    try:
        r = _requests.get(_fb_url_for(path), timeout=8)
        r.raise_for_status()
        return r.json()
    except Exception as e:
        print(f"[Firebase] GET /{path} failed: {e}")
        return None

def _fb_put(path: str, data: dict) -> bool:
    try:
        r = _requests.put(_fb_url_for(path), json=data, timeout=8)
        r.raise_for_status()
        _cache.clear()   # invalidate cache on write
        return True
    except Exception as e:
        print(f"[Firebase] PUT /{path} failed: {e}")
        return False

def _fb_patch(path: str, data: dict) -> bool:
    try:
        r = _requests.patch(_fb_url_for(path), json=data, timeout=8)
        r.raise_for_status()
        _cache.clear()
        return True
    except Exception as e:
        print(f"[Firebase] PATCH /{path} failed: {e}")
        return False

def _fb_delete(path: str) -> bool:
    try:
        r = _requests.delete(_fb_url_for(path), timeout=8)
        r.raise_for_status()
        _cache.clear()
        return True
    except Exception as e:
        print(f"[Firebase] DELETE /{path} failed: {e}")
        return False

def _fb_post(path: str, data: dict) -> Optional[str]:
    """Firebase push — returns the new auto-generated key."""
    try:
        r = _requests.post(_fb_url_for(path), json=data, timeout=8)
        r.raise_for_status()
        _cache.clear()
        return r.json().get("name")
    except Exception as e:
        print(f"[Firebase] POST /{path} failed: {e}")
        return None

def _cached_get(path: str) -> Optional[dict]:
    """GET with a per-session cache. Call _cache.clear() after writes."""
    if path not in _cache:
        _cache[path] = _fb_get(path)
    return _cache[path]

# ═════════════════════════════════════════════════════════════════════════════
# INIT — connect to Firebase or fall back to SQLite
# ═════════════════════════════════════════════════════════════════════════════

def _load_config() -> dict:
    if os.path.exists(CONFIG_FILE):
        try:
            with open(CONFIG_FILE, encoding="utf-8") as f:
                cfg = json.load(f)
            # Check it's not still the template
            if "YOUR-APP" in cfg.get("database_url","") or \
               "YOUR_WEB" in cfg.get("api_key",""):
                print("[Firebase] firebase_config.json still has placeholder values.")
                return {}
            return cfg
        except Exception as e:
            print(f"[Firebase] Could not read config: {e}")
    return {}

def _firebase_login(api_key: str, email: str, password: str) -> str:
    """Sign in with email/password, return idToken."""
    url = (f"https://identitytoolkit.googleapis.com/v1/"
           f"accounts:signInWithPassword?key={api_key}")
    r = _requests.post(url, json={"email": email, "password": password,
                                   "returnSecureToken": True}, timeout=10)
    r.raise_for_status()
    return r.json()["idToken"]

def init_db() -> None:
    """
    Connect to Firebase (if configured) or SQLite (fallback).
    Must be called once at startup before any other function.
    """
    global _fb_url, _fb_token, _use_fb

    cfg = _load_config()
    if not cfg or not _REQUESTS_OK:
        print("[Database] Using SQLite (no Firebase config or requests not installed).")
        _use_fb = False
        _sqlite_init()
        return

    _fb_url = cfg.get("database_url", "").strip().rstrip("/")
    api_key  = cfg.get("api_key", "")
    email    = cfg.get("auth_email", "")
    password = cfg.get("auth_password", "")

    # ── Authenticate ──────────────────────────────────────────────────────────
    if api_key and email and password:
        try:
            _fb_token = _firebase_login(api_key, email, password)
            print("[Firebase] Authenticated successfully.")
        except Exception as e:
            print(f"[Firebase] Auth failed: {e}")
            print("[Firebase] Trying without authentication...")
            _fb_token = ""
    else:
        print("[Firebase] No auth credentials — connecting without auth.")
        _fb_token = ""

    # ── Test connection ───────────────────────────────────────────────────────
    try:
        test = _fb_get("categories")
        # None means a real error; {} or dict means success (even empty db)
        if test is not None or True:   # treat both None and {} as reachable
            r_check = _requests.get(_fb_url_for("categories"), timeout=6)
            if r_check.status_code in (200, 204, 404):
                _use_fb = True
                print(f"[Firebase] Connected to {_fb_url}")
                _seed_default_categories()
                return
    except Exception as e:
        print(f"[Firebase] Connection test failed: {e}")

    print("[Database] Firebase unreachable — falling back to SQLite.")
    _use_fb = False
    _sqlite_init()

def init_recurring_table() -> None:
    """No-op for Firebase (schema-less). Creates SQLite table if in fallback."""
    if not _use_fb:
        _sqlite_exec(_SCHEMA_V2)

def is_online() -> bool:
    return _use_fb

# ═════════════════════════════════════════════════════════════════════════════
# SQLITE FALLBACK — full implementation kept here so the file is self-contained
# ═════════════════════════════════════════════════════════════════════════════

_SCHEMA_SQLITE = """
CREATE TABLE IF NOT EXISTS categories (
    id         TEXT PRIMARY KEY,
    name       TEXT NOT NULL UNIQUE,
    color      TEXT NOT NULL DEFAULT '#5DCAA5',
    group_type TEXT NOT NULL DEFAULT 'Wants',
    icon       TEXT NOT NULL DEFAULT '💰',
    created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE TABLE IF NOT EXISTS expenses (
    id           TEXT PRIMARY KEY,
    amount       REAL NOT NULL CHECK(amount > 0),
    description  TEXT NOT NULL,
    category_id  TEXT NOT NULL,
    expense_date TEXT NOT NULL DEFAULT (date('now')),
    payment      TEXT NOT NULL DEFAULT 'UPI',
    notes        TEXT NOT NULL DEFAULT '',
    created_at   TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE TABLE IF NOT EXISTS budgets (
    id          TEXT PRIMARY KEY,
    category_id TEXT NOT NULL,
    month       TEXT NOT NULL,
    amount      REAL NOT NULL CHECK(amount >= 0),
    UNIQUE(category_id, month)
);
CREATE INDEX IF NOT EXISTS idx_exp_date ON expenses(expense_date);
CREATE INDEX IF NOT EXISTS idx_exp_cat  ON expenses(category_id);
"""

_SCHEMA_V2 = """
CREATE TABLE IF NOT EXISTS recurring (
    id           TEXT PRIMARY KEY,
    description  TEXT NOT NULL,
    amount       REAL NOT NULL CHECK(amount > 0),
    category_id  TEXT NOT NULL,
    payment      TEXT NOT NULL DEFAULT 'UPI',
    frequency    TEXT NOT NULL DEFAULT 'monthly',
    day_of_month INTEGER,
    next_due     TEXT NOT NULL,
    active       INTEGER NOT NULL DEFAULT 1,
    notes        TEXT NOT NULL DEFAULT '',
    created_at   TEXT NOT NULL DEFAULT (datetime('now'))
);
"""

DEFAULT_CATEGORIES = [
    ("Food & Dining",   "#E8A87C", "Needs",        "🍜"),
    ("Transport",       "#85C1E9", "Needs",        "🚌"),
    ("Groceries",       "#82E0AA", "Needs",        "🛒"),
    ("Utilities",       "#F7DC6F", "Needs",        "💡"),
    ("Housing / Rent",  "#AED6F1", "Needs",        "🏠"),
    ("Health",          "#F1948A", "Needs",        "🏥"),
    ("Entertainment",   "#C39BD3", "Wants",        "🎬"),
    ("Shopping",        "#F0B27A", "Wants",        "🛍️"),
    ("Dining Out",      "#FAD7A0", "Wants",        "🍽️"),
    ("Travel",          "#A9CCE3", "Wants",        "✈️"),
    ("Emergency Fund",  "#A9DFBF", "Savings/Debt", "🏦"),
    ("Loan / EMI",      "#F9E79F", "Savings/Debt", "💳"),
    ("Investments",     "#D5E8D4", "Savings/Debt", "📈"),
    ("Miscellaneous",   "#D5D8DC", "Wants",        "📦"),
]

def _sqlite_conn() -> sqlite3.Connection:
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode=WAL")
    conn.execute("PRAGMA foreign_keys=ON")
    return conn

def _sqlite_exec(sql: str) -> None:
    with _sqlite_conn() as conn:
        conn.executescript(sql)

def _sqlite_init() -> None:
    _sqlite_exec(_SCHEMA_SQLITE)
    with _sqlite_conn() as conn:
        for name, color, group, icon in DEFAULT_CATEGORIES:
            uid = _new_id()
            conn.execute(
                "INSERT OR IGNORE INTO categories(id,name,color,group_type,icon) "
                "VALUES(?,?,?,?,?)", (uid, name, color, group, icon))

def _to_row(sqlite_row) -> Row:
    """Convert sqlite3.Row → our Row dict."""
    if sqlite_row is None:
        return None
    return Row(dict(sqlite_row))

def _to_rows(sqlite_rows) -> List[Row]:
    return [Row(dict(r)) for r in sqlite_rows]

def get_connection():
    """Compatibility shim — only works in SQLite mode."""
    return _sqlite_conn()

# ═════════════════════════════════════════════════════════════════════════════
# FIREBASE DEFAULT CATEGORY SEED
# ═════════════════════════════════════════════════════════════════════════════

def _seed_default_categories() -> None:
    """Populate Firebase with default categories only if empty."""
    existing = _fb_get("categories")
    if existing:   # already seeded
        return
    print("[Firebase] Seeding default categories...")
    for name, color, group, icon in DEFAULT_CATEGORIES:
        fid = _new_id()
        _fb_put(f"categories/{fid}", {
            "name": name, "color": color,
            "group_type": group, "icon": icon,
            "created_at": datetime.now().isoformat()
        })
    _cache.clear()
    print("[Firebase] Default categories seeded.")

# ═════════════════════════════════════════════════════════════════════════════
# CATEGORY CRUD
# ═════════════════════════════════════════════════════════════════════════════

def get_all_categories() -> List[Row]:
    if _use_fb:
        data = _cached_get("categories") or {}
        rows = []
        for fid, v in data.items():
            rows.append(_row(
                id=fid,
                name=v.get("name",""),
                color=v.get("color","#888780"),
                group_type=v.get("group_type","Wants"),
                icon=v.get("icon","💰"),
                created_at=v.get("created_at","")
            ))
        rows.sort(key=lambda r: (r["group_type"], r["name"]))
        return rows
    else:
        with _sqlite_conn() as conn:
            return _to_rows(conn.execute(
                "SELECT * FROM categories ORDER BY group_type, name").fetchall())

def add_category(name: str, color: str, group_type: str, icon: str = "💰") -> str:
    fid = _new_id()
    if _use_fb:
        _fb_put(f"categories/{fid}", {
            "name": name, "color": color,
            "group_type": group_type, "icon": icon,
            "created_at": datetime.now().isoformat()
        })
    else:
        with _sqlite_conn() as conn:
            conn.execute(
                "INSERT INTO categories(id,name,color,group_type,icon) VALUES(?,?,?,?,?)",
                (fid, name, color, group_type, icon))
    return fid

def update_category(cat_id: str, name: str, color: str, group_type: str, icon: str) -> None:
    if _use_fb:
        _fb_patch(f"categories/{cat_id}",
                  {"name": name, "color": color,
                   "group_type": group_type, "icon": icon})
    else:
        with _sqlite_conn() as conn:
            conn.execute(
                "UPDATE categories SET name=?,color=?,group_type=?,icon=? WHERE id=?",
                (name, color, group_type, icon, cat_id))

def delete_category(cat_id: str) -> None:
    if _use_fb:
        _fb_delete(f"categories/{cat_id}")
    else:
        with _sqlite_conn() as conn:
            conn.execute("DELETE FROM categories WHERE id=?", (cat_id,))

# ═════════════════════════════════════════════════════════════════════════════
# EXPENSE CRUD
# ═════════════════════════════════════════════════════════════════════════════

def add_expense(amount: float, description: str, category_id: str,
                expense_date: str, payment: str, notes: str = "") -> str:
    fid = _new_id()
    data = {
        "amount": round(amount, 2),
        "description": description,
        "category_id": str(category_id),
        "expense_date": expense_date,
        "payment": payment,
        "notes": notes or "",
        "created_at": datetime.now().isoformat()
    }
    if _use_fb:
        _fb_put(f"expenses/{fid}", data)
    else:
        with _sqlite_conn() as conn:
            conn.execute(
                "INSERT INTO expenses(id,amount,description,category_id,"
                "expense_date,payment,notes) VALUES(?,?,?,?,?,?,?)",
                (fid, data["amount"], description, str(category_id),
                 expense_date, payment, notes or ""))
    return fid

def update_expense(exp_id: str, amount: float, description: str,
                   category_id: str, expense_date: str,
                   payment: str, notes: str) -> None:
    data = {
        "amount": round(amount, 2),
        "description": description,
        "category_id": str(category_id),
        "expense_date": expense_date,
        "payment": payment,
        "notes": notes or ""
    }
    if _use_fb:
        _fb_patch(f"expenses/{exp_id}", data)
    else:
        with _sqlite_conn() as conn:
            conn.execute(
                "UPDATE expenses SET amount=?,description=?,category_id=?,"
                "expense_date=?,payment=?,notes=? WHERE id=?",
                (data["amount"], description, str(category_id),
                 expense_date, payment, notes or "", exp_id))

def delete_expense(exp_id: str) -> None:
    if _use_fb:
        _fb_delete(f"expenses/{exp_id}")
    else:
        with _sqlite_conn() as conn:
            conn.execute("DELETE FROM expenses WHERE id=?", (exp_id,))

# ── Internal: fetch & enrich expenses ─────────────────────────────────────────
def _fetch_all_fb() -> List[Row]:
    """Fetch all expenses enriched with category data from Firebase."""
    cats_data = _cached_get("categories") or {}
    exps_data = _cached_get("expenses")   or {}
    cats_by_id = {fid: v for fid, v in cats_data.items()}
    rows = []
    for fid, v in exps_data.items():
        cat_id = str(v.get("category_id",""))
        cat    = cats_by_id.get(cat_id, {})
        rows.append(_row(
            id=fid,
            amount=float(v.get("amount",0)),
            description=v.get("description",""),
            category_id=cat_id,
            expense_date=v.get("expense_date",""),
            payment=v.get("payment",""),
            notes=v.get("notes",""),
            created_at=v.get("created_at",""),
            cat_name=cat.get("name","Uncategorised"),
            cat_color=cat.get("color","#888780"),
            cat_icon=cat.get("icon","💰"),
            group_type=cat.get("group_type","Wants"),
        ))
    return rows

def _fetch_all_sqlite() -> List[Row]:
    with _sqlite_conn() as conn:
        return _to_rows(conn.execute("""
            SELECT e.*, c.name AS cat_name, c.color AS cat_color,
                   c.icon AS cat_icon, c.group_type
            FROM expenses e
            JOIN categories c ON c.id = e.category_id
        """).fetchall())

def _all_expenses() -> List[Row]:
    return _fetch_all_fb() if _use_fb else _fetch_all_sqlite()

def get_expenses(category_id: Optional[str] = None,
                 month: Optional[str] = None,
                 sort: str = "date_desc") -> List[Row]:
    if _use_fb:
        rows = _fetch_all_fb()
        if category_id:
            rows = [r for r in rows if r["category_id"] == str(category_id)]
        if month:
            rows = [r for r in rows if r["expense_date"].startswith(month)]
    else:
        wheres, params = [], []
        if category_id:
            wheres.append("e.category_id = ?"); params.append(str(category_id))
        if month:
            wheres.append("strftime('%Y-%m', e.expense_date) = ?"); params.append(month)
        where_sql = ("WHERE " + " AND ".join(wheres)) if wheres else ""
        with _sqlite_conn() as conn:
            rows = _to_rows(conn.execute(f"""
                SELECT e.*, c.name AS cat_name, c.color AS cat_color,
                       c.icon AS cat_icon, c.group_type
                FROM expenses e
                JOIN categories c ON c.id = e.category_id
                {where_sql}
            """, params).fetchall())

    order_key = {
        "date_desc":   lambda r: r["expense_date"],
        "date_asc":    lambda r: r["expense_date"],
        "amount_desc": lambda r: r["amount"],
        "amount_asc":  lambda r: r["amount"],
    }.get(sort, lambda r: r["expense_date"])
    reverse = sort in ("date_desc", "amount_desc")
    rows.sort(key=order_key, reverse=reverse)
    return rows

# ═════════════════════════════════════════════════════════════════════════════
# AGGREGATION QUERIES
# ═════════════════════════════════════════════════════════════════════════════

def monthly_total(month: str) -> float:
    rows = _all_expenses()
    return sum(r["amount"] for r in rows if r["expense_date"].startswith(month))

def monthly_by_category(month: str) -> List[Row]:
    rows   = _all_expenses()
    m_rows = [r for r in rows if r["expense_date"].startswith(month)]
    by_cat: Dict[str, dict] = {}
    for r in m_rows:
        key = r["cat_name"]
        if key not in by_cat:
            by_cat[key] = {"name": r["cat_name"], "color": r["cat_color"],
                           "icon": r["cat_icon"], "group_type": r["group_type"],
                           "total": 0.0}
        by_cat[key]["total"] += r["amount"]
    result = [_row(**v) for v in by_cat.values() if v["total"] > 0]
    result.sort(key=lambda r: r["total"], reverse=True)
    return result

def monthly_by_group(month: str) -> List[Row]:
    rows   = _all_expenses()
    by_grp: Dict[str, float] = defaultdict(float)
    for r in rows:
        if r["expense_date"].startswith(month):
            by_grp[r["group_type"]] += r["amount"]
    return [_row(group_type=g, total=t) for g, t in by_grp.items()]

def last_n_months_totals(n: int = 6) -> List[Row]:
    rows   = _all_expenses()
    by_m: Dict[str, float] = defaultdict(float)
    for r in rows:
        by_m[r["expense_date"][:7]] += r["amount"]
    months = sorted(by_m.keys(), reverse=True)[:n]
    return [_row(month=m, total=by_m[m]) for m in sorted(months)]

def daily_totals_for_month(month: str) -> List[Row]:
    rows   = _all_expenses()
    by_day: Dict[str, float] = defaultdict(float)
    for r in rows:
        if r["expense_date"].startswith(month):
            by_day[r["expense_date"]] += r["amount"]
    return [_row(day=d, total=t) for d, t in sorted(by_day.items())]

def available_months() -> List[str]:
    rows = _all_expenses()
    return sorted({r["expense_date"][:7] for r in rows}, reverse=True)

def monthly_summary(month: str) -> dict:
    all_rows  = _all_expenses()
    m_rows    = [r for r in all_rows if r["expense_date"].startswith(month)]
    total     = sum(r["amount"] for r in m_rows)
    count     = len(m_rows)

    # top category
    by_cat: Dict[str, float] = defaultdict(float)
    for r in m_rows: by_cat[r["cat_name"]] += r["amount"]
    top_name = max(by_cat, key=by_cat.get) if by_cat else None
    top_row  = next((r for r in m_rows if r["cat_name"] == top_name), None)

    # biggest expense
    biggest = max(m_rows, key=lambda r: r["amount"]) if m_rows else None

    # busiest day
    by_day: Dict[str, float] = defaultdict(float)
    for r in m_rows: by_day[r["expense_date"]] += r["amount"]
    busiest_day = max(by_day, key=by_day.get) if by_day else None

    # by payment
    by_pay: Dict[str, dict] = {}
    for r in m_rows:
        p = r["payment"]
        if p not in by_pay:
            by_pay[p] = {"s": 0.0, "cnt": 0}
        by_pay[p]["s"]   += r["amount"]
        by_pay[p]["cnt"] += 1

    return {
        "month":   month,
        "total":   total,
        "count":   count,
        "top_cat": {"name": top_name,
                    "icon": top_row["cat_icon"] if top_row else "💰"
                   } if top_name else None,
        "biggest": biggest,
        "busiest": _row(expense_date=busiest_day,
                        s=by_day[busiest_day]) if busiest_day else None,
        "by_pay":  [_row(payment=k, **v) for k, v in by_pay.items()],
    }

# ═════════════════════════════════════════════════════════════════════════════
# SEARCH
# ═════════════════════════════════════════════════════════════════════════════

def search_descriptions(term: str, limit: int = 8) -> List[str]:
    rows = _all_expenses()
    seen, results = set(), []
    for r in rows:
        d = r["description"]
        if term.lower() in d.lower() and d not in seen:
            seen.add(d); results.append(d)
        if len(results) >= limit:
            break
    return results

def search_expenses_full(term: str) -> List[Row]:
    low  = term.lower()
    rows = _all_expenses()
    return [r for r in rows
            if low in r["description"].lower()
            or low in r["cat_name"].lower()
            or low in (r["notes"] or "").lower()
            or low in r["payment"].lower()]

# ═════════════════════════════════════════════════════════════════════════════
# BUDGET CRUD
# ═════════════════════════════════════════════════════════════════════════════

def set_budget(category_id: str, month: str, amount: float) -> None:
    if _use_fb:
        budgets = _fb_get("budgets") or {}
        for fid, b in budgets.items():
            if str(b.get("category_id","")) == str(category_id) and b.get("month") == month:
                _fb_patch(f"budgets/{fid}", {"amount": amount})
                return
        fid = _new_id()
        _fb_put(f"budgets/{fid}", {
            "category_id": str(category_id), "month": month, "amount": amount
        })
    else:
        with _sqlite_conn() as conn:
            existing = conn.execute(
                "SELECT id FROM budgets WHERE category_id=? AND month=?",
                (str(category_id), month)).fetchone()
            if existing:
                conn.execute("UPDATE budgets SET amount=? WHERE id=?",
                             (amount, existing["id"]))
            else:
                conn.execute(
                    "INSERT INTO budgets(id,category_id,month,amount) VALUES(?,?,?,?)",
                    (_new_id(), str(category_id), month, amount))

def get_budgets(month: str) -> List[Row]:
    if _use_fb:
        budgets    = _fb_get("budgets")    or {}
        cats_data  = _cached_get("categories") or {}
        exps_data  = _cached_get("expenses")   or {}
        cats_by_id = {fid: v for fid, v in cats_data.items()}
        result = []
        for fid, b in budgets.items():
            if b.get("month") != month:
                continue
            cat_id = str(b.get("category_id",""))
            cat    = cats_by_id.get(cat_id, {})
            spent  = sum(float(v.get("amount",0)) for v in exps_data.values()
                         if str(v.get("category_id","")) == cat_id
                         and v.get("expense_date","").startswith(month))
            result.append(_row(
                id=fid, category_id=cat_id, month=month,
                amount=float(b.get("amount",0)),
                name=cat.get("name","?"),
                color=cat.get("color","#888"),
                icon=cat.get("icon","💰"),
                spent=spent
            ))
        return result
    else:
        with _sqlite_conn() as conn:
            return _to_rows(conn.execute("""
                SELECT b.*, c.name, c.color, c.icon,
                       COALESCE((SELECT SUM(e.amount) FROM expenses e
                                 WHERE e.category_id=b.category_id
                                 AND strftime('%Y-%m',e.expense_date)=b.month),0) AS spent
                FROM budgets b JOIN categories c ON c.id=b.category_id
                WHERE b.month=?
            """, (month,)).fetchall())

# ═════════════════════════════════════════════════════════════════════════════
# RECURRING CRUD
# ═════════════════════════════════════════════════════════════════════════════

def add_recurring(description: str, amount: float, category_id: str,
                  payment: str, frequency: str, day_of_month: int,
                  next_due: str, notes: str = "") -> str:
    fid  = _new_id()
    data = {
        "description": description, "amount": round(amount,2),
        "category_id": str(category_id), "payment": payment,
        "frequency": frequency, "day_of_month": day_of_month,
        "next_due": next_due, "active": 1, "notes": notes or "",
        "created_at": datetime.now().isoformat()
    }
    if _use_fb:
        _fb_put(f"recurring/{fid}", data)
    else:
        with _sqlite_conn() as conn:
            conn.execute(
                "INSERT INTO recurring(id,description,amount,category_id,payment,"
                "frequency,day_of_month,next_due,active,notes) VALUES(?,?,?,?,?,?,?,?,?,?)",
                (fid, description, round(amount,2), str(category_id), payment,
                 frequency, day_of_month, next_due, 1, notes or ""))
    return fid

def get_recurring() -> List[Row]:
    if _use_fb:
        recs       = _fb_get("recurring")  or {}
        cats_data  = _cached_get("categories") or {}
        cats_by_id = {fid: v for fid, v in cats_data.items()}
        rows = []
        for fid, v in recs.items():
            cat = cats_by_id.get(str(v.get("category_id","")), {})
            rows.append(_row(
                id=fid, description=v.get("description",""),
                amount=float(v.get("amount",0)),
                category_id=str(v.get("category_id","")),
                payment=v.get("payment","UPI"),
                frequency=v.get("frequency","monthly"),
                day_of_month=v.get("day_of_month",1),
                next_due=v.get("next_due",""),
                active=int(v.get("active",1)),
                notes=v.get("notes",""),
                cat_name=cat.get("name","?"),
                cat_color=cat.get("color","#888"),
                cat_icon=cat.get("icon","💰"),
            ))
        return sorted(rows, key=lambda r: r["next_due"])
    else:
        with _sqlite_conn() as conn:
            return _to_rows(conn.execute("""
                SELECT r.*, c.name AS cat_name, c.color AS cat_color, c.icon AS cat_icon
                FROM recurring r JOIN categories c ON c.id=r.category_id
                ORDER BY r.next_due
            """).fetchall())

def get_due_recurring(as_of: str) -> List[Row]:
    return [r for r in get_recurring()
            if int(r["active"]) == 1 and r["next_due"] <= as_of]

def update_recurring_next_due(rec_id: str, next_due: str) -> None:
    if _use_fb:
        _fb_patch(f"recurring/{rec_id}", {"next_due": next_due})
    else:
        with _sqlite_conn() as conn:
            conn.execute("UPDATE recurring SET next_due=? WHERE id=?",
                         (next_due, rec_id))

def toggle_recurring(rec_id: str) -> None:
    if _use_fb:
        recs = _fb_get("recurring") or {}
        cur  = int(recs.get(rec_id, {}).get("active", 1))
        _fb_patch(f"recurring/{rec_id}", {"active": 1 - cur})
    else:
        with _sqlite_conn() as conn:
            conn.execute("UPDATE recurring SET active=1-active WHERE id=?",
                         (rec_id,))

def delete_recurring(rec_id: str) -> None:
    if _use_fb:
        _fb_delete(f"recurring/{rec_id}")
    else:
        with _sqlite_conn() as conn:
            conn.execute("DELETE FROM recurring WHERE id=?", (rec_id,))

# ═════════════════════════════════════════════════════════════════════════════
# CSV IMPORT
# ═════════════════════════════════════════════════════════════════════════════

def import_from_csv(filepath: str):
    import csv as _csv
    cats   = {c["name"].lower(): c["id"] for c in get_all_categories()}
    imported, errors = 0, []

    with open(filepath, newline="", encoding="utf-8-sig") as f:
        reader = _csv.DictReader(f)
        reader.fieldnames = [h.strip().lower() for h in (reader.fieldnames or [])]
        for row_num, row in enumerate(reader, start=2):
            try:
                raw_date = (row.get("date") or row.get("expense_date","")).strip()
                desc     = row.get("description","").strip()
                raw_amt  = row.get("amount","").strip()
                cat_name = row.get("category","").strip().lower()
                payment  = row.get("payment","UPI").strip() or "UPI"
                notes    = row.get("notes","").strip()

                if not raw_date or not desc or not raw_amt:
                    errors.append(f"Row {row_num}: missing required fields")
                    continue
                try:
                    datetime.strptime(raw_date, "%Y-%m-%d")
                except ValueError:
                    errors.append(f"Row {row_num}: bad date '{raw_date}'")
                    continue
                try:
                    amount = float(raw_amt)
                    assert amount > 0
                except Exception:
                    errors.append(f"Row {row_num}: bad amount '{raw_amt}'")
                    continue

                cat_id = cats.get(cat_name)
                if cat_id is None:
                    matches = [cid for cname, cid in cats.items()
                               if cat_name in cname or cname in cat_name]
                    cat_id = matches[0] if matches else (next(iter(cats.values())) if cats else None)
                if cat_id is None:
                    errors.append(f"Row {row_num}: no categories found")
                    continue

                add_expense(amount, desc, cat_id, raw_date, payment, notes)
                imported += 1
            except Exception as e:
                errors.append(f"Row {row_num}: error — {e}")

    return imported, errors
