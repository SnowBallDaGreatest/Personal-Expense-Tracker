"""
core/firebase_db.py
────────────────────
Firebase Realtime Database adapter.

Drop-in replacement for database.py — all public function signatures
are identical so no other file needs changing except the import line
in main.py (swap `from core.database import …` → `from core.firebase_db import …`).

Setup
─────
1. Create a Firebase project at https://console.firebase.google.com
2. Add a Realtime Database (start in test mode for development)
3. Copy your database URL (e.g. https://your-app-default-rtdb.firebaseio.com)
4. Create firebase_config.json next to main.py:

   {
     "database_url": "https://YOUR-APP-default-rtdb.firebaseio.com",
     "api_key": "YOUR_WEB_API_KEY",          ← optional, for auth
     "auth_email": "user@example.com",        ← optional
     "auth_password": "yourpassword"          ← optional
   }

5. For read-only testing without auth, set database rules to:
   { "rules": { ".read": true, ".write": true } }   ← dev only!

Data structure in Firebase
──────────────────────────
  /categories/{id}   → { name, color, group_type, icon, created_at }
  /expenses/{id}     → { amount, description, category_id, expense_date,
                          payment, notes, created_at }
  /budgets/{id}      → { category_id, month, amount }
  /recurring/{id}    → { description, amount, category_id, payment,
                          frequency, day_of_month, next_due, active, notes }

Offline fallback
────────────────
If Firebase is unreachable (no internet, wrong URL), the adapter
automatically falls back to a local SQLite database so the app
remains usable offline. A warning banner is shown in the UI.
"""

import json
import os
import time
import threading
import uuid
from datetime import date, datetime
from typing import Optional
from collections import defaultdict

import requests

# ── config ────────────────────────────────────────────────────────────────────
CONFIG_FILE = os.path.join(os.path.dirname(__file__), "..", "firebase_config.json")
_OFFLINE_FALLBACK = True    # use SQLite when Firebase unreachable

# ── connection state ──────────────────────────────────────────────────────────
_firebase_url: str = ""
_auth_token:   str = ""
_online:       bool = False
_status_callbacks = []


def _load_config() -> dict:
    if os.path.exists(CONFIG_FILE):
        try:
            with open(CONFIG_FILE) as f:
                return json.load(f)
        except Exception:
            pass
    return {}


def _new_id() -> str:
    return str(uuid.uuid4()).replace("-", "")[:20]


# ── Firebase REST helpers ──────────────────────────────────────────────────────
def _url(path: str) -> str:
    base = _firebase_url.rstrip("/")
    auth = f"?auth={_auth_token}" if _auth_token else ""
    return f"{base}/{path}.json{auth}"


def _get(path: str) -> Optional[dict]:
    try:
        r = requests.get(_url(path), timeout=6)
        r.raise_for_status()
        return r.json()
    except Exception:
        return None


def _put(path: str, data: dict) -> bool:
    try:
        r = requests.put(_url(path), json=data, timeout=6)
        r.raise_for_status()
        return True
    except Exception:
        return False


def _patch(path: str, data: dict) -> bool:
    try:
        r = requests.patch(_url(path), json=data, timeout=6)
        r.raise_for_status()
        return True
    except Exception:
        return False


def _delete(path: str) -> bool:
    try:
        r = requests.delete(_url(path), timeout=6)
        r.raise_for_status()
        return True
    except Exception:
        return False


def _post(path: str, data: dict) -> Optional[str]:
    """Firebase push (creates child with auto-id). Returns the new id."""
    try:
        r = requests.post(_url(path), json=data, timeout=6)
        r.raise_for_status()
        return r.json().get("name")   # Firebase returns {"name": "-NxYZ..."}
    except Exception:
        return None


# ── Row wrapper so data looks like sqlite3.Row (dict-like) ────────────────────
class Row(dict):
    """Dict that also supports attribute-style access: row["key"] and row.key."""
    def __getattr__(self, name):
        try:
            return self[name]
        except KeyError:
            raise AttributeError(name)


def _row(**kw) -> Row:
    return Row(kw)


# ── init / connect ────────────────────────────────────────────────────────────
# SQLite fallback import
_sqlite_available = False
try:
    from core import database as _sqlite
    _sqlite_available = True
except ImportError:
    pass


def init_db() -> None:
    """Connect to Firebase (or fall back to SQLite)."""
    global _firebase_url, _auth_token, _online

    cfg = _load_config()
    _firebase_url = cfg.get("database_url", "").strip()

    if not _firebase_url:
        print("[Firebase] No database_url in firebase_config.json — using SQLite fallback.")
        _online = False
        if _sqlite_available:
            _sqlite.init_db()
        return

    # optional email/password auth
    email    = cfg.get("auth_email", "")
    password = cfg.get("auth_password", "")
    api_key  = cfg.get("api_key", "")
    if email and password and api_key:
        try:
            r = requests.post(
                f"https://identitytoolkit.googleapis.com/v1/accounts:signInWithPassword"
                f"?key={api_key}",
                json={"email": email, "password": password,
                      "returnSecureToken": True},
                timeout=8)
            r.raise_for_status()
            _auth_token = r.json().get("idToken", "")
        except Exception as e:
            print(f"[Firebase] Auth failed: {e} — trying without auth.")

    # ping
    result = _get("ping_test")
    _online = (result is not None or result == {})   # 404 → None, empty node → {}
    # a 404-style None could mean wrong URL; treat None as offline
    if result is None:
        # try one more time with root
        try:
            r2 = requests.get(_url("").replace("ping_test.json","") + ".json",
                              timeout=6)
            _online = r2.status_code in (200, 204)
        except Exception:
            _online = False

    if _online:
        print(f"[Firebase] Connected to {_firebase_url}")
        _seed_default_categories()
    else:
        print(f"[Firebase] Unreachable ({_firebase_url}) — using SQLite fallback.")
        if _sqlite_available:
            _sqlite.init_db()


def init_recurring_table() -> None:
    """Recurring table is part of Firebase schema; nothing extra to do."""
    if not _online and _sqlite_available:
        _sqlite.init_recurring_table()


def is_online() -> bool:
    return _online


# ── Default categories seed ───────────────────────────────────────────────────
_DEFAULT_CATS = [
    ("Food & Dining",   "#E8A87C", "Needs",        "🍜"),
    ("Transport",       "#85C1E9", "Needs",        "🚌"),
    ("Groceries",       "#82E0AA", "Needs",        "🛒"),
    ("Utilities",       "#F7DC6F", "Needs",        "💡"),
    ("Housing / Rent",  "#AED6F1", "Needs",        "🏠"),
    ("Health",          "#F1948A", "Needs",        "🏥"),
    ("Entertainment",   "#C39BD3", "Wants",        "🎬"),
    ("Shopping",        "#F0B27A", "Wants",        "🛍️"),
    ("Dining Out",      "#FAD7A0", "Wants",        "🍽️"),
    ("Travel",          "#A9CCE3", "Wants",        "✈️"),
    ("Emergency Fund",  "#A9DFBF", "Savings/Debt", "🏦"),
    ("Loan / EMI",      "#F9E79F", "Savings/Debt", "💳"),
    ("Investments",     "#D5E8D4", "Savings/Debt", "📈"),
    ("Miscellaneous",   "#D5D8DC", "Wants",        "📦"),
]


def _seed_default_categories():
    existing = _get("categories") or {}
    if existing:
        return
    for name, color, group, icon in _DEFAULT_CATS:
        fid = _new_id()
        _put(f"categories/{fid}", {
            "name": name, "color": color,
            "group_type": group, "icon": icon,
            "created_at": datetime.now().isoformat()
        })


# ── Route every call through Firebase or SQLite fallback ─────────────────────
def _fb_or_sqlite(fb_func, sqlite_func, *args, **kwargs):
    if _online:
        return fb_func(*args, **kwargs)
    elif _sqlite_available:
        return sqlite_func(*args, **kwargs)
    return None


# ── Category CRUD ─────────────────────────────────────────────────────────────
def get_all_categories() -> list[Row]:
    if not _online:
        return _sqlite.get_all_categories() if _sqlite_available else []
    data = _get("categories") or {}
    rows = []
    for fid, v in data.items():
        rows.append(_row(id=fid, name=v.get("name",""),
                         color=v.get("color","#888780"),
                         group_type=v.get("group_type","Wants"),
                         icon=v.get("icon","💰"),
                         created_at=v.get("created_at","")))
    rows.sort(key=lambda r: (r["group_type"], r["name"]))
    return rows


def add_category(name: str, color: str, group_type: str, icon: str = "💰") -> str:
    if not _online:
        return _sqlite.add_category(name, color, group_type, icon) if _sqlite_available else ""
    fid = _new_id()
    _put(f"categories/{fid}", {
        "name": name, "color": color, "group_type": group_type,
        "icon": icon, "created_at": datetime.now().isoformat()
    })
    return fid


def update_category(cat_id: str, name: str, color: str, group_type: str, icon: str) -> None:
    if not _online:
        if _sqlite_available: _sqlite.update_category(cat_id, name, color, group_type, icon)
        return
    _patch(f"categories/{cat_id}",
           {"name": name, "color": color, "group_type": group_type, "icon": icon})


def delete_category(cat_id: str) -> None:
    if not _online:
        if _sqlite_available: _sqlite.delete_category(cat_id)
        return
    _delete(f"categories/{cat_id}")


# ── Expense CRUD ──────────────────────────────────────────────────────────────
def add_expense(amount: float, description: str, category_id: str,
                expense_date: str, payment: str, notes: str = "") -> str:
    if not _online:
        return _sqlite.add_expense(amount, description, category_id,
                                   expense_date, payment, notes) if _sqlite_available else ""
    fid = _new_id()
    _put(f"expenses/{fid}", {
        "amount": round(amount, 2), "description": description,
        "category_id": category_id, "expense_date": expense_date,
        "payment": payment, "notes": notes or "",
        "created_at": datetime.now().isoformat()
    })
    return fid


def update_expense(exp_id: str, amount: float, description: str,
                   category_id: str, expense_date: str,
                   payment: str, notes: str) -> None:
    if not _online:
        if _sqlite_available: _sqlite.update_expense(
            exp_id, amount, description, category_id, expense_date, payment, notes)
        return
    _patch(f"expenses/{exp_id}", {
        "amount": round(amount, 2), "description": description,
        "category_id": category_id, "expense_date": expense_date,
        "payment": payment, "notes": notes or ""
    })


def delete_expense(exp_id: str) -> None:
    if not _online:
        if _sqlite_available: _sqlite.delete_expense(exp_id)
        return
    _delete(f"expenses/{exp_id}")


def _enrich_expenses(expenses_data: dict, cats_by_id: dict) -> list[Row]:
    """Join expenses with category data and return sorted Row list."""
    rows = []
    for fid, v in (expenses_data or {}).items():
        cat_id = v.get("category_id", "")
        cat    = cats_by_id.get(cat_id, {})
        rows.append(_row(
            id=fid,
            amount=v.get("amount", 0),
            description=v.get("description", ""),
            category_id=cat_id,
            expense_date=v.get("expense_date", ""),
            payment=v.get("payment", ""),
            notes=v.get("notes", ""),
            created_at=v.get("created_at", ""),
            cat_name=cat.get("name", "Uncategorised"),
            cat_color=cat.get("color", "#888780"),
            cat_icon=cat.get("icon", "💰"),
            group_type=cat.get("group_type", "Wants"),
        ))
    return rows


def get_expenses(category_id: Optional[str] = None,
                 month: Optional[str] = None,
                 sort: str = "date_desc") -> list[Row]:
    if not _online:
        return _sqlite.get_expenses(category_id, month, sort) if _sqlite_available else []

    # fetch in parallel for speed
    cats_data = _get("categories") or {}
    exps_data = _get("expenses")   or {}

    cats_by_id = {fid: v for fid, v in cats_data.items()}
    rows = _enrich_expenses(exps_data, cats_by_id)

    # filter
    if category_id:
        rows = [r for r in rows if r["category_id"] == category_id]
    if month:
        rows = [r for r in rows if r["expense_date"].startswith(month)]

    # sort
    if sort == "date_desc":
        rows.sort(key=lambda r: r["expense_date"], reverse=True)
    elif sort == "date_asc":
        rows.sort(key=lambda r: r["expense_date"])
    elif sort == "amount_desc":
        rows.sort(key=lambda r: r["amount"], reverse=True)
    elif sort == "amount_asc":
        rows.sort(key=lambda r: r["amount"])
    return rows


# ── Aggregations (computed locally from fetched data) ─────────────────────────
def _fetch_all() -> tuple[dict, dict]:
    """Return (cats_by_id, expenses_list). Cached per-second in thread-local."""
    cats_data = _get("categories") or {}
    exps_data = _get("expenses")   or {}
    cats_by_id = {fid: v for fid, v in cats_data.items()}
    rows = _enrich_expenses(exps_data, cats_by_id)
    return cats_by_id, rows


def monthly_total(month: str) -> float:
    if not _online:
        return _sqlite.monthly_total(month) if _sqlite_available else 0
    _, rows = _fetch_all()
    return sum(r["amount"] for r in rows if r["expense_date"].startswith(month))


def monthly_by_category(month: str) -> list[Row]:
    if not _online:
        return _sqlite.monthly_by_category(month) if _sqlite_available else []
    cats_by_id, rows = _fetch_all()
    month_rows = [r for r in rows if r["expense_date"].startswith(month)]
    by_cat: dict = defaultdict(float)
    for r in month_rows:
        by_cat[r["category_id"]] += r["amount"]
    result = []
    for cat_id, total in by_cat.items():
        cat = cats_by_id.get(cat_id, {})
        result.append(_row(name=cat.get("name","?"),
                           color=cat.get("color","#888"),
                           icon=cat.get("icon","💰"),
                           group_type=cat.get("group_type","Wants"),
                           total=total))
    result.sort(key=lambda r: r["total"], reverse=True)
    return result


def monthly_by_group(month: str) -> list[Row]:
    if not _online:
        return _sqlite.monthly_by_group(month) if _sqlite_available else []
    _, rows = _fetch_all()
    by_grp: dict = defaultdict(float)
    for r in rows:
        if r["expense_date"].startswith(month):
            by_grp[r["group_type"]] += r["amount"]
    return [_row(group_type=g, total=t) for g, t in by_grp.items()]


def last_n_months_totals(n: int = 6) -> list[Row]:
    if not _online:
        return _sqlite.last_n_months_totals(n) if _sqlite_available else []
    _, rows = _fetch_all()
    by_m: dict = defaultdict(float)
    for r in rows:
        by_m[r["expense_date"][:7]] += r["amount"]
    months = sorted(by_m.keys(), reverse=True)[:n]
    return [_row(month=m, total=by_m[m]) for m in sorted(months)]


def daily_totals_for_month(month: str) -> list[Row]:
    if not _online:
        return _sqlite.daily_totals_for_month(month) if _sqlite_available else []
    _, rows = _fetch_all()
    by_day: dict = defaultdict(float)
    for r in rows:
        if r["expense_date"].startswith(month):
            by_day[r["expense_date"]] += r["amount"]
    return [_row(day=d, total=t)
            for d, t in sorted(by_day.items())]


def available_months() -> list[str]:
    if not _online:
        return _sqlite.available_months() if _sqlite_available else []
    _, rows = _fetch_all()
    months = sorted({r["expense_date"][:7] for r in rows}, reverse=True)
    return months


def monthly_summary(month: str) -> dict:
    if not _online:
        return _sqlite.monthly_summary(month) if _sqlite_available else {}
    cats_by_id, rows = _fetch_all()
    month_rows = [r for r in rows if r["expense_date"].startswith(month)]

    total = sum(r["amount"] for r in month_rows)
    count = len(month_rows)

    by_cat: dict = defaultdict(float)
    for r in month_rows: by_cat[r["cat_name"]] += r["amount"]
    top_name = max(by_cat, key=by_cat.get) if by_cat else None
    top_cat_row = next((r for r in month_rows if r["cat_name"] == top_name), None)

    biggest = max(month_rows, key=lambda r: r["amount"]) if month_rows else None

    by_day: dict = defaultdict(float)
    for r in month_rows: by_day[r["expense_date"]] += r["amount"]
    busiest_day = max(by_day, key=by_day.get) if by_day else None

    by_pay: dict = defaultdict(lambda: {"s": 0, "cnt": 0})
    for r in month_rows:
        by_pay[r["payment"]]["s"]   += r["amount"]
        by_pay[r["payment"]]["cnt"] += 1

    return {
        "month":   month,
        "total":   total,
        "count":   count,
        "top_cat": {"name": top_name,
                    "icon": top_cat_row["cat_icon"] if top_cat_row else "💰"
                    } if top_name else None,
        "biggest": biggest,
        "busiest": _row(expense_date=busiest_day,
                        s=by_day[busiest_day]) if busiest_day else None,
        "by_pay":  [_row(payment=k, **v) for k, v in by_pay.items()],
    }


def search_descriptions(term: str, limit: int = 8) -> list[str]:
    if not _online:
        return _sqlite.search_descriptions(term, limit) if _sqlite_available else []
    _, rows = _fetch_all()
    seen, results = set(), []
    for r in rows:
        d = r["description"]
        if term.lower() in d.lower() and d not in seen:
            seen.add(d); results.append(d)
        if len(results) >= limit:
            break
    return results


def search_expenses_full(term: str) -> list[Row]:
    if not _online:
        return _sqlite.search_expenses_full(term) if _sqlite_available else []
    _, rows = _fetch_all()
    low = term.lower()
    return [r for r in rows
            if low in r["description"].lower()
            or low in r["cat_name"].lower()
            or low in (r["notes"] or "").lower()
            or low in r["payment"].lower()]


# ── Budget CRUD ───────────────────────────────────────────────────────────────
def set_budget(category_id: str, month: str, amount: float) -> None:
    if not _online:
        if _sqlite_available: _sqlite.set_budget(category_id, month, amount)
        return
    # find existing
    budgets = _get("budgets") or {}
    for fid, b in budgets.items():
        if b.get("category_id") == category_id and b.get("month") == month:
            _patch(f"budgets/{fid}", {"amount": amount})
            return
    fid = _new_id()
    _put(f"budgets/{fid}", {"category_id": category_id,
                             "month": month, "amount": amount})


def get_budgets(month: str) -> list[Row]:
    if not _online:
        return _sqlite.get_budgets(month) if _sqlite_available else []
    budgets   = _get("budgets")    or {}
    cats_data = _get("categories") or {}
    exps_data = _get("expenses")   or {}
    cats_by_id = {fid: v for fid, v in cats_data.items()}

    result = []
    for fid, b in budgets.items():
        if b.get("month") != month:
            continue
        cat_id = b.get("category_id", "")
        cat    = cats_by_id.get(cat_id, {})
        spent  = sum(v.get("amount", 0) for v in exps_data.values()
                     if v.get("category_id") == cat_id
                     and v.get("expense_date","").startswith(month))
        result.append(_row(id=fid, category_id=cat_id,
                           month=month, amount=b.get("amount", 0),
                           name=cat.get("name","?"),
                           color=cat.get("color","#888"),
                           icon=cat.get("icon","💰"),
                           spent=spent))
    return result


# ── Recurring CRUD ────────────────────────────────────────────────────────────
def add_recurring(description: str, amount: float, category_id: str,
                  payment: str, frequency: str, day_of_month: int,
                  next_due: str, notes: str = "") -> str:
    if not _online:
        return _sqlite.add_recurring(description, amount, category_id,
                                     payment, frequency, day_of_month,
                                     next_due, notes) if _sqlite_available else ""
    fid = _new_id()
    _put(f"recurring/{fid}", {
        "description": description, "amount": round(amount, 2),
        "category_id": category_id, "payment": payment,
        "frequency": frequency, "day_of_month": day_of_month,
        "next_due": next_due, "active": 1, "notes": notes or "",
        "created_at": datetime.now().isoformat()
    })
    return fid


def get_recurring() -> list[Row]:
    if not _online:
        return _sqlite.get_recurring() if _sqlite_available else []
    recs      = _get("recurring")   or {}
    cats_data = _get("categories") or {}
    cats_by_id = {fid: v for fid, v in cats_data.items()}
    rows = []
    for fid, v in recs.items():
        cat = cats_by_id.get(v.get("category_id",""), {})
        rows.append(_row(
            id=fid, description=v.get("description",""),
            amount=v.get("amount",0), category_id=v.get("category_id",""),
            payment=v.get("payment","UPI"), frequency=v.get("frequency","monthly"),
            day_of_month=v.get("day_of_month",1), next_due=v.get("next_due",""),
            active=v.get("active",1), notes=v.get("notes",""),
            cat_name=cat.get("name","?"), cat_color=cat.get("color","#888"),
            cat_icon=cat.get("icon","💰"),
        ))
    return sorted(rows, key=lambda r: r["next_due"])


def get_due_recurring(as_of: str) -> list[Row]:
    if not _online:
        return _sqlite.get_due_recurring(as_of) if _sqlite_available else []
    return [r for r in get_recurring()
            if r["active"] == 1 and r["next_due"] <= as_of]


def update_recurring_next_due(rec_id: str, next_due: str) -> None:
    if not _online:
        if _sqlite_available: _sqlite.update_recurring_next_due(rec_id, next_due)
        return
    _patch(f"recurring/{rec_id}", {"next_due": next_due})


def toggle_recurring(rec_id: str) -> None:
    if not _online:
        if _sqlite_available: _sqlite.toggle_recurring(rec_id)
        return
    recs = _get("recurring") or {}
    cur = recs.get(rec_id, {}).get("active", 1)
    _patch(f"recurring/{rec_id}", {"active": 1 - int(cur)})


def delete_recurring(rec_id: str) -> None:
    if not _online:
        if _sqlite_available: _sqlite.delete_recurring(rec_id)
        return
    _delete(f"recurring/{rec_id}")


# ── CSV Import ────────────────────────────────────────────────────────────────
def import_from_csv(filepath: str) -> tuple[int, list[str]]:
    """Import CSV — identical signature to database.import_from_csv."""
    import csv as _csv
    cats = {c["name"].lower(): c["id"] for c in get_all_categories()}
    imported = 0
    errors: list[str] = []

    with open(filepath, newline="", encoding="utf-8-sig") as f:
        reader = _csv.DictReader(f)
        reader.fieldnames = [h.strip().lower()
                             for h in (reader.fieldnames or [])]
        for row_num, row in enumerate(reader, start=2):
            try:
                raw_date = (row.get("date") or row.get("expense_date","")).strip()
                desc     = (row.get("description","")).strip()
                raw_amt  = (row.get("amount","")).strip()
                cat_name = (row.get("category","")).strip().lower()
                payment  = (row.get("payment","UPI")).strip() or "UPI"
                notes    = (row.get("notes","")).strip()

                if not raw_date or not desc or not raw_amt:
                    errors.append(f"Row {row_num}: missing date/description/amount")
                    continue
                try:
                    datetime.strptime(raw_date, "%Y-%m-%d")
                except ValueError:
                    errors.append(f"Row {row_num}: bad date '{raw_date}'")
                    continue
                try:
                    amount = float(raw_amt)
                    assert amount > 0
                except Exception:
                    errors.append(f"Row {row_num}: bad amount '{raw_amt}'")
                    continue

                cat_id = cats.get(cat_name)
                if cat_id is None:
                    matches = [cid for cname, cid in cats.items()
                               if cat_name in cname or cname in cat_name]
                    cat_id = matches[0] if matches else next(iter(cats.values()), None)
                if cat_id is None:
                    errors.append(f"Row {row_num}: no categories exist yet")
                    continue

                add_expense(amount, desc, cat_id, raw_date, payment, notes)
                imported += 1
            except Exception as e:
                errors.append(f"Row {row_num}: error — {e}")

    return imported, errors


# ── Compat shims (kept so old imports don't break) ────────────────────────────
DB_PATH = os.path.join(os.path.dirname(__file__), "..", "expenses.db")


def get_connection():
    """Shim: only valid in SQLite fallback mode."""
    if _sqlite_available:
        return _sqlite.get_connection()
    raise RuntimeError("get_connection() not available in Firebase mode.")
