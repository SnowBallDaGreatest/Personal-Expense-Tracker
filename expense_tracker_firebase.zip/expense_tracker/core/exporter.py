"""
core/exporter.py
────────────────
Sprint 2 — Export engine.

Supports:
  • CSV  – raw tabular data, opens in Excel / Sheets
  • PDF  – formatted summary report with charts embedded as images

Agile note: exporter is completely decoupled from the UI.
Future sprints can add Excel (.xlsx) or JSON by adding a function here.
"""

import csv
import io
import os
import tempfile
from datetime import datetime
from typing import List

# ── CSV ───────────────────────────────────────────────────────────────────────
def export_csv(expenses: list, filepath: str) -> None:
    """Write expenses to a UTF-8 CSV file."""
    fieldnames = ["id", "date", "description", "category", "group",
                  "amount", "payment", "notes"]
    with open(filepath, "w", newline="", encoding="utf-8-sig") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        for e in expenses:
            writer.writerow({
                "id":          e["id"],
                "date":        e["expense_date"],
                "description": e["description"],
                "category":    e["cat_name"],
                "group":       e["group_type"],
                "amount":      f"{e['amount']:.2f}",
                "payment":     e["payment"],
                "notes":       e["notes"] or "",
            })


# ── PDF ───────────────────────────────────────────────────────────────────────
def export_pdf(expenses: list, month: str, stats: dict,
               chart_images: list, filepath: str) -> None:
    """
    Generate a styled PDF summary report.

    Parameters
    ----------
    expenses    : list of sqlite3.Row from get_expenses()
    month       : "YYYY-MM" string
    stats       : dict with keys total, count, avg_day, top_category
    chart_images: list of file paths to PNG chart images
    filepath    : output .pdf path
    """
    from reportlab.lib.pagesizes import A4
    from reportlab.lib import colors
    from reportlab.lib.units import cm
    from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
    from reportlab.platypus import (SimpleDocTemplate, Paragraph, Spacer,
                                     Table, TableStyle, Image, HRFlowable,
                                     KeepTogether)
    from reportlab.lib.enums import TA_CENTER, TA_RIGHT, TA_LEFT

    # ── colours ───────────────────────────────────────────────────────────
    DARK    = colors.HexColor("#0F1117")
    SURFACE = colors.HexColor("#1A1D27")
    ACCENT  = colors.HexColor("#FF8C42")
    TEAL    = colors.HexColor("#2DDCCA")
    MUTED   = colors.HexColor("#8B90B0")
    WHITE   = colors.white
    SUCCESS = colors.HexColor("#4CAF82")
    DANGER  = colors.HexColor("#FF6B6B")

    W, H = A4

    doc = SimpleDocTemplate(
        filepath,
        pagesize=A4,
        rightMargin=1.8*cm, leftMargin=1.8*cm,
        topMargin=2*cm,    bottomMargin=2*cm,
    )

    styles = getSampleStyleSheet()

    def sty(name, **kw):
        return ParagraphStyle(name, parent=styles["Normal"], **kw)

    title_sty   = sty("title",   fontSize=22, textColor=WHITE,
                       fontName="Helvetica-Bold", spaceAfter=4)
    sub_sty     = sty("sub",     fontSize=11, textColor=MUTED,
                       spaceAfter=6)
    h2_sty      = sty("h2",      fontSize=14, textColor=ACCENT,
                       fontName="Helvetica-Bold", spaceBefore=14, spaceAfter=6)
    body_sty    = sty("body",    fontSize=9,  textColor=WHITE)
    caption_sty = sty("caption", fontSize=8,  textColor=MUTED)
    right_sty   = sty("right",   fontSize=9,  textColor=WHITE,
                       alignment=TA_RIGHT)
    center_sty  = sty("center",  fontSize=9,  textColor=MUTED,
                       alignment=TA_CENTER)

    story = []

    # ── header block ──────────────────────────────────────────────────────
    month_label = datetime.strptime(month, "%Y-%m").strftime("%B %Y")
    generated   = datetime.now().strftime("%d %b %Y, %I:%M %p")

    story.append(Paragraph("💸 Expense Report", title_sty))
    story.append(Paragraph(f"{month_label}  ·  Generated {generated}", sub_sty))
    story.append(HRFlowable(width="100%", thickness=1,
                             color=ACCENT, spaceAfter=12))

    # ── KPI cards as a table ──────────────────────────────────────────────
    story.append(Paragraph("Summary", h2_sty))

    def kpi_cell(label, value, color=WHITE):
        return [Paragraph(f"<font color='#{_hex(MUTED)}'>{label}</font>",
                          caption_sty),
                Paragraph(f"<b><font color='#{_hex(color)}'>{value}</font></b>",
                          sty("kv", fontSize=16, fontName="Helvetica-Bold"))]

    kpi_data = [
        [_kpi_para("Total Spent",    f"₹{stats['total']:,.0f}",      ACCENT),
         _kpi_para("Transactions",   str(stats["count"]),             TEAL),
         _kpi_para("Daily Average",  f"₹{stats['avg_day']:,.0f}",    WHITE),
         _kpi_para("Top Category",   stats.get("top_category","—"),  SUCCESS)],
    ]
    kpi_tbl = Table(kpi_data, colWidths=[(W - 3.6*cm) / 4] * 4)
    kpi_tbl.setStyle(TableStyle([
        ("BACKGROUND",  (0,0),(-1,-1), SURFACE),
        ("GRID",        (0,0),(-1,-1), 0.5, colors.HexColor("#2A2F47")),
        ("TOPPADDING",  (0,0),(-1,-1), 10),
        ("BOTTOMPADDING",(0,0),(-1,-1), 10),
        ("LEFTPADDING", (0,0),(-1,-1), 10),
    ]))
    story.append(kpi_tbl)
    story.append(Spacer(1, 14))

    # ── charts ────────────────────────────────────────────────────────────
    if chart_images:
        story.append(Paragraph("Charts", h2_sty))
        available_w = W - 3.6*cm
        for img_path in chart_images:
            if os.path.exists(img_path):
                try:
                    img = Image(img_path, width=available_w, height=available_w * 0.42)
                    story.append(img)
                    story.append(Spacer(1, 8))
                except Exception:
                    pass

    # ── expense table ─────────────────────────────────────────────────────
    story.append(Paragraph("Transactions", h2_sty))

    col_widths = [1.8*cm, 5.5*cm, 3.2*cm, 2.2*cm, 2.0*cm, 1.8*cm]
    headers = ["Date", "Description", "Category", "Group", "Payment", "Amount"]
    tbl_data = [[Paragraph(f"<b>{h}</b>", caption_sty) for h in headers]]

    for e in expenses:
        amt_color = _hex(ACCENT)
        tbl_data.append([
            Paragraph(e["expense_date"], caption_sty),
            Paragraph(e["description"][:40], body_sty),
            Paragraph(f"{e['cat_icon']} {e['cat_name']}", body_sty),
            Paragraph(e["group_type"], caption_sty),
            Paragraph(e["payment"], caption_sty),
            Paragraph(f"<b><font color='#{amt_color}'>₹{e['amount']:,.0f}</font></b>",
                      right_sty),
        ])

    tbl = Table(tbl_data, colWidths=col_widths, repeatRows=1)
    row_bg = [SURFACE, colors.HexColor("#22263A")]
    style_cmds = [
        ("BACKGROUND",    (0,0), (-1,0),  colors.HexColor("#22263A")),
        ("TEXTCOLOR",     (0,0), (-1,0),  MUTED),
        ("GRID",          (0,0), (-1,-1), 0.3, colors.HexColor("#2A2F47")),
        ("FONTNAME",      (0,0), (-1,0),  "Helvetica-Bold"),
        ("FONTSIZE",      (0,0), (-1,-1), 8),
        ("TOPPADDING",    (0,0), (-1,-1), 5),
        ("BOTTOMPADDING", (0,0), (-1,-1), 5),
        ("LEFTPADDING",   (0,0), (-1,-1), 6),
        ("ROWBACKGROUNDS",(0,1), (-1,-1), row_bg),
    ]
    tbl.setStyle(TableStyle(style_cmds))
    story.append(tbl)

    # ── footer ─────────────────────────────────────────────────────────────
    story.append(Spacer(1, 20))
    story.append(HRFlowable(width="100%", thickness=0.5,
                             color=MUTED, spaceAfter=6))
    story.append(Paragraph(
        "Generated by Personal Expense Tracker · Agile Sprint 2",
        center_sty))

    # ── build with dark background ─────────────────────────────────────────
    def _dark_canvas(canvas, doc):
        canvas.saveState()
        canvas.setFillColor(DARK)
        canvas.rect(0, 0, W, H, fill=1, stroke=0)
        canvas.restoreState()

    doc.build(story, onFirstPage=_dark_canvas, onLaterPages=_dark_canvas)


# ── helpers ───────────────────────────────────────────────────────────────────
def _hex(color) -> str:
    """Convert ReportLab color to hex string (without #)."""
    r = int(color.red   * 255)
    g = int(color.green * 255)
    b = int(color.blue  * 255)
    return f"{r:02x}{g:02x}{b:02x}"


def _kpi_para(label: str, value: str, color):
    from reportlab.platypus import Paragraph
    from reportlab.lib.styles import getSampleStyleSheet
    from reportlab.lib import colors
    styles = getSampleStyleSheet()
    MUTED  = colors.HexColor("#8B90B0")
    h = _hex(color)
    txt = (f"<para>"
           f"<font size='8' color='#{_hex(MUTED)}'>{label}</font><br/>"
           f"<font size='16' color='#{h}'><b>{value}</b></font>"
           f"</para>")
    from reportlab.lib.styles import ParagraphStyle
    sty = ParagraphStyle("kpi", parent=styles["Normal"], leading=20)
    return Paragraph(txt, sty)
