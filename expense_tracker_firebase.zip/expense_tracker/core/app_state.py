"""
core/app_state.py  — Sprint 4 revised
──────────────────────────────────────
Global singleton: theme, currency (with live FX conversion), event bus.

Theme switching
───────────────
  AppState.set_theme("light")  — instantly recolours all widgets

Currency conversion
───────────────────
  AppState.set_currency("$")
  AppState.fmt_money(500)   →  "$6"  (500 INR ÷ 83 = ~6 USD)

  Exchange rates vs INR are stored in EXCHANGE_RATES.
  All amounts in the DB are stored in INR.
  fmt_money() converts to the active currency on display.
"""

from typing import Callable, Dict, List

# ── Exchange rates (INR base — 1 INR = X foreign unit) ───────────────────────
# Approximate mid-market rates; update periodically or fetch live (see below)
EXCHANGE_RATES: Dict[str, float] = {
    "₹": 1.0,           # base — no conversion
    "$": 1 / 83.5,      # 1 USD = ~83.5 INR
    "€": 1 / 90.2,      # 1 EUR = ~90.2 INR
    "£": 1 / 105.8,     # 1 GBP = ~105.8 INR
    "¥": 1 / 0.55,      # 1 JPY = ~0.55 INR  (so 1 INR ≈ 1.82 ¥)
}

CURRENCY_DECIMALS: Dict[str, int] = {
    "₹": 0,
    "$": 2,
    "€": 2,
    "£": 2,
    "¥": 0,
}

CURRENCY_NAMES: Dict[str, str] = {
    "₹": "Indian Rupee",
    "$": "US Dollar",
    "€": "Euro",
    "£": "British Pound",
    "¥": "Japanese Yen",
}

# ── Colour palettes ───────────────────────────────────────────────────────────
DARK_PALETTE = {
    "bg_primary":     "#0F1117",
    "bg_surface":     "#1A1D27",
    "bg_raised":      "#22263A",
    "bg_hover":       "#2A2F47",
    "bg_input":       "#14172B",
    "text_primary":   "#E8EAF6",
    "text_secondary": "#8B90B0",
    "text_muted":     "#555A7A",
    "text_on_accent": "#FFFFFF",
    "accent":         "#FF8C42",
    "accent_hover":   "#FF6B1A",
    "accent_light":   "#3D2510",
    "teal":           "#2DDCCA",
    "teal_light":     "#0D3533",
    "success":        "#4CAF82",
    "warning":        "#FFB347",
    "danger":         "#FF6B6B",
    "info":           "#5B9CF6",
    "border":         "#2A2F47",
    "border_focus":   "#FF8C42",
    "needs":          "#5B9CF6",
    "wants":          "#C39BD3",
    "savings":        "#4CAF82",
}

LIGHT_PALETTE = {
    "bg_primary":     "#F4F5F7",
    "bg_surface":     "#FFFFFF",
    "bg_raised":      "#EAECF0",
    "bg_hover":       "#DDE0E8",
    "bg_input":       "#F9FAFB",
    "text_primary":   "#1A1D27",
    "text_secondary": "#4A4F6A",
    "text_muted":     "#8B90B0",
    "text_on_accent": "#FFFFFF",
    "accent":         "#E07020",
    "accent_hover":   "#C05010",
    "accent_light":   "#FDE8D4",
    "teal":           "#009B8D",
    "teal_light":     "#CCF0EC",
    "success":        "#2E7D50",
    "warning":        "#B37000",
    "danger":         "#C0392B",
    "info":           "#1565C0",
    "border":         "#C8CDD8",
    "border_focus":   "#E07020",
    "needs":          "#1565C0",
    "wants":          "#7B3F9E",
    "savings":        "#2E7D50",
}

VALID_CURRENCIES = set(EXCHANGE_RATES.keys())


# ── AppState singleton ────────────────────────────────────────────────────────
class _AppState:
    def __init__(self):
        self._theme    = "dark"
        self._currency = "₹"
        self._listeners: Dict[str, List[Callable]] = {
            "theme": [], "currency": [],
        }
        self.colors = dict(DARK_PALETTE)

    # ── theme ─────────────────────────────────────────────────────────────────
    @property
    def theme(self) -> str:
        return self._theme

    def set_theme(self, value: str) -> None:
        if value not in ("dark", "light"):
            return
        self._theme = value
        self.colors.update(DARK_PALETTE if value == "dark" else LIGHT_PALETTE)
        self._fire("theme", value)

    def is_dark(self) -> bool:
        return self._theme == "dark"

    # ── currency ──────────────────────────────────────────────────────────────
    @property
    def currency(self) -> str:
        return self._currency

    def set_currency(self, sym: str) -> None:
        if sym not in VALID_CURRENCIES:
            return
        self._currency = sym
        self._fire("currency", sym)

    def convert(self, inr_amount: float) -> float:
        """Convert an INR amount to the active currency."""
        rate = EXCHANGE_RATES.get(self._currency, 1.0)
        return inr_amount * rate

    def fmt_money(self, inr_value: float) -> str:
        """
        Convert inr_value from INR to active currency and format it.
        e.g. fmt_money(8350) with currency='$' → '$100.00'
        """
        converted = self.convert(inr_value)
        decimals  = CURRENCY_DECIMALS.get(self._currency, 2)
        if decimals == 0:
            return f"{self._currency}{converted:,.0f}"
        return f"{self._currency}{converted:,.{decimals}f}"

    def update_rate(self, sym: str, inr_per_unit: float) -> None:
        """
        Allow the user to set a custom exchange rate.
        inr_per_unit: how many INR = 1 unit of sym
        e.g. update_rate('$', 83.5) means 1 USD = 83.5 INR
        """
        if sym in EXCHANGE_RATES and inr_per_unit > 0:
            EXCHANGE_RATES[sym] = 1.0 / inr_per_unit
            if self._currency == sym:
                self._fire("currency", sym)   # triggers UI refresh

    # ── event bus ─────────────────────────────────────────────────────────────
    def subscribe(self, event: str, callback: Callable) -> None:
        if event in self._listeners:
            self._listeners[event].append(callback)

    def unsubscribe(self, event: str, callback: Callable) -> None:
        if event in self._listeners and callback in self._listeners[event]:
            self._listeners[event].remove(callback)

    def _fire(self, event: str, value) -> None:
        for cb in list(self._listeners.get(event, [])):
            try:
                cb(value)
            except Exception as e:
                print(f"[AppState] event error '{event}': {e}")

    def __getattr__(self, name: str) -> str:
        if name.startswith("_") or name in ("colors", "theme", "currency"):
            raise AttributeError(name)
        if name in self.colors:
            return self.colors[name]
        raise AttributeError(f"AppState has no attribute '{name}'")


AppState = _AppState()


# ── Theme applier — full widget tree recolor ──────────────────────────────────
def apply_theme_to_widget(widget, theme: str) -> None:
    """
    Walk every Tkinter widget and swap every colour token to the new theme.
    Works on ALL tk and ttk widgets. Handles fg/bg/selectcolor/etc.
    """
    old_pal = DARK_PALETTE if theme == "light" else LIGHT_PALETTE
    new_pal = LIGHT_PALETTE if theme == "light" else DARK_PALETTE
    remap   = {v: new_pal[k] for k, v in old_pal.items() if k in new_pal}

    # also handle common near-black/near-white hardcodes that aren't in palette
    extra = {}
    if theme == "light":
        extra.update({
            "#000000": new_pal["text_primary"],
            "#FFFFFF": new_pal["bg_surface"],
            "black":   new_pal["text_primary"],
            "white":   new_pal["bg_surface"],
        })
    else:
        extra.update({
            "#000000": new_pal["text_primary"],
            "#FFFFFF": new_pal["bg_surface"],
            "black":   new_pal["text_primary"],
            "white":   new_pal["bg_surface"],
        })
    remap.update(extra)

    _recolor_widget(widget, remap)


def _recolor_widget(widget, remap: dict) -> None:
    """Recursively recolor a widget and all its children."""
    COLOUR_OPTS = (
        "bg", "fg",
        "background", "foreground",
        "selectcolor", "selectbackground", "selectforeground",
        "activebackground", "activeforeground",
        "disabledforeground",
        "highlightbackground", "highlightcolor",
        "insertbackground",
        "troughcolor", "fieldbackground",
        "readonlybackground",
    )

    for opt in COLOUR_OPTS:
        try:
            cur = str(widget.cget(opt)).lower()
            # Exact match
            if cur in remap:
                widget.configure(**{opt: remap[cur]})
            else:
                # Try original-case match too
                cur_orig = widget.cget(opt)
                if isinstance(cur_orig, str) and cur_orig in remap:
                    widget.configure(**{opt: remap[cur_orig]})
        except Exception:
            pass

    # ttk widgets: configure via style
    try:
        import tkinter.ttk as ttk
        if isinstance(widget, ttk.Widget):
            _recolor_ttk(widget, remap)
    except Exception:
        pass

    for child in widget.winfo_children():
        _recolor_widget(child, remap)


def _recolor_ttk(widget, remap: dict) -> None:
    """Apply colour remap to ttk widget style."""
    try:
        import tkinter.ttk as ttk
        s = ttk.Style()
        style_name = widget.cget("style") or widget.winfo_class()
        for opt in ("background", "foreground", "fieldbackground",
                    "selectbackground", "selectforeground",
                    "troughcolor", "arrowcolor"):
            try:
                cur = s.lookup(style_name, opt)
                if cur and str(cur).lower() in remap:
                    s.configure(style_name, **{opt: remap[str(cur).lower()]})
                elif cur and str(cur) in remap:
                    s.configure(style_name, **{opt: remap[str(cur)]})
            except Exception:
                pass
    except Exception:
        pass
