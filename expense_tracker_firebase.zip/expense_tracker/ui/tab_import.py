"""
ui/tab_import.py
────────────────
Sprint 3 — CSV Import Panel.

Features:
  • File picker for CSV
  • Preview first 10 rows before importing
  • Validate and show errors per row
  • Import with success/error summary
  • Download a CSV template
"""

import os
import csv
import tkinter as tk
from tkinter import filedialog, messagebox
from datetime import date

from core.theme import P, TY, SP
from core import database as db
from ui.widgets import StyledButton, Toast, ScrollableFrame


def _fmt(v: float) -> str:
    from core.app_state import AppState
    return AppState.fmt_money(v)



TEMPLATE_HEADERS = ["date", "description", "amount", "category",
                     "payment", "notes"]
TEMPLATE_ROWS = [
    [date.today().isoformat(), "Sample expense", "500",
     "Food & Dining", "UPI", "lunch"],
    ["2025-03-15", "Electricity bill", "1200",
     "Utilities", "Net Banking", ""],
]


class ImportTab(tk.Frame):

    def __init__(self, master, on_imported: callable = None, **kw):
        super().__init__(master, bg=P.bg_primary, **kw)
        self._on_imported = on_imported
        self._csv_path: str = ""
        self._preview_rows: list = []
        self._build()

    # ── public ───────────────────────────────────────────────────────────────
    def refresh(self):
        pass

    # ── build ─────────────────────────────────────────────────────────────────
    def _build(self):
        hdr = tk.Frame(self, bg=P.bg_primary, padx=SP.lg, pady=SP.md)
        hdr.pack(fill="x")
        tk.Label(hdr, text="📥  Import from CSV", bg=P.bg_primary,
                 fg=P.text_primary, font=TY.h2()).pack(side="left")

        scroll = ScrollableFrame(self, bg=P.bg_primary)
        scroll.pack(fill="both", expand=True)
        body = scroll.inner

        # ── instructions card ─────────────────────────────────────────────
        info = tk.Frame(body, bg=P.bg_surface,
                        highlightthickness=1, highlightbackground=P.border,
                        padx=SP.xl, pady=SP.lg)
        info.pack(fill="x", padx=SP.lg, pady=(0, SP.md))

        tk.Label(info, text="How it works", bg=P.bg_surface,
                 fg=P.text_primary, font=TY.h3()).pack(anchor="w")

        steps = [
            "1. Download the CSV template below to see the required format.",
            "2. Fill in your expenses — one row per transaction.",
            "3. Required columns: date (YYYY-MM-DD), description, amount.",
            "4. Optional columns: category, payment, notes.",
            "5. Category names are matched to your existing categories (fuzzy match).",
            "6. Select your file and click Import.",
        ]
        for s in steps:
            tk.Label(info, text=s, bg=P.bg_surface, fg=P.text_secondary,
                     font=TY.body()).pack(anchor="w")

        btn_row = tk.Frame(info, bg=P.bg_surface)
        btn_row.pack(fill="x", pady=(SP.md, 0))
        StyledButton(btn_row, "⬇  Download CSV Template",
                     self._download_template, variant="secondary").pack(
            side="left")

        # ── file selector ─────────────────────────────────────────────────
        file_card = tk.Frame(body, bg=P.bg_surface,
                             highlightthickness=1, highlightbackground=P.border,
                             padx=SP.xl, pady=SP.lg)
        file_card.pack(fill="x", padx=SP.lg, pady=(0, SP.md))

        tk.Label(file_card, text="Select CSV File", bg=P.bg_surface,
                 fg=P.text_primary, font=TY.h3()).pack(anchor="w",
                                                         pady=(0, SP.sm))

        pick_row = tk.Frame(file_card, bg=P.bg_surface)
        pick_row.pack(fill="x")

        self._file_lbl = tk.Label(pick_row, text="No file selected",
                                   bg=P.bg_input, fg=P.text_muted,
                                   font=TY.body(), anchor="w", padx=SP.sm,
                                   highlightthickness=1,
                                   highlightbackground=P.border)
        self._file_lbl.pack(side="left", fill="x", expand=True,
                             ipady=6, padx=(0, SP.sm))
        StyledButton(pick_row, "📂  Browse",
                     self._pick_file, variant="secondary").pack(side="left")

        # import button
        self._import_btn = StyledButton(file_card, "📥  Import Expenses",
                                         self._do_import, variant="primary")
        self._import_btn.pack(anchor="w", pady=(SP.md, 0))

        # ── preview table ─────────────────────────────────────────────────
        self._preview_title = tk.Label(body, text="",
                                        bg=P.bg_primary, fg=P.text_secondary,
                                        font=TY.label(), padx=SP.lg)
        self._preview_title.pack(anchor="w")

        self._preview_frame = tk.Frame(body, bg=P.bg_primary, padx=SP.lg)
        self._preview_frame.pack(fill="x", pady=(0, SP.md))

        # ── error log ─────────────────────────────────────────────────────
        self._err_title = tk.Label(body, text="",
                                    bg=P.bg_primary, fg=P.danger,
                                    font=TY.label(), padx=SP.lg)
        self._err_title.pack(anchor="w")

        self._err_frame = tk.Frame(body, bg=P.bg_primary, padx=SP.lg)
        self._err_frame.pack(fill="x", pady=(0, SP.lg))

    # ── actions ───────────────────────────────────────────────────────────────
    def _pick_file(self):
        fp = filedialog.askopenfilename(
            filetypes=[("CSV files", "*.csv"), ("All files", "*.*")],
            title="Select CSV file to import")
        if not fp:
            return
        self._csv_path = fp
        self._file_lbl.configure(text=os.path.basename(fp),
                                  fg=P.text_primary)
        self._load_preview(fp)

    def _load_preview(self, filepath: str):
        for w in self._preview_frame.winfo_children():
            w.destroy()
        for w in self._err_frame.winfo_children():
            w.destroy()

        try:
            with open(filepath, newline="", encoding="utf-8-sig") as f:
                reader = csv.reader(f)
                rows = list(reader)
        except Exception as e:
            self._preview_title.configure(text=f"Error reading file: {e}")
            return

        if not rows:
            self._preview_title.configure(text="File is empty.")
            return

        headers = [h.strip().lower() for h in rows[0]]
        data    = rows[1:]
        self._preview_rows = data

        self._preview_title.configure(
            text=f"Preview — {len(data)} rows detected:")

        # header row
        hdr_f = tk.Frame(self._preview_frame, bg=P.bg_raised)
        hdr_f.pack(fill="x")
        for h in headers[:6]:
            tk.Label(hdr_f, text=h.title(), bg=P.bg_raised,
                     fg=P.text_secondary, font=TY.label(),
                     width=16, anchor="w", padx=SP.xs).pack(side="left")

        for i, row in enumerate(data[:10]):
            bg = P.bg_surface if i % 2 == 0 else P.bg_raised
            row_f = tk.Frame(self._preview_frame, bg=bg)
            row_f.pack(fill="x")
            for cell in (row + [""] * 6)[:6]:
                tk.Label(row_f, text=str(cell)[:20], bg=bg,
                         fg=P.text_primary, font=TY.caption(),
                         width=16, anchor="w", padx=SP.xs,
                         pady=3).pack(side="left")

        if len(data) > 10:
            tk.Label(self._preview_frame,
                     text=f"… and {len(data)-10} more rows",
                     bg=P.bg_primary, fg=P.text_muted,
                     font=TY.caption()).pack(anchor="w", pady=SP.xs)

    def _do_import(self):
        if not self._csv_path:
            messagebox.showinfo("No file", "Please select a CSV file first.")
            return
        if not os.path.exists(self._csv_path):
            messagebox.showerror("Error", "File not found.")
            return

        # confirm
        n_rows = len(self._preview_rows)
        if not messagebox.askyesno(
                "Confirm Import",
                f"Import up to {n_rows} expense(s) from:\n"
                f"{os.path.basename(self._csv_path)}\n\n"
                "Continue?"):
            return

        Toast(self.winfo_toplevel(), "Importing…", "info", 1500)
        self.update()

        imported, errors = db.import_from_csv(self._csv_path)

        # show errors
        for w in self._err_frame.winfo_children():
            w.destroy()
        if errors:
            self._err_title.configure(
                text=f"{len(errors)} row(s) had errors:")
            for err in errors[:15]:
                tk.Label(self._err_frame, text=f"  ⚠ {err}",
                         bg=P.bg_primary, fg=P.warning,
                         font=TY.caption()).pack(anchor="w")
        else:
            self._err_title.configure(text="")

        # result
        if imported:
            Toast(self.winfo_toplevel(),
                  f"✓ {imported} expense(s) imported!", "success", 3000)
            if self._on_imported:
                self._on_imported()
        else:
            messagebox.showwarning("Import result",
                                   "No expenses were imported.\n"
                                   "Check errors above.")

    def _download_template(self):
        fp = filedialog.asksaveasfilename(
            defaultextension=".csv",
            filetypes=[("CSV files", "*.csv"), ("All files", "*.*")],
            initialfile="expense_import_template.csv",
            title="Save template")
        if not fp:
            return
        with open(fp, "w", newline="", encoding="utf-8-sig") as f:
            writer = csv.writer(f)
            writer.writerow(TEMPLATE_HEADERS)
            writer.writerows(TEMPLATE_ROWS)
        Toast(self.winfo_toplevel(),
              f"Template saved: {os.path.basename(fp)}", "success")