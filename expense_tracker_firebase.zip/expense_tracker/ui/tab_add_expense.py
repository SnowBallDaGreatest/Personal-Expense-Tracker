"""
ui/tab_add_expense.py
─────────────────────
Add / Edit expense form panel with full validation.

Agile note: the form fields list at the top makes it trivial to
add new fields in future sprints (e.g., receipt image, location).
"""

import tkinter as tk
from tkinter import ttk, messagebox
from datetime import date
from typing import Optional, Callable

from core.theme import P, TY, SP
from core import database as db
from core.theme import PAYMENT_METHODS
from ui.widgets import StyledButton, Toast


def _label(parent, text, row, col, colspan=1):
    tk.Label(parent, text=text, bg=P.bg_surface, fg=P.text_secondary,
             font=TY.label()).grid(row=row, column=col, columnspan=colspan,
                                   sticky="w", pady=(SP.sm, 2))


def _entry(parent, var, row, col, colspan=1, width=24, num=False):
    vcmd = (parent.register(lambda s: s.replace(".", "", 1).isdigit() or s == ""),
            "%P") if num else None
    e = tk.Entry(parent, textvariable=var,
                 bg=P.bg_input, fg=P.text_primary,
                 insertbackground=P.accent, relief="flat",
                 font=TY.body(), width=width,
                 highlightthickness=1,
                 highlightbackground=P.border,
                 highlightcolor=P.border_focus,
                 **({"validate": "key", "validatecommand": vcmd} if vcmd else {}))
    e.grid(row=row, column=col, columnspan=colspan,
           sticky="ew", padx=(0, SP.sm), ipady=6)
    return e


def _combo(parent, var, values, row, col, colspan=1, width=22, readonly=True):
    s = ttk.Style()
    sn = f"Dark{row}{col}.TCombobox"
    s.configure(sn, fieldbackground=P.bg_input, background=P.bg_raised,
                foreground=P.text_primary, arrowcolor=P.accent)
    cb = ttk.Combobox(parent, textvariable=var, values=values,
                      state="readonly" if readonly else "normal",
                      width=width, style=sn)
    cb.grid(row=row, column=col, columnspan=colspan,
            sticky="ew", padx=(0, SP.sm), pady=2)
    return cb


class AddExpenseTab(tk.Frame):

    def __init__(self, master, on_saved: Callable = None, **kw):
        super().__init__(master, bg=P.bg_primary, **kw)
        self._on_saved = on_saved
        self._edit_id: Optional[int] = None   # None = add mode
        self._categories: list = []
        self._build()
        self._load_categories()

    # ── public ──────────────────────────────────────────────────────────────
    def refresh(self):
        self._load_categories()

    def load_for_edit(self, expense_row) -> None:
        """Pre-populate form for editing an existing expense."""
        self._edit_id = expense_row["id"]
        self._v_amount.set(str(expense_row["amount"]))
        self._v_desc.set(expense_row["description"])
        self._v_date.set(expense_row["expense_date"])
        self._v_payment.set(expense_row["payment"])
        self._v_notes.set(expense_row["notes"])

        # select category
        cat_names = [c["name"] for c in self._categories]
        if expense_row["cat_name"] in cat_names:
            self._v_cat.set(expense_row["cat_name"])

        self._title_lbl.configure(text="✏️  Edit Expense")
        self._save_btn.configure_command(self._save)

    def clear_form(self) -> None:
        self._edit_id = None
        self._v_amount.set("")
        self._v_desc.set("")
        self._v_date.set(date.today().isoformat())
        self._v_payment.set("UPI")
        self._v_notes.set("")
        self._title_lbl.configure(text="➕  Add Expense")
        if self._categories:
            self._v_cat.set(self._categories[0]["name"])

    # ── build ────────────────────────────────────────────────────────────────
    def _build(self):
        # ── header ─────────────────────────────────────────────────────────
        hdr = tk.Frame(self, bg=P.bg_primary, padx=SP.lg, pady=SP.md)
        hdr.pack(fill="x")
        self._title_lbl = tk.Label(hdr, text="➕  Add Expense",
                                   bg=P.bg_primary, fg=P.text_primary,
                                   font=TY.h2())
        self._title_lbl.pack(side="left")

        # ── form card ──────────────────────────────────────────────────────
        card = tk.Frame(self, bg=P.bg_surface,
                        highlightthickness=1,
                        highlightbackground=P.border,
                        padx=SP.xl, pady=SP.xl)
        card.pack(fill="both", expand=False, padx=SP.lg, pady=(0, SP.md))
        card.columnconfigure((0, 1, 2, 3), weight=1)

        self._v_amount  = tk.StringVar()
        self._v_desc    = tk.StringVar()
        self._v_cat     = tk.StringVar()
        self._v_date    = tk.StringVar(value=date.today().isoformat())
        self._v_payment = tk.StringVar(value="UPI")
        self._v_notes   = tk.StringVar()

        # row 0 – labels
        _label(card, "Amount (₹) *",    0, 0)
        _label(card, "Description *",   0, 1, 2)
        _label(card, "Date *",          0, 3)

        # row 1 – entries
        _entry(card, self._v_amount,  1, 0, num=True, width=14)
        _entry(card, self._v_desc,    1, 1, colspan=2, width=32)
        _entry(card, self._v_date,    1, 3, width=14)

        # row 2 – labels
        _label(card, "Category *",    2, 0, 2)
        _label(card, "Payment",       2, 2)
        _label(card, "Notes",         2, 3)

        # row 3 – dropdowns + notes
        self._cat_cb = _combo(card, self._v_cat, [], 3, 0, colspan=2)
        _combo(card, self._v_payment, PAYMENT_METHODS, 3, 2)
        _entry(card, self._v_notes,  3, 3, width=22)

        # ── group indicator ────────────────────────────────────────────────
        self._group_lbl = tk.Label(card, text="",
                                   bg=P.bg_surface, fg=P.text_muted,
                                   font=TY.caption())
        self._group_lbl.grid(row=4, column=0, columnspan=4, sticky="w",
                              pady=(SP.xs, 0))
        self._cat_cb.bind("<<ComboboxSelected>>", self._on_cat_change)

        # ── buttons ────────────────────────────────────────────────────────
        btn_row = tk.Frame(card, bg=P.bg_surface, pady=SP.md)
        btn_row.grid(row=5, column=0, columnspan=4, sticky="ew")

        self._save_btn = StyledButton(btn_row, "💾  Save Expense",
                                      self._save, variant="primary")
        self._save_btn.pack(side="left")
        StyledButton(btn_row, "✖  Clear", self.clear_form,
                     variant="ghost").pack(side="left", padx=SP.sm)

        # ── quick tips ─────────────────────────────────────────────────────
        tips = tk.Frame(self, bg=P.bg_primary, padx=SP.lg)
        tips.pack(fill="x")
        tk.Label(tips, text="💡 Tips", bg=P.bg_primary, fg=P.accent,
                 font=TY.label()).pack(anchor="w")
        tip_lines = [
            "• Date format: YYYY-MM-DD  (e.g. 2025-04-10)",
            "• Amount in Indian Rupees (₹)",
            "• Categories are grouped into Needs / Wants / Savings-Debt",
            "• Add budgets from the Budget tab to track limits",
        ]
        for t in tip_lines:
            tk.Label(tips, text=t, bg=P.bg_primary, fg=P.text_muted,
                     font=TY.caption()).pack(anchor="w")

    # ── internals ────────────────────────────────────────────────────────────
    def _load_categories(self):
        self._categories = db.get_all_categories()
        names = [c["name"] for c in self._categories]
        self._cat_cb["values"] = names
        if names and not self._v_cat.get():
            self._v_cat.set(names[0])
            self._update_group_label()

    def _on_cat_change(self, _e=None):
        self._update_group_label()

    def _update_group_label(self):
        name = self._v_cat.get()
        for c in self._categories:
            if c["name"] == name:
                gcolors = {"Needs": P.needs, "Wants": P.wants,
                           "Savings/Debt": P.savings}
                col = gcolors.get(c["group_type"], P.text_muted)
                self._group_lbl.configure(
                    text=f"Group: {c['group_type']}  {c['icon']}",
                    fg=col)
                break

    def _validate(self) -> Optional[dict]:
        errs = []

        raw_amt = self._v_amount.get().strip()
        if not raw_amt:
            errs.append("Amount is required.")
        else:
            try:
                amt = float(raw_amt)
                if amt <= 0:
                    raise ValueError
            except ValueError:
                errs.append("Amount must be a positive number.")

        if not self._v_desc.get().strip():
            errs.append("Description is required.")
        if not self._v_cat.get():
            errs.append("Category is required.")

        raw_date = self._v_date.get().strip()
        from datetime import datetime
        try:
            datetime.strptime(raw_date, "%Y-%m-%d")
        except ValueError:
            errs.append("Date must be YYYY-MM-DD.")

        if errs:
            messagebox.showerror("Validation Error", "\n".join(errs))
            return None

        cat_id = next(
            (c["id"] for c in self._categories
             if c["name"] == self._v_cat.get()), None)
        if cat_id is None:
            messagebox.showerror("Error", "Invalid category.")
            return None

        return {
            "amount":      float(self._v_amount.get()),
            "description": self._v_desc.get().strip(),
            "category_id": cat_id,
            "expense_date": self._v_date.get().strip(),
            "payment":     self._v_payment.get(),
            "notes":       self._v_notes.get().strip(),
        }

    def _save(self):
        data = self._validate()
        if not data:
            return

        if self._edit_id:
            db.update_expense(self._edit_id, **data)
            msg = "Expense updated!"
        else:
            db.add_expense(**data)
            msg = "Expense added!"

        self.clear_form()
        Toast(self.winfo_toplevel(), msg, "success")
        if self._on_saved:
            self._on_saved()
