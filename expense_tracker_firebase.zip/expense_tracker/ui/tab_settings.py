"""
ui/tab_settings.py  (Sprint 4 revised)
───────────────────────────────────────
• Live dark/light theme  (full widget recolor, fonts + backgrounds)
• Live currency with real INR conversion  (₹500 = $5.99 @ 83.5 rate)
• Editable exchange rates
• Firebase / SQLite status
• DB backup / restore / wipe
"""

import json, os, shutil
import tkinter as tk
from tkinter import filedialog, messagebox
from datetime import datetime

from core.theme    import P, TY, SP, PAYMENT_METHODS
from core.app_state import (AppState, apply_theme_to_widget,
                             EXCHANGE_RATES, CURRENCY_NAMES,
                             DARK_PALETTE, LIGHT_PALETTE)
from ui.widgets    import StyledButton, Toast, ScrollableFrame

SETTINGS_FILE = os.path.join(os.path.dirname(__file__), "..", "settings.json")

DEFAULT_SETTINGS = {
    "theme": "dark", "currency": "₹",
    "default_payment": "UPI", "show_tips": True, "rows_per_page": 50,
    "custom_rates": {},
}


def load_settings() -> dict:
    if os.path.exists(SETTINGS_FILE):
        try:
            with open(SETTINGS_FILE) as f:
                return {**DEFAULT_SETTINGS, **json.load(f)}
        except Exception:
            pass
    return DEFAULT_SETTINGS.copy()


def save_settings(settings: dict) -> None:
    with open(SETTINGS_FILE, "w") as f:
        json.dump(settings, f, indent=2)


class SettingsTab(tk.Frame):
    VERSION = "4.1.0"

    def __init__(self, master,
                 on_theme_change=None,
                 on_currency_change=None, **kw):
        super().__init__(master, bg=P.bg_primary, **kw)
        self._on_theme_change    = on_theme_change
        self._on_currency_change = on_currency_change
        self._settings = load_settings()
        self._rate_vars = {}      # sym → StringVar for editable rates

        # Restore custom rates into AppState
        for sym, rate_str in self._settings.get("custom_rates", {}).items():
            try:
                AppState.update_rate(sym, float(rate_str))
            except Exception:
                pass

        # Sync AppState from saved settings
        AppState.set_theme(self._settings["theme"])
        AppState.set_currency(self._settings["currency"])

        self._build()

    # ── public ───────────────────────────────────────────────────────────────
    def refresh(self):
        pass

    def get_settings(self) -> dict:
        return self._settings.copy()

    # ── build ─────────────────────────────────────────────────────────────────
    def _build(self):
        hdr = tk.Frame(self, bg=P.bg_primary, padx=SP.lg, pady=SP.md)
        hdr.pack(fill="x")
        tk.Label(hdr, text="⚙️  Settings", bg=P.bg_primary,
                 fg=P.text_primary, font=TY.h2()).pack(side="left")

        scroll = ScrollableFrame(self, bg=P.bg_primary)
        scroll.pack(fill="both", expand=True)
        body = scroll.inner

        # ── APPEARANCE ───────────────────────────────────────────────────
        self._section(body, "🎨  Appearance")
        ap_card = self._card(body)

        # Theme
        self._row(ap_card, "Theme",
                  "Switches immediately — backgrounds AND text colours update.")
        self._v_theme = tk.StringVar(value=self._settings["theme"])
        theme_row = tk.Frame(ap_card, bg=P.bg_surface)
        theme_row.pack(anchor="w", pady=(SP.xs, SP.sm))
        self._theme_btns = {}
        for val, emoji, label in [("dark","🌙","Dark"), ("light","☀️","Light")]:
            is_active = (self._settings["theme"] == val)
            btn = tk.Label(theme_row,
                           text=f"  {emoji}  {label}  ",
                           bg=P.accent if is_active else P.bg_raised,
                           fg=P.text_on_accent if is_active else P.text_secondary,
                           font=TY.body(), cursor="hand2",
                           padx=SP.sm, pady=SP.xs)
            btn.pack(side="left", padx=(0, SP.xs))
            btn._val = val
            btn.bind("<Button-1>", lambda e, v=val: self._apply_theme(v))
            self._theme_btns[val] = btn

        # ── CURRENCY ─────────────────────────────────────────────────────
        self._section(body, "💱  Currency & Exchange Rates")
        cur_card = self._card(body)

        tk.Label(cur_card,
                 text="All amounts are stored in ₹ INR. Selecting another currency\n"
                      "converts the displayed value using the rates below.",
                 bg=P.bg_surface, fg=P.text_muted,
                 font=TY.caption(), justify="left").pack(anchor="w",
                                                          pady=(0, SP.sm))

        # Currency selector row
        self._row(cur_card, "Active Currency", "Click to switch:")
        cur_sel = tk.Frame(cur_card, bg=P.bg_surface)
        cur_sel.pack(anchor="w", pady=(SP.xs, SP.md))
        self._cur_btns = {}
        for sym in ["₹", "$", "€", "£", "¥"]:
            is_active = (self._settings["currency"] == sym)
            btn = tk.Label(cur_sel,
                           text=f"  {sym}  ",
                           bg=P.accent if is_active else P.bg_raised,
                           fg=P.text_on_accent if is_active else P.text_secondary,
                           font=(TY.family, TY.size_xl), cursor="hand2",
                           padx=SP.xs, pady=4)
            btn.pack(side="left", padx=(0, SP.xs))
            btn._sym = sym
            btn.bind("<Button-1>", lambda e, s=sym: self._apply_currency(s))
            self._cur_btns[sym] = btn

        # Exchange rates table
        self._row(cur_card, "Exchange Rates  (1 unit = ? INR)",
                  "Edit to set custom rates, then press Enter or click Save.")

        rate_frame = tk.Frame(cur_card, bg=P.bg_surface)
        rate_frame.pack(fill="x", pady=(SP.xs, SP.sm))

        for col, hdr_txt in enumerate(["Currency", "Name", "Rate (1 X = ? ₹)", "Example"]):
            tk.Label(rate_frame, text=hdr_txt, bg=P.bg_raised,
                     fg=P.text_secondary, font=TY.label(),
                     padx=SP.sm, pady=4, width=18,
                     anchor="w").grid(row=0, column=col, sticky="ew",
                                      padx=1, pady=(0, 2))

        self._rate_vars = {}
        self._example_labels = {}
        for i, sym in enumerate(["$", "€", "£", "¥"], start=1):
            inr_per_unit = round(1.0 / EXCHANGE_RATES[sym], 2)

            tk.Label(rate_frame, text=f"  {sym}", bg=P.bg_surface,
                     fg=P.accent, font=(TY.family, TY.size_lg),
                     width=8, anchor="w").grid(row=i, column=0, sticky="ew",
                                               padx=1, pady=2)
            tk.Label(rate_frame, text=CURRENCY_NAMES[sym], bg=P.bg_surface,
                     fg=P.text_primary, font=TY.body(),
                     width=18, anchor="w").grid(row=i, column=1, sticky="ew",
                                                padx=1, pady=2)

            var = tk.StringVar(value=str(inr_per_unit))
            self._rate_vars[sym] = var
            entry = tk.Entry(rate_frame, textvariable=var,
                             bg=P.bg_input, fg=P.text_primary,
                             insertbackground=P.accent, relief="flat",
                             font=TY.body(), width=14,
                             highlightthickness=1,
                             highlightbackground=P.border,
                             highlightcolor=P.border_focus)
            entry.grid(row=i, column=2, sticky="ew", padx=(4, 2), pady=2,
                       ipady=4)
            entry.bind("<Return>",   lambda e, s=sym: self._save_rate(s))
            entry.bind("<FocusOut>", lambda e, s=sym: self._save_rate(s))

            # Example label: 1000 INR = X sym
            ex_lbl = tk.Label(rate_frame, text=self._example_text(sym),
                              bg=P.bg_surface, fg=P.text_muted,
                              font=TY.caption(), width=20, anchor="w")
            ex_lbl.grid(row=i, column=3, sticky="ew", padx=(4, 0), pady=2)
            self._example_labels[sym] = ex_lbl

        StyledButton(cur_card, "💾  Save All Rates",
                     self._save_all_rates, variant="secondary").pack(
            anchor="w", pady=(SP.sm, 0))

        # ── DEFAULTS ─────────────────────────────────────────────────────
        self._section(body, "🔧  Defaults")
        def_card = self._card(body)
        self._row(def_card, "Default Payment Method", "Pre-selected on Add Expense.")
        self._v_payment = tk.StringVar(value=self._settings["default_payment"])
        pay_row = tk.Frame(def_card, bg=P.bg_surface)
        pay_row.pack(anchor="w", pady=(0, SP.sm))
        for pm in PAYMENT_METHODS:
            tk.Radiobutton(pay_row, text=pm, variable=self._v_payment, value=pm,
                           bg=P.bg_surface, fg=P.text_primary,
                           selectcolor=P.bg_raised, activebackground=P.bg_surface,
                           font=TY.body(), cursor="hand2",
                           command=self._save).pack(side="left", padx=(0, SP.sm))

        self._v_tips = tk.BooleanVar(value=self._settings["show_tips"])
        tk.Checkbutton(def_card, text="Show tips on Add Expense tab",
                       variable=self._v_tips, command=self._save,
                       bg=P.bg_surface, fg=P.text_primary,
                       selectcolor=P.bg_raised, activebackground=P.bg_surface,
                       font=TY.body(), cursor="hand2").pack(anchor="w",
                                                              pady=(0, SP.sm))

        # ── DATABASE ─────────────────────────────────────────────────────
        self._section(body, "🔥  Database")
        db_card = self._card(body)
        self._render_db_status(db_card)

        # ── DATA MANAGEMENT ───────────────────────────────────────────────
        self._section(body, "💾  Data Management")
        dm_card = self._card(body)
        self._row(dm_card, "Backup Database", "Save a local copy of expenses.db.")
        StyledButton(dm_card, "📦  Backup Now",
                     self._backup_db, variant="secondary").pack(
            anchor="w", pady=(0, SP.md))
        self._row(dm_card, "Restore Database", "Restore from a backup file.")
        StyledButton(dm_card, "📂  Restore from File",
                     self._restore_db, variant="secondary").pack(
            anchor="w", pady=(0, SP.md))
        self._row(dm_card, "Wipe All Expenses",
                  "⚠️ Permanently deletes ALL transactions.")
        StyledButton(dm_card, "🗑️  Wipe Expenses",
                     self._wipe_expenses, variant="danger").pack(
            anchor="w", pady=(0, SP.sm))

        # ── ABOUT ─────────────────────────────────────────────────────────
        self._section(body, "ℹ️  About")
        ab_card = self._card(body)
        for lbl, val in [
            ("App",     "Personal Expense Tracker"),
            ("Version", self.VERSION),
            ("Stack",   "Python · Tkinter · Firebase · Matplotlib"),
        ]:
            row = tk.Frame(ab_card, bg=P.bg_surface)
            row.pack(fill="x", pady=2)
            tk.Label(row, text=lbl + ":", bg=P.bg_surface,
                     fg=P.text_secondary, font=TY.label(),
                     width=14, anchor="w").pack(side="left")
            tk.Label(row, text=val, bg=P.bg_surface,
                     fg=P.text_primary, font=TY.body()).pack(side="left")

    # ── LIVE THEME ────────────────────────────────────────────────────────────
    def _apply_theme(self, new_theme: str):
        if AppState.theme == new_theme:
            return
        AppState.set_theme(new_theme)
        self._settings["theme"] = new_theme
        self._save()

        # Update our own buttons first so they reflect new theme correctly
        for val, btn in self._theme_btns.items():
            active = (val == new_theme)
            btn.configure(
                bg=P.accent if active else P.bg_raised,
                fg=P.text_on_accent if active else P.text_secondary)

        # Walk the ENTIRE widget tree from the root window
        root = self.winfo_toplevel()
        apply_theme_to_widget(root, new_theme)

        # Tell main.py to refresh ttk styles + redraw charts
        if self._on_theme_change:
            self._on_theme_change(new_theme)

        Toast(self.winfo_toplevel(),
              f"{'🌙 Dark' if new_theme == 'dark' else '☀️ Light'} theme applied!",
              "success")

    # ── LIVE CURRENCY ─────────────────────────────────────────────────────────
    def _apply_currency(self, sym: str):
        AppState.set_currency(sym)
        self._settings["currency"] = sym
        self._save()

        # Update currency selector buttons
        for s, btn in self._cur_btns.items():
            active = (s == sym)
            btn.configure(
                bg=P.accent if active else P.bg_raised,
                fg=P.text_on_accent if active else P.text_secondary)

        # Update example labels
        for s, lbl in self._example_labels.items():
            lbl.configure(text=self._example_text(s))

        if self._on_currency_change:
            self._on_currency_change(sym)

        converted = AppState.fmt_money(1000)
        Toast(self.winfo_toplevel(),
              f"Currency: {CURRENCY_NAMES[sym]} ({sym})  |  ₹1000 = {converted}",
              "success", 3000)

    # ── EXCHANGE RATES ────────────────────────────────────────────────────────
    def _save_rate(self, sym: str):
        """Save one exchange rate from its entry field."""
        var = self._rate_vars.get(sym)
        if not var:
            return
        try:
            inr_per_unit = float(var.get())
            assert inr_per_unit > 0
        except Exception:
            Toast(self.winfo_toplevel(), f"Invalid rate for {sym}", "error")
            return

        AppState.update_rate(sym, inr_per_unit)
        self._settings.setdefault("custom_rates", {})[sym] = inr_per_unit
        self._save()

        # Refresh example
        if sym in self._example_labels:
            self._example_labels[sym].configure(text=self._example_text(sym))

        # If this is the active currency, trigger a UI refresh
        if AppState.currency == sym and self._on_currency_change:
            self._on_currency_change(sym)

    def _save_all_rates(self):
        for sym in self._rate_vars:
            self._save_rate(sym)
        Toast(self.winfo_toplevel(), "All exchange rates saved!", "success")

    def _example_text(self, sym: str) -> str:
        """Show both directions: 1000 INR → X sym and 1 sym → Y INR."""
        converted = AppState.convert(1000)
        rate_inr  = round(1.0 / EXCHANGE_RATES.get(sym, 1), 2)
        ex_val    = AppState.fmt_money(1000) if AppState.currency == sym else \
                    f"{sym}{1000 * EXCHANGE_RATES.get(sym, 1):.2f}"
        return f"₹1000 = {sym}{1000 * EXCHANGE_RATES.get(sym, 1):.2f}  |  1{sym} = ₹{rate_inr}"

    # ── helpers ───────────────────────────────────────────────────────────────
    def _section(self, parent, title: str):
        f = tk.Frame(parent, bg=P.bg_primary, padx=SP.lg)
        f.pack(fill="x", pady=(SP.md, SP.xs))
        tk.Label(f, text=title, bg=P.bg_primary, fg=P.accent,
                 font=(TY.family, TY.size_md, "bold")).pack(anchor="w")

    def _card(self, parent) -> tk.Frame:
        c = tk.Frame(parent, bg=P.bg_surface,
                     highlightthickness=1, highlightbackground=P.border,
                     padx=SP.xl, pady=SP.md)
        c.pack(fill="x", padx=SP.lg, pady=(0, SP.sm))
        return c

    def _row(self, parent, title: str, desc: str):
        tk.Label(parent, text=title, bg=P.bg_surface,
                 fg=P.text_primary,
                 font=(TY.family, TY.size_base, "bold")).pack(
            anchor="w", pady=(SP.sm, 0))
        tk.Label(parent, text=desc, bg=P.bg_surface,
                 fg=P.text_muted, font=TY.caption()).pack(anchor="w")

    def _save(self):
        self._settings.update({
            "theme":           AppState.theme,
            "currency":        AppState.currency,
            "default_payment": self._v_payment.get(),
            "show_tips":       self._v_tips.get(),
        })
        save_settings(self._settings)

    def _render_db_status(self, card):
        try:
            from core.database import is_online
            online = is_online()
            mode   = "🔥 Firebase Realtime DB" if online else "💽 SQLite (offline fallback)"
            col    = P.success if online else P.warning
            status = "Connected" if online else "Offline — data saved locally"
        except ImportError:
            mode, col, status = "💽 SQLite", P.info, "Local only"

        tk.Label(card, text=mode, bg=P.bg_surface, fg=col,
                 font=(TY.family, TY.size_base, "bold")).pack(anchor="w")
        tk.Label(card, text=status, bg=P.bg_surface, fg=P.text_muted,
                 font=TY.caption()).pack(anchor="w")

        cfg_path = os.path.join(os.path.dirname(__file__), "..", "firebase_config.json")
        if not os.path.exists(cfg_path):
            tk.Label(card,
                     text="ℹ️  Create firebase_config.json to enable Firebase.",
                     bg=P.bg_surface, fg=P.info,
                     font=TY.caption()).pack(anchor="w", pady=(SP.xs, 0))
            StyledButton(card, "📄  Create Config Template",
                         self._create_config_template, variant="ghost").pack(
                anchor="w", pady=(SP.sm, 0))

    def _create_config_template(self):
        fp = filedialog.asksaveasfilename(
            defaultextension=".json",
            filetypes=[("JSON", "*.json")],
            initialfile="firebase_config.json")
        if not fp:
            return
        tpl = {
            "database_url": "https://YOUR-APP-default-rtdb.firebaseio.com",
            "api_key":      "YOUR_WEB_API_KEY",
            "auth_email":   "user@example.com",
            "auth_password":"yourpassword"
        }
        with open(fp, "w") as f:
            json.dump(tpl, f, indent=2)
        Toast(self.winfo_toplevel(),
              "Template saved. Fill in your Firebase credentials.", "info", 4000)

    def _backup_db(self):
        try:
            from core import database as _db
            src = _db.DB_PATH
        except Exception:
            src = ""
        if not src or not os.path.exists(src):
            messagebox.showinfo("No local DB",
                                "No local SQLite file found.\n"
                                "(Firebase mode — data is in the cloud.)")
            return
        ts = datetime.now().strftime("%Y%m%d_%H%M%S")
        fp = filedialog.asksaveasfilename(
            defaultextension=".db",
            filetypes=[("SQLite DB", "*.db")],
            initialfile=f"expenses_backup_{ts}.db")
        if fp:
            shutil.copy2(src, fp)
            Toast(self.winfo_toplevel(),
                  f"Backup saved: {os.path.basename(fp)}", "success")

    def _restore_db(self):
        fp = filedialog.askopenfilename(
            filetypes=[("SQLite DB", "*.db")])
        if not fp:
            return
        if not messagebox.askyesno("Confirm Restore",
                                   "Replace current local database?\nRestart after."):
            return
        try:
            from core import database as _db
            shutil.copy2(fp, _db.DB_PATH)
            Toast(self.winfo_toplevel(),
                  "Restored. Please restart the app.", "info", 4000)
        except Exception as e:
            messagebox.showerror("Error", str(e))

    def _wipe_expenses(self):
        if not messagebox.askyesno("Confirm", "Delete ALL expenses permanently?"):
            return
        if not messagebox.askyesno("Double confirm", "Are you 100% sure?"):
            return
        try:
            from core.database import is_online, _fb_delete
            if is_online():
                _fb_delete("expenses")
                Toast(self.winfo_toplevel(),
                      "Firebase expenses wiped.", "info", 3000)
                return
        except Exception:
            pass
        try:
            from core import database as _db
            with _db.get_connection() as conn:
                conn.execute("DELETE FROM expenses")
            Toast(self.winfo_toplevel(),
                  "All local expenses deleted.", "info", 3000)
        except Exception as e:
            messagebox.showerror("Error", str(e))
