"""
ui/tab_budget.py
────────────────
Budget management panel.

Features:
  • Set monthly budget per category
  • Visual progress bars showing spending vs budget
  • Over-budget warning in red

Agile note: Budget logic is entirely in this tab + core/database.py.
Future sprint can add "budget templates" or "carry-over" features here.
"""

import tkinter as tk
from tkinter import messagebox
from datetime import date

from core.theme import P, TY, SP
from core import database as db
from ui.widgets import ScrollableFrame, StyledButton, BudgetBar, Toast


def _fmt(v: float) -> str:
    from core.app_state import AppState
    return AppState.fmt_money(v)



class BudgetTab(tk.Frame):

    def __init__(self, master, **kw):
        super().__init__(master, bg=P.bg_primary, **kw)
        self._build()

    # ── public ──────────────────────────────────────────────────────────────
    def refresh(self):
        self._load_month_selector()
        self._render_budgets()

    # ── build ────────────────────────────────────────────────────────────────
    def _build(self):
        # header
        hdr = tk.Frame(self, bg=P.bg_primary, padx=SP.lg, pady=SP.md)
        hdr.pack(fill="x")
        tk.Label(hdr, text="🎯  Budget Planner", bg=P.bg_primary,
                 fg=P.text_primary, font=TY.h2()).pack(side="left")

        # month selector
        ctrl = tk.Frame(self, bg=P.bg_primary, padx=SP.lg)
        ctrl.pack(fill="x")
        tk.Label(ctrl, text="Month:", bg=P.bg_primary,
                 fg=P.text_secondary, font=TY.label()).pack(side="left")
        self._v_month = tk.StringVar(value=date.today().strftime("%Y-%m"))
        self._month_cb = tk.OptionMenu(ctrl, self._v_month, "")
        self._month_cb.configure(
            bg=P.bg_raised, fg=P.text_primary, font=TY.body(),
            activebackground=P.bg_hover, activeforeground=P.text_primary,
            highlightthickness=0, relief="flat", cursor="hand2")
        self._month_cb["menu"].configure(
            bg=P.bg_raised, fg=P.text_primary, font=TY.body())
        self._month_cb.pack(side="left", padx=(4, SP.md))
        self._v_month.trace_add("write", lambda *_: self._render_budgets())

        # ── set budget form ────────────────────────────────────────────────
        form_card = tk.Frame(self, bg=P.bg_surface,
                             highlightthickness=1,
                             highlightbackground=P.border,
                             padx=SP.xl, pady=SP.lg)
        form_card.pack(fill="x", padx=SP.lg, pady=SP.sm)

        tk.Label(form_card, text="Set / Update Budget",
                 bg=P.bg_surface, fg=P.text_primary, font=TY.h3()).pack(anchor="w")
        tk.Label(form_card, text="Choose a category and enter a budget for the selected month.",
                 bg=P.bg_surface, fg=P.text_muted, font=TY.caption()).pack(anchor="w")

        row = tk.Frame(form_card, bg=P.bg_surface, pady=SP.sm)
        row.pack(fill="x")

        tk.Label(row, text="Category:", bg=P.bg_surface,
                 fg=P.text_secondary, font=TY.label()).pack(side="left")
        self._v_cat = tk.StringVar()
        self._cat_cb = tk.OptionMenu(row, self._v_cat, "")
        self._cat_cb.configure(
            bg=P.bg_raised, fg=P.text_primary, font=TY.body(),
            activebackground=P.bg_hover, activeforeground=P.text_primary,
            highlightthickness=0, relief="flat", cursor="hand2", width=20)
        self._cat_cb["menu"].configure(
            bg=P.bg_raised, fg=P.text_primary, font=TY.body())
        self._cat_cb.pack(side="left", padx=(4, SP.md))

        tk.Label(row, text="Budget (₹):", bg=P.bg_surface,
                 fg=P.text_secondary, font=TY.label()).pack(side="left")
        self._v_amount = tk.StringVar()
        tk.Entry(row, textvariable=self._v_amount,
                 bg=P.bg_input, fg=P.text_primary,
                 insertbackground=P.accent, relief="flat",
                 font=TY.body(), width=12,
                 highlightthickness=1,
                 highlightbackground=P.border,
                 highlightcolor=P.border_focus).pack(
            side="left", padx=(4, SP.md), ipady=5)

        StyledButton(row, "💾  Save Budget",
                     self._save_budget, variant="primary").pack(side="left")

        # ── progress bars ──────────────────────────────────────────────────
        tk.Label(self, text="Budget vs Actual", bg=P.bg_primary,
                 fg=P.text_secondary, font=TY.label(),
                 padx=SP.lg).pack(anchor="w", pady=(SP.md, SP.xs))

        self._scroll = ScrollableFrame(self, bg=P.bg_primary)
        self._scroll.pack(fill="both", expand=True)
        self._bars_frame = self._scroll.inner

    # ── helpers ──────────────────────────────────────────────────────────────
    def _load_month_selector(self):
        months = db.available_months()
        cur = date.today().strftime("%Y-%m")
        if cur not in months:
            months.insert(0, cur)

        menu = self._month_cb["menu"]
        menu.delete(0, "end")
        for m in months:
            menu.add_command(label=m,
                             command=lambda v=m: self._v_month.set(v))

        cur_val = self._v_month.get()
        if cur_val not in months:
            self._v_month.set(months[0] if months else cur)

        # load categories into cat selector
        cats = db.get_all_categories()
        cat_menu = self._cat_cb["menu"]
        cat_menu.delete(0, "end")
        for c in cats:
            cat_menu.add_command(
                label=c["name"],
                command=lambda n=c["name"]: self._v_cat.set(n))
        if cats and not self._v_cat.get():
            self._v_cat.set(cats[0]["name"])

    def _save_budget(self):
        cat_name = self._v_cat.get()
        raw_amt  = self._v_amount.get().strip()
        month    = self._v_month.get()

        if not cat_name or not raw_amt:
            messagebox.showwarning("Input needed",
                                   "Please choose a category and enter an amount.")
            return
        try:
            amt = float(raw_amt)
            assert amt >= 0
        except Exception:
            messagebox.showerror("Error", "Amount must be a non-negative number.")
            return

        cat_id = None
        for c in db.get_all_categories():
            if c["name"] == cat_name:
                cat_id = c["id"]
                break
        if cat_id is None:
            return

        db.set_budget(cat_id, month, amt)
        self._v_amount.set("")
        Toast(self.winfo_toplevel(), "Budget saved!", "success")
        self._render_budgets()

    def _render_budgets(self):
        for w in self._bars_frame.winfo_children():
            w.destroy()

        month  = self._v_month.get()
        budgets = db.get_budgets(month)

        if not budgets:
            tk.Label(self._bars_frame,
                     text="No budgets set for this month.\n"
                          "Use the form above to add one.",
                     bg=P.bg_primary, fg=P.text_muted,
                     font=TY.body(), pady=SP.xl).pack()
            return

        total_budget = sum(b["amount"] for b in budgets)
        total_spent  = sum(b["spent"]  for b in budgets)

        # summary row
        summary = tk.Frame(self._bars_frame, bg=P.bg_raised,
                           padx=SP.lg, pady=SP.sm)
        summary.pack(fill="x", padx=SP.lg, pady=(0, SP.sm))
        for lbl, val, col in [
            ("Total Budget", _fmt(total_budget), P.teal),
            ("Total Spent",  _fmt(total_spent),
             P.danger if total_spent > total_budget else P.success),
            ("Remaining",    _fmt(max(0, total_budget-total_spent)), P.success),
        ]:
            col_f = tk.Frame(summary, bg=P.bg_raised)
            col_f.pack(side="left", expand=True, fill="x")
            tk.Label(col_f, text=lbl, bg=P.bg_raised, fg=P.text_secondary,
                     font=TY.caption()).pack()
            tk.Label(col_f, text=val, bg=P.bg_raised, fg=col,
                     font=TY.h3()).pack()

        # individual bars
        for b in budgets:
            card = tk.Frame(self._bars_frame, bg=P.bg_surface,
                            padx=SP.md, pady=SP.sm,
                            highlightthickness=1,
                            highlightbackground=P.border)
            card.pack(fill="x", padx=SP.lg, pady=2)
            BudgetBar(card,
                      label=f"{b['icon']} {b['name']}",
                      spent=b["spent"],
                      budget=b["amount"],
                      color=b["color"]).pack(fill="x")