"""
ui/tab_history.py
─────────────────
History panel: filterable, sortable expense table with edit/delete.

Agile note: The Treeview columns list is the single source of truth.
To add a column in a future sprint, add it to COLUMNS and update
_populate_row().
"""

import sqlite3
import tkinter as tk
from tkinter import ttk, messagebox
from typing import Callable, Optional

from core.theme import P, TY, SP
from core import database as db
from ui.widgets import StyledButton, Toast


def _fmt(v: float) -> str:
    from core.app_state import AppState
    return AppState.fmt_money(v)



COLUMNS = [
    # (id,          heading,     width, anchor)
    ("date",        "Date",       90,  "center"),
    ("desc",        "Description",200, "w"),
    ("category",    "Category",  130,  "w"),
    ("group",       "Group",      90,  "center"),
    ("amount",      "Amount",     90,  "e"),
    ("payment",     "Payment",    90,  "center"),
    ("notes",       "Notes",     140,  "w"),
]


class HistoryTab(tk.Frame):

    def __init__(self, master,
                 on_edit: Callable = None,
                 **kw):
        super().__init__(master, bg=P.bg_primary, **kw)
        self._on_edit = on_edit
        self._all_rows: list = []
        self._build()

    # ── public ──────────────────────────────────────────────────────────────
    def refresh(self):
        self._load_category_filter()
        self._load_month_filter()
        self._query_and_display()

    # ── build ────────────────────────────────────────────────────────────────
    def _build(self):
        # ── header ─────────────────────────────────────────────────────────
        hdr = tk.Frame(self, bg=P.bg_primary, padx=SP.lg, pady=SP.md)
        hdr.pack(fill="x")
        tk.Label(hdr, text="📋  Transaction History", bg=P.bg_primary,
                 fg=P.text_primary, font=TY.h2()).pack(side="left")

        # ── filter bar ─────────────────────────────────────────────────────
        bar = tk.Frame(self, bg=P.bg_raised, padx=SP.md, pady=SP.sm)
        bar.pack(fill="x", padx=SP.lg, pady=(0, SP.sm))

        # category filter
        tk.Label(bar, text="Category:", bg=P.bg_raised,
                 fg=P.text_secondary, font=TY.label()).pack(side="left")
        self._v_cat = tk.StringVar(value="All")
        self._cat_cb = self._make_combo(bar, self._v_cat, ["All"], 16)
        self._cat_cb.pack(side="left", padx=(4, SP.md))

        # month filter
        tk.Label(bar, text="Month:", bg=P.bg_raised,
                 fg=P.text_secondary, font=TY.label()).pack(side="left")
        self._v_month = tk.StringVar(value="All")
        self._month_cb = self._make_combo(bar, self._v_month, ["All"], 12)
        self._month_cb.pack(side="left", padx=(4, SP.md))

        # group filter
        tk.Label(bar, text="Group:", bg=P.bg_raised,
                 fg=P.text_secondary, font=TY.label()).pack(side="left")
        self._v_group = tk.StringVar(value="All")
        grp_cb = self._make_combo(bar, self._v_group,
                                   ["All", "Needs", "Wants", "Savings/Debt"], 14)
        grp_cb.pack(side="left", padx=(4, SP.md))

        # sort
        tk.Label(bar, text="Sort:", bg=P.bg_raised,
                 fg=P.text_secondary, font=TY.label()).pack(side="left")
        self._v_sort = tk.StringVar(value="Date (newest)")
        sort_map = {
            "Date (newest)": "date_desc",
            "Date (oldest)": "date_asc",
            "Amount (high)": "amount_desc",
            "Amount (low)":  "amount_asc",
        }
        self._sort_map = sort_map
        sort_cb = self._make_combo(bar, self._v_sort,
                                    list(sort_map.keys()), 16)
        sort_cb.pack(side="left", padx=(4, SP.md))

        # search
        tk.Label(bar, text="Search:", bg=P.bg_raised,
                 fg=P.text_secondary, font=TY.label()).pack(side="left")
        self._v_search = tk.StringVar()
        self._v_search.trace_add("write", lambda *_: self._filter_display())
        tk.Entry(bar, textvariable=self._v_search,
                 bg=P.bg_input, fg=P.text_primary,
                 insertbackground=P.accent, relief="flat",
                 font=TY.body(), width=16,
                 highlightthickness=1,
                 highlightbackground=P.border,
                 highlightcolor=P.border_focus).pack(
            side="left", padx=(4, SP.md), ipady=3)

        StyledButton(bar, "Apply", self._query_and_display,
                     variant="primary").pack(side="left")

        # ── total label ─────────────────────────────────────────────────────
        self._total_lbl = tk.Label(self, text="",
                                    bg=P.bg_primary, fg=P.text_secondary,
                                    font=TY.label(), padx=SP.lg)
        self._total_lbl.pack(anchor="w")

        # ── treeview ────────────────────────────────────────────────────────
        tv_frame = tk.Frame(self, bg=P.bg_primary, padx=SP.lg)
        tv_frame.pack(fill="both", expand=True, pady=(0, SP.sm))

        style = ttk.Style()
        style.configure("Dark.Treeview",
                         background=P.bg_surface,
                         fieldbackground=P.bg_surface,
                         foreground=P.text_primary,
                         rowheight=30,
                         borderwidth=0,
                         font=TY.body())
        style.configure("Dark.Treeview.Heading",
                         background=P.bg_raised,
                         foreground=P.text_secondary,
                         font=TY.label(),
                         borderwidth=0)
        style.map("Dark.Treeview",
                  background=[("selected", P.bg_hover)],
                  foreground=[("selected", P.accent)])

        col_ids = [c[0] for c in COLUMNS]
        self._tree = ttk.Treeview(tv_frame, columns=col_ids,
                                   show="headings", style="Dark.Treeview",
                                   selectmode="browse")
        for cid, heading, width, anchor in COLUMNS:
            self._tree.heading(cid, text=heading)
            self._tree.column(cid, width=width, minwidth=50, anchor=anchor)

        vsb = ttk.Scrollbar(tv_frame, orient="vertical",
                             command=self._tree.yview)
        hsb = ttk.Scrollbar(tv_frame, orient="horizontal",
                             command=self._tree.xview)
        self._tree.configure(yscrollcommand=vsb.set, xscrollcommand=hsb.set)

        self._tree.grid(row=0, column=0, sticky="nsew")
        vsb.grid(row=0, column=1, sticky="ns")
        hsb.grid(row=1, column=0, sticky="ew")
        tv_frame.rowconfigure(0, weight=1)
        tv_frame.columnconfigure(0, weight=1)

        self._tree.tag_configure("odd",  background=P.bg_surface)
        self._tree.tag_configure("even", background=P.bg_raised)

        self._tree.bind("<Double-1>", self._on_double_click)

        # ── action bar ──────────────────────────────────────────────────────
        act = tk.Frame(self, bg=P.bg_primary, padx=SP.lg, pady=SP.sm)
        act.pack(fill="x")
        StyledButton(act, "✏️  Edit Selected",
                     self._edit_selected, variant="secondary").pack(side="left")
        StyledButton(act, "🗑️  Delete Selected",
                     self._delete_selected, variant="danger").pack(
            side="left", padx=SP.sm)

    # ── helpers ──────────────────────────────────────────────────────────────
    def _make_combo(self, parent, var, values, width):
        s = ttk.Style()
        sn = f"DarkH{id(var)}.TCombobox"
        s.configure(sn, fieldbackground=P.bg_input, background=P.bg_raised,
                    foreground=P.text_primary, arrowcolor=P.accent)
        cb = ttk.Combobox(parent, textvariable=var, values=values,
                          state="readonly", width=width, style=sn)
        return cb

    def _load_category_filter(self):
        cats = ["All"] + [c["name"] for c in db.get_all_categories()]
        self._cat_cb["values"] = cats

    def _load_month_filter(self):
        months = ["All"] + db.available_months()
        self._month_cb["values"] = months

    def _query_and_display(self):
        cat_name  = self._v_cat.get()
        month     = self._v_month.get()
        sort_key  = self._sort_map.get(self._v_sort.get(), "date_desc")

        cat_id = None
        if cat_name != "All":
            for c in db.get_all_categories():
                if c["name"] == cat_name:
                    cat_id = c["id"]
                    break

        self._all_rows = db.get_expenses(
            category_id=cat_id,
            month=month if month != "All" else None,
            sort=sort_key,
        )
        self._filter_display()

    def _filter_display(self):
        term  = self._v_search.get().lower()
        group = self._v_group.get()

        rows = self._all_rows
        if term:
            rows = [r for r in rows
                    if term in r["description"].lower()
                    or term in r["cat_name"].lower()
                    or term in (r["notes"] or "").lower()]
        if group != "All":
            rows = [r for r in rows if r["group_type"] == group]

        self._tree.delete(*self._tree.get_children())
        self._id_map: dict = {}
        total = 0.0
        for i, r in enumerate(rows):
            tag = "odd" if i % 2 == 0 else "even"
            iid = self._tree.insert("", "end", tags=(tag,),
                                    values=(
                                        r["expense_date"],
                                        r["description"],
                                        f"{r['cat_icon']} {r['cat_name']}",
                                        r["group_type"],
                                        _fmt(r['amount']),
                                        r["payment"],
                                        r["notes"],
                                    ))
            self._id_map[iid] = r
            total += r["amount"]

        self._total_lbl.configure(
            text=f"{len(rows)} transactions  ·  Total: {_fmt(total)}")

    def _selected_row(self) -> Optional[sqlite3.Row]:
        sel = self._tree.selection()
        if not sel:
            messagebox.showinfo("Select", "Please select a transaction first.")
            return None
        return self._id_map.get(sel[0])

    def _on_double_click(self, _e):
        self._edit_selected()

    def _edit_selected(self):
        row = self._selected_row()
        if row and self._on_edit:
            self._on_edit(row)

    def _delete_selected(self):
        row = self._selected_row()
        if not row:
            return
        if not messagebox.askyesno(
                "Confirm Delete",
                f"Delete «{row['description']}» ({_fmt(row['amount'])})?"):
            return
        db.delete_expense(row["id"])
        Toast(self.winfo_toplevel(), "Expense deleted.", "info")
        self.refresh()