"""
ui/tab_dashboard.py
───────────────────
Dashboard panel: KPI cards, doughnut chart, line chart, recent transactions.

Agile note: This is one tab = one file. Future sprints can extend
this class or replace it without touching other tabs.
"""

import tkinter as tk
from datetime import date, timedelta, datetime
from collections import defaultdict

import matplotlib
matplotlib.use("TkAgg")
from matplotlib.figure import Figure
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
import matplotlib.patches as mpatches

from core.theme import P, TY, SP
from core import database as db
from ui.widgets import MetricCard, ScrollableFrame, StyledButton


def _fmt(v: float) -> str:
    from core.app_state import AppState
    return AppState.fmt_money(v)


def _blend_hex(c1: str, c2: str, t: float) -> str:
    """Blend two hex colours. t=0 → c1, t=1 → c2. Returns solid 6-digit hex."""
    def rgb(h):
        h = h.lstrip("#")
        return int(h[0:2], 16), int(h[2:4], 16), int(h[4:6], 16)
    r1, g1, b1 = rgb(c1)
    r2, g2, b2 = rgb(c2)
    return "#{:02x}{:02x}{:02x}".format(
        int(r1 + (r2 - r1) * t),
        int(g1 + (g2 - g1) * t),
        int(b1 + (b2 - b1) * t)
    )


class DashboardTab(tk.Frame):

    def __init__(self, master, on_add_expense: callable = None, **kw):
        super().__init__(master, bg=P.bg_primary, **kw)
        self._on_add = on_add_expense
        self._build()

    def _build(self):
        # ── top bar ────────────────────────────────────────────────────────
        bar = tk.Frame(self, bg=P.bg_primary, pady=SP.md, padx=SP.lg)
        bar.pack(fill="x")
        tk.Label(bar, text="💸  Expense Dashboard", bg=P.bg_primary,
                 fg=P.text_primary, font=TY.h2()).pack(side="left")
        if self._on_add:
            StyledButton(bar, "+ Add Expense", self._on_add,
                         variant="primary").pack(side="right", padx=SP.sm)

        # ── month selector ─────────────────────────────────────────────────
        ctrl = tk.Frame(self, bg=P.bg_primary, padx=SP.lg)
        ctrl.pack(fill="x")
        tk.Label(ctrl, text="Month:", bg=P.bg_primary,
                 fg=P.text_secondary, font=TY.label()).pack(side="left")
        self._month_var = tk.StringVar()
        self._month_cb = tk.OptionMenu(ctrl, self._month_var, "")
        self._month_cb.configure(
            bg=P.bg_raised, fg=P.text_primary, font=TY.body(),
            activebackground=P.bg_hover, activeforeground=P.text_primary,
            highlightthickness=0, relief="flat", cursor="hand2")
        self._month_cb["menu"].configure(
            bg=P.bg_raised, fg=P.text_primary, font=TY.body())
        self._month_cb.pack(side="left", padx=(4, 0))
        self._month_var.trace_add("write", lambda *_: self.refresh())

        # ── scrollable content ─────────────────────────────────────────────
        self._scroll = ScrollableFrame(self, bg=P.bg_primary)
        self._scroll.pack(fill="both", expand=True)
        self._body = self._scroll.inner

        # ── metric cards row ───────────────────────────────────────────────
        card_row = tk.Frame(self._body, bg=P.bg_primary,
                            padx=SP.lg, pady=SP.md)
        card_row.pack(fill="x")
        card_row.columnconfigure((0, 1, 2, 3), weight=1)

        self._card_total  = MetricCard(card_row, "This Month")
        self._card_last   = MetricCard(card_row, "vs Last Month")
        self._card_avg    = MetricCard(card_row, "Daily Average")
        self._card_count  = MetricCard(card_row, "Transactions")

        for i, c in enumerate([self._card_total, self._card_last,
                                self._card_avg, self._card_count]):
            c.grid(row=0, column=i, sticky="nsew", padx=(0, SP.sm))

        # ── chart row ─────────────────────────────────────────────────────
        chart_row = tk.Frame(self._body, bg=P.bg_primary, padx=SP.lg)
        chart_row.pack(fill="x", pady=(0, SP.md))
        chart_row.columnconfigure(0, weight=2)
        chart_row.columnconfigure(1, weight=3)

        # doughnut
        donut_frame = tk.Frame(chart_row, bg=P.bg_surface, padx=4, pady=4)
        donut_frame.grid(row=0, column=0, sticky="nsew", padx=(0, SP.sm))
        tk.Label(donut_frame, text="Spending by Category", bg=P.bg_surface,
                 fg=P.text_secondary, font=TY.label()).pack(anchor="w", padx=8)
        self._fig_donut = Figure(figsize=(3.4, 2.8), dpi=96,
                                  facecolor=P.bg_surface)
        self._ax_donut = self._fig_donut.add_subplot(111)
        self._canvas_donut = FigureCanvasTkAgg(self._fig_donut, donut_frame)
        self._canvas_donut.get_tk_widget().pack(fill="both", expand=True)

        # line
        line_frame = tk.Frame(chart_row, bg=P.bg_surface, padx=4, pady=4)
        line_frame.grid(row=0, column=1, sticky="nsew")
        tk.Label(line_frame, text="Daily Spending Trend", bg=P.bg_surface,
                 fg=P.text_secondary, font=TY.label()).pack(anchor="w", padx=8)
        self._fig_line = Figure(figsize=(5.5, 2.8), dpi=96,
                                 facecolor=P.bg_surface)
        self._ax_line = self._fig_line.add_subplot(111)
        self._canvas_line = FigureCanvasTkAgg(self._fig_line, line_frame)
        self._canvas_line.get_tk_widget().pack(fill="both", expand=True)

        # group bar
        grp_frame = tk.Frame(self._body, bg=P.bg_surface,
                             padx=SP.lg, pady=SP.sm,
                             highlightthickness=1,
                             highlightbackground=P.border)
        grp_frame.pack(fill="x", padx=SP.lg, pady=(0, SP.md))
        tk.Label(grp_frame, text="Needs / Wants / Savings",
                 bg=P.bg_surface, fg=P.text_secondary,
                 font=TY.label()).pack(anchor="w")
        self._fig_grp = Figure(figsize=(8, 1.5), dpi=88,
                                facecolor=P.bg_surface)
        self._ax_grp = self._fig_grp.add_subplot(111)
        self._canvas_grp = FigureCanvasTkAgg(self._fig_grp, grp_frame)
        self._canvas_grp.get_tk_widget().pack(fill="x")

        # ── recent transactions ────────────────────────────────────────────
        rec_hdr = tk.Frame(self._body, bg=P.bg_primary, padx=SP.lg)
        rec_hdr.pack(fill="x", pady=(SP.sm, SP.xs))
        tk.Label(rec_hdr, text="Recent Transactions", bg=P.bg_primary,
                 fg=P.text_primary, font=TY.h3()).pack(side="left")

        self._recent_frame = tk.Frame(self._body, bg=P.bg_primary,
                                       padx=SP.lg)
        self._recent_frame.pack(fill="x", pady=(0, SP.lg))

    # ── public ─────────────────────────────────────────────────────────────
    def refresh(self):
        self._refresh_month_list()
        month = self._month_var.get()
        if not month:
            return
        self._render_metrics(month)
        self._render_donut(month)
        self._render_line(month)
        self._render_group_bar(month)
        self._render_recent(month)

    # ── private helpers ────────────────────────────────────────────────────
    def _refresh_month_list(self):
        months = db.available_months()
        cur = date.today().strftime("%Y-%m")
        if cur not in months:
            months.insert(0, cur)

        menu = self._month_cb["menu"]
        menu.delete(0, "end")
        for m in months:
            menu.add_command(label=m,
                             command=lambda v=m: self._month_var.set(v))

        cur_val = self._month_var.get()
        if cur_val not in months:
            self._month_var.set(months[0] if months else cur)

    def _render_metrics(self, month: str):
        total     = db.monthly_total(month)
        prev_month = _prev_month(month)
        prev_total = db.monthly_total(prev_month)
        diff       = total - prev_total

        today = date.today()
        days_elapsed = today.day if month == today.strftime("%Y-%m") else 30
        avg = total / max(days_elapsed, 1)

        all_exp = db.get_expenses(month=month)

        self._card_total.update(_fmt(total))
        sign = "↓" if diff <= 0 else "↑"
        self._card_last.update(
            _fmt(abs(diff)),
            delta=f"{sign} vs {prev_month}",
            delta_positive=diff <= 0)
        self._card_avg.update(_fmt(avg))
        self._card_count.update(str(len(all_exp)))

    def _render_donut(self, month: str):
        rows = db.monthly_by_category(month)
        self._ax_donut.clear()
        if not rows:
            self._ax_donut.text(0.5, 0.5, "No data", ha="center",
                                va="center", color=P.text_muted,
                                transform=self._ax_donut.transAxes)
        else:
            vals   = [r["total"] for r in rows]
            colors = [r["color"] for r in rows]
            labels = [r["name"] for r in rows]
            wedges, _ = self._ax_donut.pie(
                vals, colors=colors, startangle=90,
                wedgeprops={"width": 0.55,
                            "edgecolor": P.bg_surface, "linewidth": 2})
            total = sum(vals)
            self._ax_donut.text(0, 0, _fmt(total), ha="center", va="center",
                                color=P.text_primary,
                                fontsize=9, fontweight="bold")
            # legend
            patches = [mpatches.Patch(color=colors[i], label=labels[i])
                       for i in range(min(6, len(labels)))]
            self._ax_donut.legend(handles=patches, loc="lower center",
                                   bbox_to_anchor=(0.5, -0.18),
                                   ncol=2, fontsize=6.5, frameon=False,
                                   labelcolor=P.text_secondary)
        self._ax_donut.set_facecolor(P.bg_surface)
        self._fig_donut.set_facecolor(P.bg_surface)
        self._fig_donut.tight_layout(pad=0.5)
        self._canvas_donut.draw()

    def _render_line(self, month: str):
        rows = db.daily_totals_for_month(month)
        self._ax_line.clear()
        if not rows:
            self._ax_line.text(0.5, 0.5, "No data", ha="center",
                               va="center", color=P.text_muted,
                               transform=self._ax_line.transAxes)
        else:
            days   = [r["day"][-2:]  for r in rows]   # DD only
            totals = [r["total"]     for r in rows]
            self._ax_line.plot(days, totals, color=P.teal,
                               linewidth=2, marker="o", markersize=4,
                               markerfacecolor=P.accent)
            self._ax_line.fill_between(range(len(days)), totals,
                                        alpha=0.12, color=P.teal)
            self._ax_line.set_xticks(range(len(days)))
            self._ax_line.set_xticklabels(days, rotation=0, fontsize=7,
                                           color=P.text_secondary)
            self._ax_line.yaxis.set_major_formatter(
                matplotlib.ticker.FuncFormatter(lambda v, _: f"₹{v:,.0f}"))
            self._ax_line.tick_params(axis="y", labelsize=7,
                                       labelcolor=P.text_secondary)
            for sp in ["top", "right"]:
                self._ax_line.spines[sp].set_visible(False)
            for sp in ["left", "bottom"]:
                self._ax_line.spines[sp].set_color(P.border)
            self._ax_line.set_facecolor(P.bg_surface)
            self._ax_line.patch.set_alpha(0)
        self._fig_line.set_facecolor(P.bg_surface)
        self._fig_line.tight_layout(pad=0.5)
        self._canvas_line.draw()

    def _render_group_bar(self, month: str):
        rows = db.monthly_by_group(month)
        self._ax_grp.clear()
        groups  = [r["group_type"] for r in rows]
        totals  = [r["total"]      for r in rows]
        gcolors = {
            "Needs":        P.needs,
            "Wants":        P.wants,
            "Savings/Debt": P.savings,
        }
        colors = [gcolors.get(g, P.accent) for g in groups]
        if groups:
            bars = self._ax_grp.barh(groups, totals, color=colors,
                                      height=0.5)
            for bar, total in zip(bars, totals):
                self._ax_grp.text(
                    bar.get_width() + max(totals) * 0.01,
                    bar.get_y() + bar.get_height() / 2,
                    _fmt(total), va="center",
                    color=P.text_secondary, fontsize=8)
        self._ax_grp.set_facecolor(P.bg_surface)
        self._ax_grp.tick_params(labelcolor=P.text_secondary, labelsize=8)
        for sp in ["top", "right", "left", "bottom"]:
            self._ax_grp.spines[sp].set_visible(False)
        self._ax_grp.xaxis.set_visible(False)
        self._fig_grp.set_facecolor(P.bg_surface)
        self._fig_grp.tight_layout(pad=0.4)
        self._canvas_grp.draw()

    def _render_recent(self, month: str):
        for w in self._recent_frame.winfo_children():
            w.destroy()

        exps = db.get_expenses(month=month, sort="date_desc")[:10]
        if not exps:
            tk.Label(self._recent_frame, text="No transactions yet.",
                     bg=P.bg_primary, fg=P.text_muted,
                     font=TY.body()).pack(pady=SP.lg)
            return

        # header row
        hdr = tk.Frame(self._recent_frame, bg=P.bg_raised)
        hdr.pack(fill="x", pady=(0, 1))
        for col, wt in [("Date", 1), ("Description", 3),
                         ("Category", 2), ("Payment", 1), ("Amount", 1)]:
            tk.Label(hdr, text=col, bg=P.bg_raised, fg=P.text_secondary,
                     font=TY.label(), padx=SP.sm, pady=SP.xs,
                     anchor="w").pack(side="left", fill="x", expand=(wt > 1))

        for i, e in enumerate(exps):
            bg = P.bg_surface if i % 2 == 0 else P.bg_raised
            row = tk.Frame(self._recent_frame, bg=bg, pady=2)
            row.pack(fill="x")

            # date
            tk.Label(row, text=e["expense_date"], bg=bg,
                     fg=P.text_secondary, font=TY.caption(),
                     padx=SP.sm, width=10, anchor="w").pack(side="left")
            # desc
            tk.Label(row, text=e["description"], bg=bg,
                     fg=P.text_primary, font=TY.body(),
                     padx=SP.sm, anchor="w").pack(side="left", fill="x",
                                                   expand=True)
            # category badge
            badge_bg = _blend_hex(e["cat_color"], P.bg_raised, 0.82)
            badge = tk.Frame(row, bg=badge_bg, padx=6, pady=1)
            badge.pack(side="left", padx=SP.xs)
            tk.Label(badge, text=f"{e['cat_icon']} {e['cat_name']}",
                     bg=badge_bg, fg=e["cat_color"],
                     font=TY.caption()).pack()
            # payment
            tk.Label(row, text=e["payment"], bg=bg,
                     fg=P.text_muted, font=TY.caption(),
                     padx=SP.sm, width=10).pack(side="left")
            # amount
            tk.Label(row, text=_fmt(e["amount"]), bg=bg,
                     fg=P.accent, font=(TY.family, TY.size_base, "bold"),
                     padx=SP.sm, width=10, anchor="e").pack(side="right")


# ── helper ────────────────────────────────────────────────────────────────────
def _prev_month(month: str) -> str:
    y, m = map(int, month.split("-"))
    m -= 1
    if m == 0:
        m = 12; y -= 1
    return f"{y}-{m:02d}"


import matplotlib.ticker
