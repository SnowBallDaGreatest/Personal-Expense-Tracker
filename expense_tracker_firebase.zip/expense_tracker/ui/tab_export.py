"""
ui/tab_export.py
────────────────
Sprint 2 — Export panel.

Features:
  • Export filtered expenses to CSV
  • Generate PDF report (with embedded charts snapshot)
  • Preview stats before exporting
  • File-save dialog
"""

import os
import tempfile
import tkinter as tk
from tkinter import filedialog, messagebox
from datetime import date, datetime

import matplotlib
matplotlib.use("TkAgg")
import matplotlib.pyplot as plt
from matplotlib.figure import Figure
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
import matplotlib.patches as mpatches
import matplotlib.ticker as ticker

from core.theme import P, TY, SP
from core import database as db
from core.exporter import export_csv, export_pdf
from ui.widgets import StyledButton, Toast, ScrollableFrame, BudgetBar


def _fmt(v: float) -> str:
    from core.app_state import AppState
    return AppState.fmt_money(v)


class ExportTab(tk.Frame):

    def __init__(self, master, **kw):
        super().__init__(master, bg=P.bg_primary, **kw)
        self._preview_expenses = []
        self._build()

    # ── public ───────────────────────────────────────────────────────────────
    def refresh(self):
        self._load_months()
        self._update_preview()

    # ── build ─────────────────────────────────────────────────────────────────
    def _build(self):
        # header
        hdr = tk.Frame(self, bg=P.bg_primary, padx=SP.lg, pady=SP.md)
        hdr.pack(fill="x")
        tk.Label(hdr, text="📤  Export & Reports", bg=P.bg_primary,
                 fg=P.text_primary, font=TY.h2()).pack(side="left")

        # ── filter card ───────────────────────────────────────────────────
        fcard = tk.Frame(self, bg=P.bg_surface,
                         highlightthickness=1, highlightbackground=P.border,
                         padx=SP.xl, pady=SP.lg)
        fcard.pack(fill="x", padx=SP.lg, pady=(0, SP.md))

        tk.Label(fcard, text="Export Settings", bg=P.bg_surface,
                 fg=P.text_primary, font=TY.h3()).grid(
            row=0, column=0, columnspan=4, sticky="w", pady=(0, SP.sm))

        # month
        tk.Label(fcard, text="Month:", bg=P.bg_surface,
                 fg=P.text_secondary, font=TY.label()).grid(
            row=1, column=0, sticky="w")
        self._v_month = tk.StringVar()
        self._month_cb = tk.OptionMenu(fcard, self._v_month, "")
        self._month_cb.configure(
            bg=P.bg_raised, fg=P.text_primary, font=TY.body(),
            activebackground=P.bg_hover, activeforeground=P.text_primary,
            highlightthickness=0, relief="flat", cursor="hand2")
        self._month_cb["menu"].configure(
            bg=P.bg_raised, fg=P.text_primary, font=TY.body())
        self._month_cb.grid(row=2, column=0, sticky="ew", padx=(0, SP.md))
        self._v_month.trace_add("write", lambda *_: self._update_preview())

        # category
        tk.Label(fcard, text="Category:", bg=P.bg_surface,
                 fg=P.text_secondary, font=TY.label()).grid(
            row=1, column=1, sticky="w")
        self._v_cat = tk.StringVar(value="All")
        self._cat_cb = tk.OptionMenu(fcard, self._v_cat, "All")
        self._cat_cb.configure(
            bg=P.bg_raised, fg=P.text_primary, font=TY.body(),
            activebackground=P.bg_hover, activeforeground=P.text_primary,
            highlightthickness=0, relief="flat", cursor="hand2")
        self._cat_cb["menu"].configure(
            bg=P.bg_raised, fg=P.text_primary, font=TY.body())
        self._cat_cb.grid(row=2, column=1, sticky="ew", padx=(0, SP.md))
        self._v_cat.trace_add("write", lambda *_: self._update_preview())

        # group
        tk.Label(fcard, text="Group:", bg=P.bg_surface,
                 fg=P.text_secondary, font=TY.label()).grid(
            row=1, column=2, sticky="w")
        self._v_group = tk.StringVar(value="All")
        group_om = tk.OptionMenu(fcard, self._v_group,
                                  "All", "Needs", "Wants", "Savings/Debt")
        group_om.configure(
            bg=P.bg_raised, fg=P.text_primary, font=TY.body(),
            activebackground=P.bg_hover, activeforeground=P.text_primary,
            highlightthickness=0, relief="flat", cursor="hand2")
        group_om["menu"].configure(bg=P.bg_raised, fg=P.text_primary)
        group_om.grid(row=2, column=2, sticky="ew", padx=(0, SP.md))
        self._v_group.trace_add("write", lambda *_: self._update_preview())

        fcard.columnconfigure((0, 1, 2, 3), weight=1)

        # export buttons
        btn_row = tk.Frame(fcard, bg=P.bg_surface)
        btn_row.grid(row=3, column=0, columnspan=4,
                     sticky="ew", pady=(SP.lg, 0))
        StyledButton(btn_row, "📄  Export CSV",
                     self._export_csv, variant="primary").pack(side="left")
        StyledButton(btn_row, "📑  Export PDF Report",
                     self._export_pdf, variant="secondary").pack(
            side="left", padx=SP.sm)

        # ── preview section ───────────────────────────────────────────────
        scroll = ScrollableFrame(self, bg=P.bg_primary)
        scroll.pack(fill="both", expand=True)
        self._body = scroll.inner

        # stat cards
        self._stat_frame = tk.Frame(self._body, bg=P.bg_primary,
                                     padx=SP.lg, pady=SP.sm)
        self._stat_frame.pack(fill="x")

        # preview chart
        chart_card = tk.Frame(self._body, bg=P.bg_surface,
                               padx=4, pady=4,
                               highlightthickness=1,
                               highlightbackground=P.border)
        chart_card.pack(fill="x", padx=SP.lg, pady=(0, SP.sm))
        tk.Label(chart_card, text="Preview — Category Breakdown",
                 bg=P.bg_surface, fg=P.text_secondary,
                 font=TY.label()).pack(anchor="w", padx=SP.sm)

        self._fig_prev = Figure(figsize=(8, 2.8), dpi=90,
                                 facecolor=P.bg_surface)
        self._ax_prev_pie  = self._fig_prev.add_subplot(121)
        self._ax_prev_bar  = self._fig_prev.add_subplot(122)
        self._cv_prev = FigureCanvasTkAgg(self._fig_prev, chart_card)
        self._cv_prev.get_tk_widget().pack(fill="x")

        # preview table header
        self._tbl_lbl = tk.Label(self._body, text="",
                                   bg=P.bg_primary, fg=P.text_secondary,
                                   font=TY.label(), padx=SP.lg)
        self._tbl_lbl.pack(anchor="w")

        self._rows_frame = tk.Frame(self._body, bg=P.bg_primary, padx=SP.lg)
        self._rows_frame.pack(fill="x", pady=(0, SP.lg))

    # ── data loading ──────────────────────────────────────────────────────────
    def _load_months(self):
        months = db.available_months()
        cur = date.today().strftime("%Y-%m")
        if cur not in months:
            months.insert(0, cur)

        menu = self._month_cb["menu"]
        menu.delete(0, "end")
        for m in months:
            menu.add_command(label=m,
                             command=lambda v=m: self._v_month.set(v))
        if not self._v_month.get() or self._v_month.get() not in months:
            self._v_month.set(months[0] if months else cur)

        # categories
        cats = db.get_all_categories()
        menu2 = self._cat_cb["menu"]
        menu2.delete(0, "end")
        menu2.add_command(label="All",
                          command=lambda: self._v_cat.set("All"))
        for c in cats:
            menu2.add_command(
                label=c["name"],
                command=lambda n=c["name"]: self._v_cat.set(n))

    def _get_filtered(self) -> list:
        month   = self._v_month.get()
        cat_name = self._v_cat.get()
        group    = self._v_group.get()

        cat_id = None
        if cat_name != "All":
            for c in db.get_all_categories():
                if c["name"] == cat_name:
                    cat_id = c["id"]; break

        exps = db.get_expenses(
            category_id=cat_id,
            month=month if month else None,
        )
        if group != "All":
            exps = [e for e in exps if e["group_type"] == group]
        return exps

    # ── preview render ────────────────────────────────────────────────────────
    def _update_preview(self):
        self._preview_expenses = self._get_filtered()
        self._render_stats()
        self._render_preview_charts()
        self._render_preview_rows()

    def _render_stats(self):
        for w in self._stat_frame.winfo_children():
            w.destroy()

        exps  = self._preview_expenses
        total = sum(e["amount"] for e in exps)
        count = len(exps)
        month = self._v_month.get()

        try:
            days_in = (date.today().day
                       if month == date.today().strftime("%Y-%m")
                       else 30)
        except Exception:
            days_in = 30
        avg = total / max(days_in, 1)

        from collections import Counter
        top = Counter()
        for e in exps:
            top[e["cat_name"]] += e["amount"]
        top_cat = top.most_common(1)[0][0] if top else "—"

        metrics = [
            ("Transactions",  str(count),       P.teal),
            ("Total Amount",  _fmt(total),      P.accent),
            ("Daily Average", _fmt(avg),        P.text_primary),
            ("Top Category",  top_cat,          P.success),
        ]
        self._stat_frame.columnconfigure((0, 1, 2, 3), weight=1)
        for i, (lbl, val, col) in enumerate(metrics):
            card = tk.Frame(self._stat_frame, bg=P.bg_surface, padx=SP.md,
                            pady=SP.sm)
            card.grid(row=0, column=i, sticky="nsew", padx=(0, SP.xs))
            tk.Label(card, text=lbl, bg=P.bg_surface, fg=P.text_secondary,
                     font=TY.caption()).pack(anchor="w")
            tk.Label(card, text=val, bg=P.bg_surface, fg=col,
                     font=TY.h3()).pack(anchor="w")

    def _render_preview_charts(self):
        from collections import defaultdict
        exps = self._preview_expenses

        # doughnut
        by_cat = defaultdict(float)
        for e in exps:
            by_cat[e["cat_name"]] += e["amount"]

        self._ax_prev_pie.clear()
        if by_cat:
            cats   = list(by_cat.keys())
            vals   = [by_cat[c] for c in cats]
            colors = [e["cat_color"] for e in exps
                      if e["cat_name"] in cats][:len(cats)]
            # deduplicate colors in order
            seen, ucolors = set(), []
            for e in exps:
                n = e["cat_name"]
                if n in by_cat and n not in seen:
                    ucolors.append(e["cat_color"]); seen.add(n)
            self._ax_prev_pie.pie(
                vals, colors=ucolors, startangle=90,
                wedgeprops={"width": 0.55, "edgecolor": P.bg_surface,
                            "linewidth": 2})
            total = sum(vals)
            self._ax_prev_pie.text(0, 0, _fmt(total), ha="center",
                                    va="center", color=P.text_primary,
                                    fontsize=9, fontweight="bold")
        self._ax_prev_pie.set_facecolor(P.bg_surface)

        # group bar
        by_grp = defaultdict(float)
        for e in exps:
            by_grp[e["group_type"]] += e["amount"]

        self._ax_prev_bar.clear()
        grp_colors = {"Needs": P.needs, "Wants": P.wants,
                      "Savings/Debt": P.savings}
        grps  = list(by_grp.keys())
        gvals = [by_grp[g] for g in grps]
        gcols = [grp_colors.get(g, P.accent) for g in grps]
        if grps:
            self._ax_prev_bar.barh(grps, gvals, color=gcols, height=0.5)
            self._ax_prev_bar.xaxis.set_major_formatter(
                ticker.FuncFormatter(lambda v, _: _fmt(v)))
        self._ax_prev_bar.set_facecolor(P.bg_surface)
        self._ax_prev_bar.tick_params(colors=P.text_secondary, labelsize=7)
        for sp in self._ax_prev_bar.spines.values():
            sp.set_color(P.border)
        for sp in ["top", "right"]:
            self._ax_prev_bar.spines[sp].set_visible(False)

        self._fig_prev.set_facecolor(P.bg_surface)
        self._fig_prev.tight_layout(pad=0.6)
        self._cv_prev.draw()

    def _render_preview_rows(self):
        for w in self._rows_frame.winfo_children():
            w.destroy()

        exps = self._preview_expenses[:15]
        self._tbl_lbl.configure(
            text=f"Preview (first {len(exps)} of "
                 f"{len(self._preview_expenses)} rows):")

        if not exps:
            tk.Label(self._rows_frame, text="No transactions match the filter.",
                     bg=P.bg_primary, fg=P.text_muted,
                     font=TY.body()).pack(pady=SP.lg)
            return

        # mini table
        hdr = tk.Frame(self._rows_frame, bg=P.bg_raised, pady=4)
        hdr.pack(fill="x")
        for col, w in [("Date", 10), ("Description", 30),
                       ("Category", 18), ("Amount", 10)]:
            tk.Label(hdr, text=col, bg=P.bg_raised, fg=P.text_secondary,
                     font=TY.caption(), width=w, anchor="w",
                     padx=SP.xs).pack(side="left")

        for i, e in enumerate(exps):
            bg = P.bg_surface if i % 2 == 0 else P.bg_raised
            row = tk.Frame(self._rows_frame, bg=bg)
            row.pack(fill="x")
            for txt, w in [
                (e["expense_date"], 10),
                (e["description"][:28], 30),
                (f"{e['cat_icon']} {e['cat_name']}", 18),
                (_fmt(e["amount"]), 10),
            ]:
                tk.Label(row, text=txt, bg=bg, fg=P.text_primary,
                         font=TY.caption(), width=w, anchor="w",
                         padx=SP.xs, pady=3).pack(side="left")

    # ── export actions ────────────────────────────────────────────────────────
    def _export_csv(self):
        if not self._preview_expenses:
            messagebox.showinfo("Nothing to export",
                                "No transactions match the current filter.")
            return
        month = self._v_month.get().replace("-", "_")
        fp = filedialog.asksaveasfilename(
            defaultextension=".csv",
            filetypes=[("CSV files", "*.csv"), ("All files", "*.*")],
            initialfile=f"expenses_{month}.csv",
            title="Save CSV export")
        if not fp:
            return
        try:
            export_csv(self._preview_expenses, fp)
            Toast(self.winfo_toplevel(),
                  f"CSV saved: {os.path.basename(fp)}", "success")
            if messagebox.askyesno("Open file?",
                                   "CSV saved. Open it now?"):
                _open_file(fp)
        except Exception as e:
            messagebox.showerror("Export failed", str(e))

    def _export_pdf(self):
        if not self._preview_expenses:
            messagebox.showinfo("Nothing to export",
                                "No transactions match the current filter.")
            return

        month = self._v_month.get()
        exps  = self._preview_expenses

        # gather stats
        from collections import Counter
        total = sum(e["amount"] for e in exps)
        top   = Counter()
        for e in exps:
            top[e["cat_name"]] += e["amount"]
        stats = {
            "total":        total,
            "count":        len(exps),
            "avg_day":      total / max(date.today().day, 1),
            "top_category": top.most_common(1)[0][0] if top else "—",
        }

        # save charts to temp PNGs
        chart_paths = self._save_charts_as_images(month)

        fp = filedialog.asksaveasfilename(
            defaultextension=".pdf",
            filetypes=[("PDF files", "*.pdf"), ("All files", "*.*")],
            initialfile=f"expense_report_{month}.pdf",
            title="Save PDF Report")
        if not fp:
            return

        try:
            Toast(self.winfo_toplevel(), "Generating PDF…", "info", 1500)
            self.update()
            export_pdf(exps, month, stats, chart_paths, fp)
            for p in chart_paths:
                try: os.unlink(p)
                except: pass
            Toast(self.winfo_toplevel(),
                  f"PDF saved: {os.path.basename(fp)}", "success")
            if messagebox.askyesno("Open file?",
                                   "PDF report saved. Open it now?"):
                _open_file(fp)
        except Exception as e:
            messagebox.showerror("Export failed", str(e))

    def _save_charts_as_images(self, month: str) -> list:
        """Render two charts as temp PNG files and return paths."""
        paths = []
        from collections import defaultdict

        # chart 1: doughnut + group bar
        fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(10, 4),
                                        facecolor="#0F1117")
        rows = db.monthly_by_category(month)
        if rows:
            vals   = [r["total"] for r in rows]
            colors = [r["color"] for r in rows]
            names  = [r["name"]  for r in rows]
            ax1.pie(vals, colors=colors, startangle=90,
                    wedgeprops={"width": 0.55,
                                "edgecolor": "#0F1117", "linewidth": 2})
            total = sum(vals)
            ax1.text(0, 0, f"₹{total:,.0f}", ha="center", va="center",
                     color="white", fontsize=11, fontweight="bold")
            patches = [mpatches.Patch(color=colors[i],
                                      label=f"{names[i]}")
                       for i in range(min(8, len(names)))]
            ax1.legend(handles=patches, loc="lower center",
                       bbox_to_anchor=(0.5, -0.2), ncol=2,
                       fontsize=7, frameon=False, labelcolor="#8B90B0")
        ax1.set_title("Category Breakdown", color="#8B90B0", fontsize=10)
        ax1.set_facecolor("#1A1D27")

        grp_rows = db.monthly_by_group(month)
        grp_colors = {"Needs": "#5B9CF6", "Wants": "#C39BD3",
                      "Savings/Debt": "#4CAF82"}
        if grp_rows:
            gs = [r["group_type"] for r in grp_rows]
            gv = [r["total"] for r in grp_rows]
            gc = [grp_colors.get(g, "#FF8C42") for g in gs]
            ax2.barh(gs, gv, color=gc, height=0.5)
            ax2.xaxis.set_major_formatter(
                ticker.FuncFormatter(lambda v, _: f"₹{v:,.0f}"))
        ax2.set_title("Needs / Wants / Savings", color="#8B90B0", fontsize=10)
        ax2.set_facecolor("#1A1D27")
        ax2.tick_params(colors="#8B90B0", labelsize=8)
        for sp in ax2.spines.values():
            sp.set_color("#2A2F47")

        fig.tight_layout()
        p1 = tempfile.mktemp(suffix=".png")
        fig.savefig(p1, dpi=120, bbox_inches="tight",
                    facecolor="#0F1117")
        plt.close(fig)
        paths.append(p1)

        # chart 2: monthly bar
        fig2, ax3 = plt.subplots(figsize=(10, 3), facecolor="#0F1117")
        m_rows = db.last_n_months_totals(6)
        if m_rows:
            lbls = [datetime.strptime(r["month"], "%Y-%m").strftime("%b '%y")
                    for r in m_rows]
            vals = [r["total"] for r in m_rows]
            cols = ["#FF8C42" if i == len(vals)-1 else "#2DDCCA"
                    for i in range(len(vals))]
            ax3.bar(lbls, vals, color=cols, width=0.55,
                    edgecolor="#0F1117", linewidth=0.5)
            ax3.yaxis.set_major_formatter(
                ticker.FuncFormatter(lambda v, _: f"₹{v:,.0f}"))
        ax3.set_title("Monthly Totals (last 6 months)",
                       color="#8B90B0", fontsize=10)
        ax3.set_facecolor("#1A1D27")
        ax3.tick_params(colors="#8B90B0", labelsize=8)
        for sp in ax3.spines.values():
            sp.set_color("#2A2F47")
        for sp in ["top", "right"]:
            ax3.spines[sp].set_visible(False)
        fig2.tight_layout()
        p2 = tempfile.mktemp(suffix=".png")
        fig2.savefig(p2, dpi=120, bbox_inches="tight",
                     facecolor="#0F1117")
        plt.close(fig2)
        paths.append(p2)

        return paths


# ── platform file opener ──────────────────────────────────────────────────────
def _open_file(path: str) -> None:
    import subprocess, sys
    try:
        if sys.platform.startswith("win"):
            os.startfile(path)
        elif sys.platform == "darwin":
            subprocess.run(["open", path])
        else:
            subprocess.run(["xdg-open", path])
    except Exception:
        pass
