"""
ui/tab_summary.py
─────────────────
Sprint 3 — Monthly Summary Report.

A rich single-page summary for a chosen month:
  • Hero stat block (total, transactions, avg, top category)
  • Spending heatmap calendar (color-coded days)
  • Payment method breakdown (horizontal bars)
  • Biggest single expense + busiest day callouts
  • Category table with % share and bar
  • Quick comparison vs previous month
"""

import tkinter as tk
from tkinter import ttk
from datetime import date, datetime, timedelta
from calendar import monthcalendar
from collections import defaultdict

import matplotlib
matplotlib.use("TkAgg")
from matplotlib.figure import Figure
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
import matplotlib.patches as mpatches
import matplotlib.ticker as ticker

from core.theme import P, TY, SP
from core import database as db
from ui.widgets import ScrollableFrame


def _fmt(v: float) -> str:
    from core.app_state import AppState
    return AppState.fmt_money(v)


def _blend_hex(c1: str, c2: str, t: float) -> str:
    def rgb(h):
        h = h.lstrip("#"); return int(h[0:2],16), int(h[2:4],16), int(h[4:6],16)
    r1,g1,b1=rgb(c1); r2,g2,b2=rgb(c2)
    return "#{:02x}{:02x}{:02x}".format(
        int(r1+(r2-r1)*t), int(g1+(g2-g1)*t), int(b1+(b2-b1)*t))


def _prev_month(month: str) -> str:
    y, m = map(int, month.split("-"))
    m -= 1
    if m == 0: m = 12; y -= 1
    return f"{y}-{m:02d}"


class SummaryTab(tk.Frame):

    def __init__(self, master, **kw):
        super().__init__(master, bg=P.bg_primary, **kw)
        self._build()

    # ── public ───────────────────────────────────────────────────────────────
    def refresh(self):
        self._load_months()
        self._render()

    # ── build ─────────────────────────────────────────────────────────────────
    def _build(self):
        hdr = tk.Frame(self, bg=P.bg_primary, padx=SP.lg, pady=SP.md)
        hdr.pack(fill="x")
        tk.Label(hdr, text="📋  Monthly Summary", bg=P.bg_primary,
                 fg=P.text_primary, font=TY.h2()).pack(side="left")

        ctrl = tk.Frame(hdr, bg=P.bg_primary)
        ctrl.pack(side="right")
        tk.Label(ctrl, text="Month:", bg=P.bg_primary,
                 fg=P.text_secondary, font=TY.label()).pack(side="left")
        self._v_month = tk.StringVar()
        self._month_om = tk.OptionMenu(ctrl, self._v_month, "")
        self._month_om.configure(
            bg=P.bg_raised, fg=P.text_primary, font=TY.body(),
            activebackground=P.bg_hover, activeforeground=P.text_primary,
            highlightthickness=0, relief="flat", cursor="hand2")
        self._month_om["menu"].configure(
            bg=P.bg_raised, fg=P.text_primary, font=TY.body())
        self._month_om.pack(side="left", padx=(4, 0))
        self._v_month.trace_add("write", lambda *_: self._render())

        self._scroll = ScrollableFrame(self, bg=P.bg_primary)
        self._scroll.pack(fill="both", expand=True)
        self._body = self._scroll.inner

    # ── data loading ──────────────────────────────────────────────────────────
    def _load_months(self):
        months = db.available_months()
        cur = date.today().strftime("%Y-%m")
        if cur not in months:
            months.insert(0, cur)
        menu = self._month_om["menu"]
        menu.delete(0, "end")
        for m in months:
            menu.add_command(label=m, command=lambda v=m: self._v_month.set(v))
        if not self._v_month.get() or self._v_month.get() not in months:
            self._v_month.set(months[0] if months else cur)

    # ── render ─────────────────────────────────────────────────────────────────
    def _render(self):
        for w in self._body.winfo_children():
            w.destroy()
        month = self._v_month.get()
        if not month:
            return

        summary  = db.monthly_summary(month)
        prev_m   = _prev_month(month)
        prev_sum = db.monthly_summary(prev_m)
        cats_data = db.monthly_by_category(month)
        daily    = db.daily_totals_for_month(month)

        self._render_hero(summary, prev_sum)
        self._render_calendar_heatmap(month, daily)
        self._render_cats_table(cats_data, summary["total"])
        self._render_payment_bars(summary)
        self._render_callouts(summary)
        self._render_comparison_chart(month, prev_m)

    # ── hero stats ────────────────────────────────────────────────────────────
    def _render_hero(self, s: dict, p: dict):
        frame = tk.Frame(self._body, bg=P.bg_primary, padx=SP.lg, pady=SP.sm)
        frame.pack(fill="x")
        frame.columnconfigure((0,1,2,3), weight=1)

        diff = s["total"] - p["total"]
        diff_pct = (diff / p["total"] * 100) if p["total"] else 0
        sign = "▲" if diff > 0 else "▼"
        diff_col = P.danger if diff > 0 else P.success

        items = [
            ("Total Spent",    _fmt(s["total"]),        P.accent),
            ("Transactions",   str(s["count"]),          P.teal),
            ("vs Prev Month",  f"{sign} {abs(diff_pct):.1f}%", diff_col),
            ("Top Category",
             f"{s['top_cat']['icon']} {s['top_cat']['name']}" if s["top_cat"] else "—",
             P.success),
        ]
        for i, (lbl, val, col) in enumerate(items):
            card = tk.Frame(frame, bg=P.bg_surface, padx=SP.md, pady=SP.md)
            card.grid(row=0, column=i, sticky="nsew", padx=(0, SP.xs))
            tk.Label(card, text=lbl, bg=P.bg_surface, fg=P.text_secondary,
                     font=TY.caption()).pack(anchor="w")
            tk.Label(card, text=val, bg=P.bg_surface, fg=col,
                     font=TY.h2()).pack(anchor="w", pady=(2, 0))

    # ── calendar heatmap ──────────────────────────────────────────────────────
    def _render_calendar_heatmap(self, month: str, daily_rows: list):
        sect = tk.Frame(self._body, bg=P.bg_primary, padx=SP.lg)
        sect.pack(fill="x", pady=(SP.md, 0))
        tk.Label(sect, text="Spending Heatmap", bg=P.bg_primary,
                 fg=P.text_secondary, font=TY.label()).pack(anchor="w")

        cal_card = tk.Frame(self._body, bg=P.bg_surface,
                            highlightthickness=1, highlightbackground=P.border,
                            padx=SP.md, pady=SP.md)
        cal_card.pack(fill="x", padx=SP.lg, pady=(SP.xs, SP.sm))

        # build day→amount map
        day_totals = {r["day"]: r["total"] for r in daily_rows}
        max_amt = max(day_totals.values(), default=1)

        y, m = map(int, month.split("-"))
        weeks = monthcalendar(y, m)

        # day-of-week headers
        hdr = tk.Frame(cal_card, bg=P.bg_surface)
        hdr.pack(fill="x")
        for dow in ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"]:
            tk.Label(hdr, text=dow, bg=P.bg_surface, fg=P.text_muted,
                     font=TY.caption(), width=5, anchor="center").pack(side="left")

        for week in weeks:
            row = tk.Frame(cal_card, bg=P.bg_surface)
            row.pack(fill="x", pady=1)
            for day_num in week:
                if day_num == 0:
                    tk.Frame(row, bg=P.bg_surface, width=40, height=32).pack(
                        side="left", padx=1)
                    continue
                day_str = f"{month}-{day_num:02d}"
                amt     = day_totals.get(day_str, 0)
                # intensity: 0→bg_raised, 1→accent
                t = (amt / max_amt) ** 0.5 if max_amt > 0 else 0
                cell_bg = _blend_hex(P.accent, P.bg_raised, 1 - t) if amt > 0 else P.bg_raised
                cell = tk.Frame(row, bg=cell_bg, width=40, height=32)
                cell.pack(side="left", padx=1)
                cell.pack_propagate(False)
                fg = P.text_primary if t > 0.5 else P.text_muted
                tk.Label(cell, text=str(day_num), bg=cell_bg, fg=fg,
                         font=TY.caption()).pack(expand=True)
                if amt > 0:
                    cell.bind("<Enter>", lambda e, d=day_str, a=amt:
                              self._show_tooltip(e, f"{d}\n{_fmt(a)}"))
                    cell.bind("<Leave>", self._hide_tooltip)

        # legend
        leg = tk.Frame(cal_card, bg=P.bg_surface)
        leg.pack(anchor="e", pady=(SP.xs, 0))
        tk.Label(leg, text="Low", bg=P.bg_surface, fg=P.text_muted,
                 font=TY.caption()).pack(side="left")
        for t in [0.1, 0.3, 0.5, 0.7, 0.9]:
            c = _blend_hex(P.accent, P.bg_raised, 1-t)
            tk.Frame(leg, bg=c, width=14, height=10).pack(
                side="left", padx=1)
        tk.Label(leg, text="High", bg=P.bg_surface, fg=P.text_muted,
                 font=TY.caption()).pack(side="left", padx=(2, 0))

    def _show_tooltip(self, event, text: str):
        self._tip = tk.Toplevel(self)
        self._tip.overrideredirect(True)
        self._tip.attributes("-topmost", True)
        tk.Label(self._tip, text=text, bg=P.bg_raised, fg=P.text_primary,
                 font=TY.caption(), padx=6, pady=4).pack()
        x = event.widget.winfo_rootx() + 20
        y = event.widget.winfo_rooty() + 20
        self._tip.geometry(f"+{x}+{y}")

    def _hide_tooltip(self, _event):
        if hasattr(self, "_tip") and self._tip:
            self._tip.destroy()
            self._tip = None

    # ── category table ────────────────────────────────────────────────────────
    def _render_cats_table(self, cats: list, total: float):
        sect = tk.Frame(self._body, bg=P.bg_primary, padx=SP.lg)
        sect.pack(fill="x", pady=(SP.sm, 0))
        tk.Label(sect, text="Category Breakdown", bg=P.bg_primary,
                 fg=P.text_secondary, font=TY.label()).pack(anchor="w")

        tbl = tk.Frame(self._body, bg=P.bg_surface,
                       highlightthickness=1, highlightbackground=P.border,
                       padx=SP.md, pady=SP.sm)
        tbl.pack(fill="x", padx=SP.lg, pady=(SP.xs, SP.sm))

        # header
        hdr = tk.Frame(tbl, bg=P.bg_raised)
        hdr.pack(fill="x", pady=(0, 2))
        for txt, w in [("Category", 22), ("Amount", 12), ("Share", 8), ("Bar", 30)]:
            tk.Label(hdr, text=txt, bg=P.bg_raised, fg=P.text_secondary,
                     font=TY.label(), width=w, anchor="w",
                     padx=SP.xs).pack(side="left")

        for i, c in enumerate(cats):
            bg  = P.bg_surface if i % 2 == 0 else P.bg_raised
            pct = (c["total"] / total * 100) if total else 0
            row = tk.Frame(tbl, bg=bg)
            row.pack(fill="x", pady=1)

            # swatch + name
            name_frame = tk.Frame(row, bg=bg, width=180)
            name_frame.pack(side="left")
            name_frame.pack_propagate(False)
            tk.Frame(name_frame, bg=c["color"], width=4).pack(
                side="left", fill="y")
            tk.Label(name_frame, text=f"{c['icon']} {c['name']}",
                     bg=bg, fg=P.text_primary, font=TY.body(),
                     padx=SP.xs).pack(side="left", fill="x")

            tk.Label(row, text=_fmt(c["total"]), bg=bg, fg=P.accent,
                     font=(TY.family, TY.size_base, "bold"),
                     width=12, anchor="w").pack(side="left")
            tk.Label(row, text=f"{pct:.1f}%", bg=bg, fg=P.text_secondary,
                     font=TY.caption(), width=8, anchor="w").pack(side="left")

            # mini bar
            bar_frame = tk.Frame(row, bg=P.bg_raised, height=8, width=200)
            bar_frame.pack(side="left", padx=SP.sm)
            bar_frame.pack_propagate(False)
            fill_w = max(int(pct / 100 * 200), 2) if pct > 0 else 0
            tk.Frame(bar_frame, bg=c["color"], width=fill_w, height=8).place(
                x=0, y=0)

    # ── payment bars ──────────────────────────────────────────────────────────
    def _render_payment_bars(self, summary: dict):
        by_pay = summary.get("by_pay", [])
        if not by_pay:
            return
        total = sum(r["s"] for r in by_pay) or 1

        sect = tk.Frame(self._body, bg=P.bg_primary, padx=SP.lg)
        sect.pack(fill="x", pady=(SP.sm, 0))
        tk.Label(sect, text="Payment Method Breakdown", bg=P.bg_primary,
                 fg=P.text_secondary, font=TY.label()).pack(anchor="w")

        card = tk.Frame(self._body, bg=P.bg_surface,
                        highlightthickness=1, highlightbackground=P.border,
                        padx=SP.lg, pady=SP.md)
        card.pack(fill="x", padx=SP.lg, pady=(SP.xs, SP.sm))

        pay_colors = {
            "UPI": P.accent, "Cash": P.teal,
            "Card": P.needs, "Net Banking": P.savings,
            "Wallet": P.wants,
        }
        for r in by_pay:
            pct = r["s"] / total
            col = pay_colors.get(r["payment"], P.text_secondary)

            row = tk.Frame(card, bg=P.bg_surface)
            row.pack(fill="x", pady=2)
            tk.Label(row, text=r["payment"], bg=P.bg_surface,
                     fg=P.text_primary, font=TY.body(),
                     width=14, anchor="w").pack(side="left")
            tk.Label(row, text=_fmt(r["s"]), bg=P.bg_surface,
                     fg=col, font=(TY.family, TY.size_base, "bold"),
                     width=12, anchor="w").pack(side="left")
            tk.Label(row, text=f"{pct*100:.1f}%  ({r['cnt']} txns)",
                     bg=P.bg_surface, fg=P.text_muted,
                     font=TY.caption()).pack(side="left")

            track = tk.Frame(row, bg=P.bg_raised, height=6)
            track.pack(side="left", fill="x", expand=True, padx=(SP.sm, 0))
            track.pack_propagate(False)
            tk.Frame(track, bg=col, height=6).place(
                relx=0, rely=0, relwidth=pct, relheight=1)

    # ── callouts ──────────────────────────────────────────────────────────────
    def _render_callouts(self, summary: dict):
        row = tk.Frame(self._body, bg=P.bg_primary, padx=SP.lg)
        row.pack(fill="x", pady=(SP.sm, 0))
        row.columnconfigure(0, weight=1)
        row.columnconfigure(1, weight=1)

        def callout(parent, col, icon, title, body, color):
            card = tk.Frame(parent, bg=P.bg_surface,
                            highlightthickness=1,
                            highlightbackground=color,
                            padx=SP.md, pady=SP.md)
            card.grid(row=0, column=col, sticky="nsew",
                      padx=(0 if col else 0, SP.xs if col == 0 else 0))
            tk.Label(card, text=icon, bg=P.bg_surface, fg=color,
                     font=(TY.family, TY.size_xl)).pack(side="left",
                                                         padx=(0, SP.sm))
            info = tk.Frame(card, bg=P.bg_surface)
            info.pack(side="left", fill="x", expand=True)
            tk.Label(info, text=title, bg=P.bg_surface, fg=P.text_secondary,
                     font=TY.caption()).pack(anchor="w")
            tk.Label(info, text=body, bg=P.bg_surface, fg=color,
                     font=(TY.family, TY.size_md, "bold")).pack(anchor="w")

        b = summary.get("biggest")
        if b:
            callout(row, 0, "💸", "Biggest Single Expense",
                    f"{b['description'][:30]}  —  {_fmt(b['amount'])}",
                    P.danger)

        bz = summary.get("busiest")
        if bz:
            callout(row, 1, "📅", "Busiest Spending Day",
                    f"{bz['expense_date']}  —  {_fmt(bz['s'])}",
                    P.accent)

    # ── month comparison chart ────────────────────────────────────────────────
    def _render_comparison_chart(self, month: str, prev_m: str):
        sect = tk.Frame(self._body, bg=P.bg_primary, padx=SP.lg)
        sect.pack(fill="x", pady=(SP.sm, 0))
        tk.Label(sect, text=f"This month vs {prev_m}", bg=P.bg_primary,
                 fg=P.text_secondary, font=TY.label()).pack(anchor="w")

        card = tk.Frame(self._body, bg=P.bg_surface,
                        highlightthickness=1, highlightbackground=P.border,
                        padx=4, pady=4)
        card.pack(fill="x", padx=SP.lg, pady=(SP.xs, SP.lg))

        # build daily data for both months
        def daily_map(m: str) -> dict:
            rows = db.daily_totals_for_month(m)
            return {int(r["day"][-2:]): r["total"] for r in rows}

        cur_map  = daily_map(month)
        prev_map = daily_map(prev_m)

        # get number of days in each month
        y, mo = map(int, month.split("-"))
        import calendar
        days_cur  = calendar.monthrange(y, mo)[1]
        y2, mo2 = map(int, prev_m.split("-"))
        days_prev = calendar.monthrange(y2, mo2)[1]
        max_days  = max(days_cur, days_prev)

        x      = list(range(1, max_days+1))
        y_cur  = [cur_map.get(d, 0)  for d in x]
        y_prev = [prev_map.get(d, 0) for d in x]

        fig = Figure(figsize=(8.5, 2.6), dpi=90, facecolor=P.bg_surface)
        ax  = fig.add_subplot(111)
        ax.bar([i-0.2 for i in x], y_cur,  width=0.4,
               color=P.accent, label=month, alpha=0.9)
        ax.bar([i+0.2 for i in x], y_prev, width=0.4,
               color=P.teal,   label=prev_m, alpha=0.7)
        ax.set_facecolor(P.bg_surface)
        ax.tick_params(colors=P.text_secondary, labelsize=7)
        for sp in ax.spines.values():
            sp.set_color(P.border)
        for sp in ["top", "right"]:
            ax.spines[sp].set_visible(False)
        ax.yaxis.set_major_formatter(
            ticker.FuncFormatter(lambda v, _: _fmt(v)))
        ax.legend(fontsize=7, frameon=False, labelcolor=P.text_secondary)
        fig.tight_layout(pad=0.5)

        canvas = FigureCanvasTkAgg(fig, card)
        canvas.get_tk_widget().pack(fill="x")
        canvas.draw()
