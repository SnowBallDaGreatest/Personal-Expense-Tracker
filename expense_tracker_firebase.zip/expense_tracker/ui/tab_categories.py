"""
ui/tab_categories.py
────────────────────
Category management panel.

Features:
  • View all categories with icon, colour, group
  • Add new category
  • Edit existing
  • Delete (with safety check if expenses exist)

Agile note: One file = one feature. No dependencies on other tabs.
"""

import tkinter as tk
from tkinter import messagebox, colorchooser
from typing import Optional

from core.theme import P, TY, SP, GROUP_TYPES, CATEGORY_ICONS
from core import database as db
from ui.widgets import StyledButton, Toast, ScrollableFrame


class CategoriesTab(tk.Frame):

    def __init__(self, master, on_changed: callable = None, **kw):
        super().__init__(master, bg=P.bg_primary, **kw)
        self._on_changed = on_changed
        self._editing_id: Optional[int] = None
        self._selected_color = "#5DCAA5"
        self._build()

    # ── public ──────────────────────────────────────────────────────────────
    def refresh(self):
        self._render_list()

    # ── build ────────────────────────────────────────────────────────────────
    def _build(self):
        # header
        hdr = tk.Frame(self, bg=P.bg_primary, padx=SP.lg, pady=SP.md)
        hdr.pack(fill="x")
        tk.Label(hdr, text="🏷️  Categories", bg=P.bg_primary,
                 fg=P.text_primary, font=TY.h2()).pack(side="left")

        # ── form card ──────────────────────────────────────────────────────
        card = tk.Frame(self, bg=P.bg_surface,
                        highlightthickness=1,
                        highlightbackground=P.border,
                        padx=SP.xl, pady=SP.lg)
        card.pack(fill="x", padx=SP.lg, pady=(0, SP.md))

        self._form_title = tk.Label(card, text="Add Category",
                                     bg=P.bg_surface, fg=P.text_primary,
                                     font=TY.h3())
        self._form_title.grid(row=0, column=0, columnspan=5, sticky="w",
                               pady=(0, SP.sm))

        tk.Label(card, text="Name *", bg=P.bg_surface,
                 fg=P.text_secondary, font=TY.label()).grid(
            row=1, column=0, sticky="w", pady=(0, 2))
        tk.Label(card, text="Icon", bg=P.bg_surface,
                 fg=P.text_secondary, font=TY.label()).grid(
            row=1, column=1, sticky="w", padx=(SP.md, 0), pady=(0, 2))
        tk.Label(card, text="Group *", bg=P.bg_surface,
                 fg=P.text_secondary, font=TY.label()).grid(
            row=1, column=2, sticky="w", padx=(SP.md, 0), pady=(0, 2))
        tk.Label(card, text="Colour *", bg=P.bg_surface,
                 fg=P.text_secondary, font=TY.label()).grid(
            row=1, column=3, sticky="w", padx=(SP.md, 0), pady=(0, 2))

        self._v_name  = tk.StringVar()
        self._v_icon  = tk.StringVar(value="💰")
        self._v_group = tk.StringVar(value="Wants")

        tk.Entry(card, textvariable=self._v_name,
                 bg=P.bg_input, fg=P.text_primary,
                 insertbackground=P.accent, relief="flat",
                 font=TY.body(), width=20,
                 highlightthickness=1,
                 highlightbackground=P.border,
                 highlightcolor=P.border_focus).grid(
            row=2, column=0, sticky="ew", ipady=5)

        # icon dropdown
        from tkinter import ttk
        sn = "CatIcon.TCombobox"
        s = ttk.Style()
        s.configure(sn, fieldbackground=P.bg_input, background=P.bg_raised,
                    foreground=P.text_primary, arrowcolor=P.accent)
        self._icon_cb = ttk.Combobox(card, textvariable=self._v_icon,
                                      values=CATEGORY_ICONS, state="readonly",
                                      width=6, style=sn)
        self._icon_cb.grid(row=2, column=1, sticky="ew", padx=(SP.md, 0))

        # group dropdown
        sn2 = "CatGrp.TCombobox"
        s.configure(sn2, fieldbackground=P.bg_input, background=P.bg_raised,
                    foreground=P.text_primary, arrowcolor=P.accent)
        self._group_cb = ttk.Combobox(card, textvariable=self._v_group,
                                       values=GROUP_TYPES, state="readonly",
                                       width=14, style=sn2)
        self._group_cb.grid(row=2, column=2, sticky="ew", padx=(SP.md, 0))

        # colour picker
        self._col_btn = tk.Button(
            card, text="  Pick  ",
            bg=self._selected_color, fg="white",
            relief="flat", cursor="hand2", font=TY.body(),
            command=self._pick_colour)
        self._col_btn.grid(row=2, column=3, padx=(SP.md, 0), ipady=4)

        # action buttons
        btn_row = tk.Frame(card, bg=P.bg_surface)
        btn_row.grid(row=3, column=0, columnspan=5, sticky="ew",
                     pady=(SP.md, 0))
        self._save_btn = StyledButton(btn_row, "💾  Save Category",
                                       self._save, variant="primary")
        self._save_btn.pack(side="left")
        StyledButton(btn_row, "✖  Clear", self._clear_form,
                     variant="ghost").pack(side="left", padx=SP.sm)

        # ── category list ──────────────────────────────────────────────────
        tk.Label(self, text="All Categories", bg=P.bg_primary,
                 fg=P.text_secondary, font=TY.label(),
                 padx=SP.lg).pack(anchor="w", pady=(0, SP.xs))

        scroll = ScrollableFrame(self, bg=P.bg_primary)
        scroll.pack(fill="both", expand=True)
        self._list_frame = scroll.inner

        self._render_list()

    # ── helpers ──────────────────────────────────────────────────────────────
    def _pick_colour(self):
        result = colorchooser.askcolor(
            color=self._selected_color, title="Pick category colour")
        if result and result[1]:
            self._selected_color = result[1]
            self._col_btn.configure(bg=self._selected_color)

    def _clear_form(self):
        self._editing_id = None
        self._v_name.set("")
        self._v_icon.set("💰")
        self._v_group.set("Wants")
        self._selected_color = "#5DCAA5"
        self._col_btn.configure(bg=self._selected_color)
        self._form_title.configure(text="Add Category")

    def _load_for_edit(self, cat):
        self._editing_id = cat["id"]
        self._v_name.set(cat["name"])
        self._v_icon.set(cat["icon"])
        self._v_group.set(cat["group_type"])
        self._selected_color = cat["color"]
        self._col_btn.configure(bg=cat["color"])
        self._form_title.configure(text=f"Edit: {cat['name']}")

    def _save(self):
        name  = self._v_name.get().strip()
        icon  = self._v_icon.get()
        group = self._v_group.get()
        color = self._selected_color

        if not name:
            import tkinter.messagebox as mb
            mb.showerror("Error", "Category name is required.")
            return

        if self._editing_id:
            db.update_category(self._editing_id, name, color, group, icon)
            msg = "Category updated!"
        else:
            try:
                db.add_category(name, color, group, icon)
                msg = "Category added!"
            except Exception as e:
                messagebox.showerror("Error", f"Could not save: {e}")
                return

        self._clear_form()
        self._render_list()
        Toast(self.winfo_toplevel(), msg, "success")
        if self._on_changed:
            self._on_changed()

    def _delete_cat(self, cat_id: int, cat_name: str):
        if not messagebox.askyesno(
                "Delete Category",
                f'Delete "{cat_name}"?\n\n'
                "Expenses in this category will lose their category link."):
            return
        db.delete_category(cat_id)
        self._render_list()
        Toast(self.winfo_toplevel(), "Category deleted.", "info")
        if self._on_changed:
            self._on_changed()

    def _render_list(self):
        for w in self._list_frame.winfo_children():
            w.destroy()

        cats = db.get_all_categories()
        if not cats:
            tk.Label(self._list_frame, text="No categories yet.",
                     bg=P.bg_primary, fg=P.text_muted,
                     font=TY.body(), pady=SP.xl).pack()
            return

        # group headers
        groups: dict = {}
        for c in cats:
            groups.setdefault(c["group_type"], []).append(c)

        group_colors = {"Needs": P.needs, "Wants": P.wants,
                        "Savings/Debt": P.savings}
        group_order  = ["Needs", "Wants", "Savings/Debt"]

        for grp in group_order:
            if grp not in groups:
                continue
            grp_hdr = tk.Frame(self._list_frame, bg=P.bg_primary, padx=SP.lg)
            grp_hdr.pack(fill="x", pady=(SP.sm, SP.xs))
            col = group_colors.get(grp, P.accent)
            tk.Label(grp_hdr, text=f"▌ {grp}", bg=P.bg_primary,
                     fg=col, font=(TY.family, TY.size_base, "bold")).pack(
                side="left")

            for i, cat in enumerate(groups[grp]):
                bg = P.bg_surface if i % 2 == 0 else P.bg_raised
                row = tk.Frame(self._list_frame, bg=bg,
                               padx=SP.lg, pady=4,
                               highlightthickness=0)
                row.pack(fill="x")

                # colour swatch
                tk.Frame(row, bg=cat["color"], width=8).pack(
                    side="left", fill="y", padx=(0, SP.sm))

                # icon + name
                tk.Label(row, text=cat["icon"], bg=bg, fg=cat["color"],
                         font=(TY.family, TY.size_lg)).pack(side="left", padx=(0, SP.xs))
                tk.Label(row, text=cat["name"], bg=bg, fg=P.text_primary,
                         font=TY.body()).pack(side="left", fill="x", expand=True)

                # hex colour label
                tk.Label(row, text=cat["color"], bg=bg, fg=P.text_muted,
                         font=TY.caption(), width=8).pack(side="left")

                # edit / delete buttons
                StyledButton(row, "✏️", lambda c=cat: self._load_for_edit(c),
                             variant="ghost").pack(side="right")
                StyledButton(row, "🗑️",
                             lambda cid=cat["id"], cn=cat["name"]: self._delete_cat(cid, cn),
                             variant="danger").pack(side="right", padx=SP.xs)
