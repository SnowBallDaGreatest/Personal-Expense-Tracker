"""
ui/tab_search.py
────────────────
Sprint 3 — Smart Search with autocomplete.

Features:
  • Live full-text search across description, category, notes, payment
  • Autocomplete dropdown from past descriptions
  • Highlighted match results
  • Quick-filter chips (Needs / Wants / Savings / Overbudget)
  • Click result to edit expense
"""

import tkinter as tk
from tkinter import ttk
from typing import Callable, Optional

from core.theme import P, TY, SP
from core import database as db
from ui.widgets import StyledButton, Toast


def _fmt(v: float) -> str:
    from core.app_state import AppState
    return AppState.fmt_money(v)


def _blend_hex(c1: str, c2: str, t: float) -> str:
    def rgb(h):
        h = h.lstrip("#"); return int(h[0:2],16), int(h[2:4],16), int(h[4:6],16)
    r1,g1,b1=rgb(c1); r2,g2,b2=rgb(c2)
    return "#{:02x}{:02x}{:02x}".format(
        int(r1+(r2-r1)*t), int(g1+(g2-g1)*t), int(b1+(b2-b1)*t))


class SearchTab(tk.Frame):

    def __init__(self, master, on_edit: Callable = None, **kw):
        super().__init__(master, bg=P.bg_primary, **kw)
        self._on_edit = on_edit
        self._results: list = []
        self._ac_visible = False
        self._build()

    # ── public ───────────────────────────────────────────────────────────────
    def refresh(self):
        pass  # search is stateless; nothing to pre-load

    def focus_search(self):
        self._search_entry.focus_set()

    # ── build ─────────────────────────────────────────────────────────────────
    def _build(self):
        hdr = tk.Frame(self, bg=P.bg_primary, padx=SP.lg, pady=SP.md)
        hdr.pack(fill="x")
        tk.Label(hdr, text="🔍  Smart Search", bg=P.bg_primary,
                 fg=P.text_primary, font=TY.h2()).pack(side="left")

        # ── search bar ────────────────────────────────────────────────────
        bar_outer = tk.Frame(self, bg=P.bg_primary, padx=SP.lg)
        bar_outer.pack(fill="x", pady=(0, SP.sm))

        search_frame = tk.Frame(bar_outer, bg=P.bg_surface,
                                highlightthickness=2,
                                highlightbackground=P.accent)
        search_frame.pack(fill="x")

        tk.Label(search_frame, text="🔍", bg=P.bg_surface,
                 fg=P.text_muted, font=(TY.family, TY.size_lg),
                 padx=SP.sm).pack(side="left")

        self._v_search = tk.StringVar()
        self._v_search.trace_add("write", self._on_search_change)

        self._search_entry = tk.Entry(
            search_frame, textvariable=self._v_search,
            bg=P.bg_surface, fg=P.text_primary,
            insertbackground=P.accent, relief="flat",
            font=(TY.family, TY.size_lg),
            highlightthickness=0)
        self._search_entry.pack(side="left", fill="x", expand=True,
                                ipady=10)
        self._search_entry.bind("<Down>",   self._ac_down)
        self._search_entry.bind("<Return>", self._do_search)
        self._search_entry.bind("<Escape>", self._clear_search)

        tk.Button(search_frame, text="✕", bg=P.bg_surface,
                  fg=P.text_muted, relief="flat", cursor="hand2",
                  font=TY.body(), padx=SP.sm,
                  command=self._clear_search).pack(side="right")

        # autocomplete dropdown
        self._ac_frame = tk.Frame(self, bg=P.bg_raised,
                                   highlightthickness=1,
                                   highlightbackground=P.border)
        # (packed/hidden dynamically)

        # ── filter chips ──────────────────────────────────────────────────
        chips_row = tk.Frame(self, bg=P.bg_primary, padx=SP.lg)
        chips_row.pack(fill="x", pady=(0, SP.sm))

        tk.Label(chips_row, text="Filter:", bg=P.bg_primary,
                 fg=P.text_muted, font=TY.caption()).pack(side="left")

        self._active_chip = tk.StringVar(value="All")
        chips = [
            ("All",           P.text_muted),
            ("Needs",         P.needs),
            ("Wants",         P.wants),
            ("Savings/Debt",  P.savings),
        ]
        for label, col in chips:
            self._make_chip(chips_row, label, col)

        # ── stats bar ─────────────────────────────────────────────────────
        self._stats_lbl = tk.Label(self, text="Type to search…",
                                    bg=P.bg_primary, fg=P.text_muted,
                                    font=TY.caption(), padx=SP.lg)
        self._stats_lbl.pack(anchor="w")

        # ── results ───────────────────────────────────────────────────────
        results_container = tk.Frame(self, bg=P.bg_primary, padx=SP.lg)
        results_container.pack(fill="both", expand=True)

        # canvas + scrollbar for results
        self._canvas = tk.Canvas(results_container, bg=P.bg_primary,
                                  highlightthickness=0)
        sb = ttk.Scrollbar(results_container, orient="vertical",
                            command=self._canvas.yview)
        self._canvas.configure(yscrollcommand=sb.set)
        sb.pack(side="right", fill="y")
        self._canvas.pack(side="left", fill="both", expand=True)

        self._results_frame = tk.Frame(self._canvas, bg=P.bg_primary)
        self._win = self._canvas.create_window(
            (0, 0), window=self._results_frame, anchor="nw")

        self._results_frame.bind("<Configure>",
            lambda _: self._canvas.configure(
                scrollregion=self._canvas.bbox("all")))
        self._canvas.bind("<Configure>",
            lambda e: self._canvas.itemconfig(self._win, width=e.width))
        self._canvas.bind("<MouseWheel>",
            lambda e: self._canvas.yview_scroll(
                int(-1*(e.delta/120)), "units"))

    # ── chip builder ──────────────────────────────────────────────────────────
    def _make_chip(self, parent, label: str, color: str):
        def on_click():
            self._active_chip.set(label)
            # recolor all chips
            for child in parent.winfo_children():
                if hasattr(child, "_chip_label"):
                    is_active = child._chip_label == label
                    chip_col = child._chip_color
                    bg = chip_col if is_active else _blend_hex(chip_col, P.bg_raised, 0.85)
                    fg = P.bg_primary if is_active else chip_col
                    child.configure(bg=bg, fg=fg)
            self._do_search()

        chip_bg = _blend_hex(color, P.bg_raised, 0.85)
        btn = tk.Label(parent, text=label, bg=chip_bg, fg=color,
                       font=TY.caption(), padx=8, pady=3, cursor="hand2")
        btn._chip_label = label
        btn._chip_color = color
        btn.pack(side="left", padx=(4, 0))
        btn.bind("<Button-1>", lambda _: on_click())
        return btn

    # ── autocomplete ──────────────────────────────────────────────────────────
    def _show_autocomplete(self, suggestions: list):
        for w in self._ac_frame.winfo_children():
            w.destroy()

        if not suggestions:
            self._hide_autocomplete()
            return

        for sug in suggestions[:6]:
            lbl = tk.Label(self._ac_frame, text=sug, bg=P.bg_raised,
                           fg=P.text_primary, font=TY.body(),
                           padx=SP.md, pady=5, anchor="w", cursor="hand2")
            lbl.pack(fill="x")
            lbl.bind("<Enter>",
                     lambda e, l=lbl: l.configure(bg=P.bg_hover))
            lbl.bind("<Leave>",
                     lambda e, l=lbl: l.configure(bg=P.bg_raised))
            lbl.bind("<Button-1>",
                     lambda e, s=sug: self._select_suggestion(s))

        # place dropdown below search bar
        self._search_entry.update_idletasks()
        x = self._search_entry.winfo_rootx() - self.winfo_rootx()
        y = (self._search_entry.winfo_rooty()
             - self.winfo_rooty()
             + self._search_entry.winfo_height() + 2)
        self._ac_frame.place(x=SP.lg, y=y, relwidth=0.97)
        self._ac_frame.lift()
        self._ac_visible = True

    def _hide_autocomplete(self):
        self._ac_frame.place_forget()
        self._ac_visible = False

    def _select_suggestion(self, text: str):
        self._v_search.set(text)
        self._hide_autocomplete()
        self._do_search()

    def _ac_down(self, _e):
        children = self._ac_frame.winfo_children()
        if children:
            children[0].focus_set()

    # ── search logic ──────────────────────────────────────────────────────────
    def _on_search_change(self, *_):
        term = self._v_search.get().strip()
        if len(term) >= 2:
            sugs = db.search_descriptions(term)
            self._show_autocomplete(sugs)
        else:
            self._hide_autocomplete()
        if len(term) >= 1:
            self._do_search()
        else:
            self._clear_results()

    def _do_search(self, _event=None):
        self._hide_autocomplete()
        term = self._v_search.get().strip()
        if not term:
            self._clear_results()
            return

        all_results = db.search_expenses_full(term)

        # apply group chip filter
        grp = self._active_chip.get()
        if grp != "All":
            all_results = [r for r in all_results if r["group_type"] == grp]

        self._results = all_results
        total = sum(r["amount"] for r in all_results)
        self._stats_lbl.configure(
            text=f'{len(all_results)} results for "{term}"  ·  Total: {_fmt(total)}',
            fg=P.text_secondary)
        self._render_results(term)

    def _clear_search(self, _event=None):
        self._v_search.set("")
        self._hide_autocomplete()
        self._clear_results()
        self._stats_lbl.configure(text="Type to search…", fg=P.text_muted)

    def _clear_results(self):
        for w in self._results_frame.winfo_children():
            w.destroy()
        self._results = []

    # ── render results ────────────────────────────────────────────────────────
    def _render_results(self, term: str):
        for w in self._results_frame.winfo_children():
            w.destroy()

        if not self._results:
            tk.Label(self._results_frame, text="No matching expenses found.",
                     bg=P.bg_primary, fg=P.text_muted, font=TY.body(),
                     pady=SP.xl).pack()
            return

        for i, e in enumerate(self._results[:100]):
            bg = P.bg_surface if i % 2 == 0 else P.bg_raised
            row = tk.Frame(self._results_frame, bg=bg, pady=SP.xs,
                           cursor="hand2")
            row.pack(fill="x", pady=1)
            row.bind("<Button-1>", lambda ev, ex=e: self._edit(ex))
            row.bind("<Enter>",    lambda ev, r=row, b=bg: r.configure(bg=P.bg_hover))
            row.bind("<Leave>",    lambda ev, r=row, b=bg: r.configure(bg=b))

            # colour stripe
            tk.Frame(row, bg=e["cat_color"], width=4).pack(
                side="left", fill="y")

            # icon
            tk.Label(row, text=e["cat_icon"], bg=bg, fg=e["cat_color"],
                     font=(TY.family, TY.size_lg),
                     padx=SP.xs).pack(side="left")

            # info
            info = tk.Frame(row, bg=bg)
            info.pack(side="left", fill="x", expand=True, padx=SP.xs)

            # highlight matched term in description
            desc = e["description"]
            self._render_highlighted(info, desc, term, bg)

            meta = (f"{e['expense_date']}  ·  "
                    f"{e['cat_name']}  ·  "
                    f"{e['payment']}"
                    + (f"  ·  {e['notes']}" if e["notes"] else ""))
            tk.Label(info, text=meta, bg=bg, fg=P.text_muted,
                     font=TY.caption()).pack(anchor="w")

            # amount
            tk.Label(row, text=_fmt(e["amount"]), bg=bg, fg=P.accent,
                     font=(TY.family, TY.size_base, "bold"),
                     padx=SP.md).pack(side="right")

            # edit button (shows on hover via binding)
            edit_btn = tk.Label(row, text="✏️", bg=bg, fg=P.text_muted,
                                cursor="hand2", font=TY.body(), padx=SP.xs)
            edit_btn.pack(side="right")
            edit_btn.bind("<Button-1>", lambda ev, ex=e: self._edit(ex))

    def _render_highlighted(self, parent, text: str, term: str, bg: str):
        """Render text with the search term highlighted."""
        frame = tk.Frame(parent, bg=bg)
        frame.pack(anchor="w")
        low_text = text.lower()
        low_term = term.lower()
        idx = low_text.find(low_term)
        if idx == -1:
            tk.Label(frame, text=text, bg=bg, fg=P.text_primary,
                     font=TY.body()).pack(side="left")
            return
        # before match
        if idx > 0:
            tk.Label(frame, text=text[:idx], bg=bg, fg=P.text_primary,
                     font=TY.body()).pack(side="left")
        # match (highlighted)
        match_bg = _blend_hex(P.accent, bg, 0.75)
        tk.Label(frame, text=text[idx:idx+len(term)],
                 bg=match_bg, fg=P.accent,
                 font=(TY.family, TY.size_base, "bold")).pack(side="left")
        # after match
        after = text[idx+len(term):]
        if after:
            tk.Label(frame, text=after, bg=bg, fg=P.text_primary,
                     font=TY.body()).pack(side="left")

    def _edit(self, expense_row):
        if self._on_edit:
            self._on_edit(expense_row)
