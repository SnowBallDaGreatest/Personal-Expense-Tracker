"""
ui/widgets.py
─────────────
Reusable custom Tkinter widgets.
All styling comes from core/theme.py — never hardcode colours here.

Agile note: each widget is a self-contained class. Add new widgets
in future sprints without touching existing ones.
"""

import tkinter as tk
from tkinter import ttk
from typing import Callable, Optional
from core.theme import P, TY, SP


# ── helpers ───────────────────────────────────────────────────────────────────
def _rgb(hex_color: str) -> tuple:
    h = hex_color.lstrip("#")
    return tuple(int(h[i:i+2], 16) for i in (0, 2, 4))


def _blend(c1: str, c2: str, t: float) -> str:
    r1, g1, b1 = _rgb(c1)
    r2, g2, b2 = _rgb(c2)
    return "#{:02x}{:02x}{:02x}".format(
        int(r1 + (r2-r1)*t), int(g1 + (g2-g1)*t), int(b1 + (b2-b1)*t))


# ── MetricCard ────────────────────────────────────────────────────────────────
class MetricCard(tk.Frame):
    """Displays a single KPI: label + big number + optional delta."""

    def __init__(self, master, label: str, value: str = "—",
                 delta: str = "", delta_positive: bool = True, **kw):
        super().__init__(master, bg=P.bg_surface, padx=SP.md, pady=SP.md, **kw)

        tk.Label(self, text=label, bg=P.bg_surface, fg=P.text_secondary,
                 font=TY.label()).pack(anchor="w")

        self._val_lbl = tk.Label(self, text=value, bg=P.bg_surface,
                                 fg=P.text_primary, font=TY.h2())
        self._val_lbl.pack(anchor="w", pady=(2, 0))

        self._delta_lbl = tk.Label(self, text=delta, bg=P.bg_surface,
                                   fg=P.success if delta_positive else P.danger,
                                   font=TY.caption())
        self._delta_lbl.pack(anchor="w")

    def update(self, value: str, delta: str = "",
               delta_positive: bool = True) -> None:
        self._val_lbl.configure(text=value)
        self._delta_lbl.configure(
            text=delta,
            fg=P.success if delta_positive else P.danger)


# ── StyledButton ─────────────────────────────────────────────────────────────
class StyledButton(tk.Label):
    """Flat button built on Label (allows fine-grained styling)."""

    def __init__(self, master, text: str, command: Callable = None,
                 variant: str = "primary", width: int = 0, **kw):
        colours = {
            "primary":   (P.accent,      P.text_on_accent, P.accent_hover),
            "secondary": (P.bg_raised,   P.text_primary,   P.bg_hover),
            "danger":    ("#3D1A1A",   P.danger,         "#5A2020"),
            "ghost":     (P.bg_surface,  P.text_secondary, P.bg_raised),
        }
        self._bg, self._fg, self._hover_bg = colours.get(variant, colours["primary"])
        self._command = command

        cfg = dict(bg=self._bg, fg=self._fg, font=TY.body(),
                   padx=SP.md, pady=SP.sm, cursor="hand2",
                   relief="flat", anchor="center")
        if width:
            cfg["width"] = width
        super().__init__(master, text=text, **cfg, **kw)

        self.bind("<Enter>",    lambda _: self.configure(bg=self._hover_bg))
        self.bind("<Leave>",    lambda _: self.configure(bg=self._bg))
        self.bind("<Button-1>", self._on_click)

    def _on_click(self, _event):
        if self._command:
            self._command()

    def configure_command(self, command: Callable):
        self._command = command


# ── SectionHeader ─────────────────────────────────────────────────────────────
class SectionHeader(tk.Frame):
    """Labelled divider: title left, optional action button right."""

    def __init__(self, master, title: str, action_text: str = "",
                 action_cmd: Callable = None, **kw):
        super().__init__(master, bg=P.bg_primary, **kw)
        tk.Label(self, text=title, bg=P.bg_primary, fg=P.text_primary,
                 font=TY.h3()).pack(side="left")
        if action_text and action_cmd:
            StyledButton(self, action_text, action_cmd, variant="ghost"
                         ).pack(side="right")


# ── CategoryBadge ─────────────────────────────────────────────────────────────
class CategoryBadge(tk.Frame):
    """Coloured pill with icon + name."""

    def __init__(self, master, icon: str, name: str, color: str, **kw):
        tint = _blend(color, P.bg_surface, 0.82)   # 18% color, 82% surface
        super().__init__(master, bg=tint, padx=6, pady=2, **kw)
        tk.Label(self, text=f"{icon} {name}", bg=tint,
                 fg=color, font=TY.caption()).pack()


# ── ScrollableFrame ──────────────────────────────────────────────────────────
class ScrollableFrame(tk.Frame):
    """A Frame whose content scrolls vertically."""

    def __init__(self, master, bg: str = P.bg_primary, **kw):
        super().__init__(master, bg=bg, **kw)

        self._canvas = tk.Canvas(self, bg=bg, highlightthickness=0)
        sb = ttk.Scrollbar(self, orient="vertical",
                            command=self._canvas.yview)
        self._canvas.configure(yscrollcommand=sb.set)

        sb.pack(side="right", fill="y")
        self._canvas.pack(side="left", fill="both", expand=True)

        self.inner = tk.Frame(self._canvas, bg=bg)
        self._win_id = self._canvas.create_window(
            (0, 0), window=self.inner, anchor="nw")

        self.inner.bind("<Configure>", self._on_configure)
        self._canvas.bind("<Configure>", self._on_canvas_resize)
        self._canvas.bind("<MouseWheel>", self._on_mousewheel)
        self.inner.bind("<MouseWheel>", self._on_mousewheel)

    def _on_configure(self, _e):
        self._canvas.configure(scrollregion=self._canvas.bbox("all"))

    def _on_canvas_resize(self, e):
        self._canvas.itemconfig(self._win_id, width=e.width)

    def _on_mousewheel(self, e):
        self._canvas.yview_scroll(int(-1 * (e.delta / 120)), "units")

    def scroll_to_top(self):
        self._canvas.yview_moveto(0)


# ── LabeledEntry ─────────────────────────────────────────────────────────────
class LabeledEntry(tk.Frame):
    """Label + Entry stacked vertically, styled consistently."""

    def __init__(self, master, label: str, placeholder: str = "",
                 var: tk.StringVar = None, width: int = 20, **kw):
        super().__init__(master, bg=P.bg_surface, **kw)
        self.var = var or tk.StringVar()

        tk.Label(self, text=label, bg=P.bg_surface, fg=P.text_secondary,
                 font=TY.label()).pack(anchor="w")

        self._entry = tk.Entry(self, textvariable=self.var,
                               bg=P.bg_input, fg=P.text_primary,
                               insertbackground=P.accent,
                               relief="flat", font=TY.body(),
                               width=width,
                               highlightthickness=1,
                               highlightbackground=P.border,
                               highlightcolor=P.border_focus)
        self._entry.pack(fill="x", pady=(3, 0), ipady=6)

        if placeholder and not self.var.get():
            self._set_placeholder(placeholder)

    def _set_placeholder(self, text: str):
        self._entry.insert(0, text)
        self._entry.configure(fg=P.text_muted)
        self._entry.bind("<FocusIn>",  lambda _: self._clear_ph(text))
        self._entry.bind("<FocusOut>", lambda _: self._restore_ph(text))

    def _clear_ph(self, text):
        if self._entry.get() == text:
            self._entry.delete(0, "end")
            self._entry.configure(fg=P.text_primary)

    def _restore_ph(self, text):
        if not self._entry.get():
            self._entry.insert(0, text)
            self._entry.configure(fg=P.text_muted)

    def get(self) -> str:
        return self.var.get()

    def set(self, value: str):
        self.var.set(value)

    def focus(self):
        self._entry.focus_set()


# ── LabeledCombobox ───────────────────────────────────────────────────────────
class LabeledCombobox(tk.Frame):
    """Label + Combobox styled consistently."""

    def __init__(self, master, label: str, values: list,
                 var: tk.StringVar = None, width: int = 18, **kw):
        super().__init__(master, bg=P.bg_surface, **kw)
        self.var = var or tk.StringVar()

        tk.Label(self, text=label, bg=P.bg_surface, fg=P.text_secondary,
                 font=TY.label()).pack(anchor="w")

        style_name = f"Dark{id(self)}.TCombobox"
        s = ttk.Style()
        s.configure(style_name,
                    fieldbackground=P.bg_input, background=P.bg_raised,
                    foreground=P.text_primary, arrowcolor=P.accent,
                    borderwidth=1, relief="flat")

        self._cb = ttk.Combobox(self, textvariable=self.var,
                                 values=values, state="readonly",
                                 width=width, style=style_name)
        self._cb.pack(fill="x", pady=(3, 0))
        if values:
            self._cb.set(values[0])

    def get(self) -> str:
        return self.var.get()

    def set(self, value: str):
        self.var.set(value)

    def set_values(self, values: list):
        self._cb["values"] = values
        if values and self.var.get() not in values:
            self._cb.set(values[0])

    def bind_change(self, callback: Callable):
        self._cb.bind("<<ComboboxSelected>>", lambda _: callback())


# ── Toast notification ────────────────────────────────────────────────────────
class Toast(tk.Toplevel):
    """Temporary overlay notification (auto-dismisses)."""

    def __init__(self, master, message: str, kind: str = "success",
                 duration_ms: int = 2500):
        super().__init__(master)
        self.overrideredirect(True)
        self.attributes("-topmost", True)

        colours = {
            "success": (P.success, "#1A3D2A"),
            "error":   (P.danger,  "#3D1A1A"),
            "info":    (P.info,    "#1A2A3D"),
        }
        fg, bg = colours.get(kind, colours["success"])

        frame = tk.Frame(self, bg=bg, padx=SP.lg, pady=SP.md)
        frame.pack()
        tk.Label(frame, text=message, bg=bg, fg=fg,
                 font=TY.body()).pack()

        self._position(master)
        self.after(duration_ms, self.destroy)

    def _position(self, master):
        master.update_idletasks()
        x = master.winfo_x() + master.winfo_width()  // 2 - 150
        y = master.winfo_y() + master.winfo_height() - 80
        self.geometry(f"300x48+{x}+{y}")


# ── ProgressBar ───────────────────────────────────────────────────────────────
class BudgetBar(tk.Frame):
    """Horizontal budget-usage bar for the budget panel."""

    def __init__(self, master, label: str, spent: float, budget: float,
                 color: str = P.accent, **kw):
        super().__init__(master, bg=P.bg_surface, pady=4, **kw)

        pct = min(spent / budget, 1.0) if budget > 0 else 0
        over = spent > budget

        top = tk.Frame(self, bg=P.bg_surface)
        top.pack(fill="x")
        tk.Label(top, text=label, bg=P.bg_surface, fg=P.text_primary,
                 font=TY.body()).pack(side="left")
        tk.Label(top,
                 text=f"₹{spent:,.0f} / ₹{budget:,.0f}",
                 bg=P.bg_surface,
                 fg=P.danger if over else P.text_secondary,
                 font=TY.caption()).pack(side="right")

        track = tk.Frame(self, bg=P.bg_raised, height=6)
        track.pack(fill="x", pady=(3, 0))
        track.pack_propagate(False)

        fill_color = P.danger if over else color
        fill = tk.Frame(track, bg=fill_color, height=6)
        fill.place(relx=0, rely=0, relwidth=pct, relheight=1)
