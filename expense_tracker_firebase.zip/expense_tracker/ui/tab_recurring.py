"""
ui/tab_recurring.py
───────────────────
Sprint 3 — Recurring Expenses Manager.

Features:
  • Add recurring expenses (daily / weekly / monthly / yearly)
  • View all recurring entries with next-due date
  • Auto-post due entries on app launch with a review dialog
  • Enable / Disable / Delete entries
  • Manually trigger posting of a recurring entry
"""

import tkinter as tk
from tkinter import ttk, messagebox
from datetime import date, timedelta
from typing import Optional

from core.theme import P, TY, SP, PAYMENT_METHODS
from core import database as db
from ui.widgets import StyledButton, Toast, ScrollableFrame


def _fmt(v: float) -> str:
    from core.app_state import AppState
    return AppState.fmt_money(v)



FREQUENCIES = ["daily", "weekly", "monthly", "yearly"]

FREQ_LABELS = {
    "daily":   "Every day",
    "weekly":  "Every week",
    "monthly": "Every month",
    "yearly":  "Every year",
}


def _next_due_after(freq: str, day_of_month: int, from_date: date) -> date:
    """Calculate the next due date after posting."""
    if freq == "daily":
        return from_date + timedelta(days=1)
    if freq == "weekly":
        return from_date + timedelta(weeks=1)
    if freq == "yearly":
        try:
            return from_date.replace(year=from_date.year + 1)
        except ValueError:
            return from_date.replace(year=from_date.year + 1, day=28)
    # monthly
    m = from_date.month + 1
    y = from_date.year
    if m > 12:
        m = 1; y += 1
    d = min(day_of_month or from_date.day, 28)
    return date(y, m, d)


def _blend_hex(c1: str, c2: str, t: float) -> str:
    def rgb(h):
        h = h.lstrip("#")
        return int(h[0:2], 16), int(h[2:4], 16), int(h[4:6], 16)
    r1, g1, b1 = rgb(c1); r2, g2, b2 = rgb(c2)
    return "#{:02x}{:02x}{:02x}".format(
        int(r1+(r2-r1)*t), int(g1+(g2-g1)*t), int(b1+(b2-b1)*t))


class RecurringTab(tk.Frame):

    def __init__(self, master, on_posted: callable = None, **kw):
        super().__init__(master, bg=P.bg_primary, **kw)
        self._on_posted = on_posted
        self._categories: list = []
        self._build()

    # ── public ───────────────────────────────────────────────────────────────
    def refresh(self):
        self._load_categories()
        self._render_list()

    def check_and_post_due(self, silent: bool = False) -> int:
        """Post all due recurring entries. Returns count posted."""
        today_str = date.today().isoformat()
        due = db.get_due_recurring(today_str)
        if not due:
            return 0

        posted = 0
        for r in due:
            # add the expense
            db.add_expense(
                amount=r["amount"],
                description=r["description"],
                category_id=r["category_id"],
                expense_date=today_str,
                payment=r["payment"],
                notes=f"[Auto-recurring] {r['notes']}".strip(),
            )
            # advance next_due
            freq = r["frequency"]
            dom  = r["day_of_month"] or date.today().day
            nxt  = _next_due_after(freq, dom, date.today())
            db.update_recurring_next_due(r["id"], nxt.isoformat())
            posted += 1

        if posted and not silent:
            Toast(self.winfo_toplevel(),
                  f"{posted} recurring expense(s) posted automatically.",
                  "success", 3500)
        if posted and self._on_posted:
            self._on_posted()
        return posted

    # ── build ────────────────────────────────────────────────────────────────
    def _build(self):
        # header
        hdr = tk.Frame(self, bg=P.bg_primary, padx=SP.lg, pady=SP.md)
        hdr.pack(fill="x")
        tk.Label(hdr, text="🔁  Recurring Expenses", bg=P.bg_primary,
                 fg=P.text_primary, font=TY.h2()).pack(side="left")
        StyledButton(hdr, "Post Due Now", self._post_due_manual,
                     variant="secondary").pack(side="right")

        # ── add form card ─────────────────────────────────────────────────
        card = tk.Frame(self, bg=P.bg_surface,
                        highlightthickness=1, highlightbackground=P.border,
                        padx=SP.xl, pady=SP.lg)
        card.pack(fill="x", padx=SP.lg, pady=(0, SP.md))
        card.columnconfigure((0,1,2,3,4), weight=1)

        tk.Label(card, text="New Recurring Expense", bg=P.bg_surface,
                 fg=P.text_primary, font=TY.h3()).grid(
            row=0, column=0, columnspan=5, sticky="w", pady=(0, SP.sm))

        # labels row
        for col, lbl in enumerate(["Description *", "Amount (₹) *",
                                    "Category *", "Frequency", "Payment"]):
            tk.Label(card, text=lbl, bg=P.bg_surface, fg=P.text_secondary,
                     font=TY.label()).grid(row=1, column=col, sticky="w",
                                           pady=(0, 2), padx=(0, SP.sm))

        self._v_desc  = tk.StringVar()
        self._v_amt   = tk.StringVar()
        self._v_cat   = tk.StringVar()
        self._v_freq  = tk.StringVar(value="monthly")
        self._v_pay   = tk.StringVar(value="UPI")

        def entry(var, col, width=14):
            e = tk.Entry(card, textvariable=var, bg=P.bg_input,
                         fg=P.text_primary, insertbackground=P.accent,
                         relief="flat", font=TY.body(), width=width,
                         highlightthickness=1, highlightbackground=P.border,
                         highlightcolor=P.border_focus)
            e.grid(row=2, column=col, sticky="ew", padx=(0, SP.sm), ipady=5)
            return e

        def combo(var, values, col, width=13):
            sn = f"Rec{col}.TCombobox"
            s = ttk.Style(); s.configure(sn, fieldbackground=P.bg_input,
                background=P.bg_raised, foreground=P.text_primary,
                arrowcolor=P.accent)
            cb = ttk.Combobox(card, textvariable=var, values=values,
                              state="readonly", width=width, style=sn)
            cb.grid(row=2, column=col, sticky="ew", padx=(0,SP.sm))
            return cb

        entry(self._v_desc, 0, width=20)
        entry(self._v_amt,  1, width=10)
        self._cat_cb = combo(self._v_cat, [], 2)
        combo(self._v_freq, FREQUENCIES, 3, width=11)
        combo(self._v_pay,  PAYMENT_METHODS, 4, width=11)

        # day of month + start date row
        sub = tk.Frame(card, bg=P.bg_surface)
        sub.grid(row=3, column=0, columnspan=5, sticky="ew", pady=(SP.sm, 0))

        tk.Label(sub, text="Day of month (1-28):", bg=P.bg_surface,
                 fg=P.text_secondary, font=TY.label()).pack(side="left")
        self._v_dom = tk.StringVar(value=str(date.today().day))
        tk.Entry(sub, textvariable=self._v_dom, bg=P.bg_input,
                 fg=P.text_primary, insertbackground=P.accent, relief="flat",
                 font=TY.body(), width=4,
                 highlightthickness=1, highlightbackground=P.border,
                 highlightcolor=P.border_focus).pack(
            side="left", padx=(4, SP.md), ipady=4)

        tk.Label(sub, text="First due date:", bg=P.bg_surface,
                 fg=P.text_secondary, font=TY.label()).pack(side="left")
        self._v_start = tk.StringVar(value=date.today().isoformat())
        tk.Entry(sub, textvariable=self._v_start, bg=P.bg_input,
                 fg=P.text_primary, insertbackground=P.accent, relief="flat",
                 font=TY.body(), width=12,
                 highlightthickness=1, highlightbackground=P.border,
                 highlightcolor=P.border_focus).pack(
            side="left", padx=(4, SP.md), ipady=4)

        tk.Label(sub, text="Notes:", bg=P.bg_surface,
                 fg=P.text_secondary, font=TY.label()).pack(side="left")
        self._v_notes = tk.StringVar()
        tk.Entry(sub, textvariable=self._v_notes, bg=P.bg_input,
                 fg=P.text_primary, insertbackground=P.accent, relief="flat",
                 font=TY.body(), width=20,
                 highlightthickness=1, highlightbackground=P.border,
                 highlightcolor=P.border_focus).pack(
            side="left", padx=(4, SP.md), ipady=4)

        StyledButton(card, "➕  Add Recurring",
                     self._add_recurring, variant="primary").grid(
            row=4, column=0, columnspan=5, sticky="w", pady=(SP.md, 0))

        # ── list ──────────────────────────────────────────────────────────
        tk.Label(self, text="Active Recurring Expenses", bg=P.bg_primary,
                 fg=P.text_secondary, font=TY.label(),
                 padx=SP.lg).pack(anchor="w", pady=(0, SP.xs))

        self._scroll = ScrollableFrame(self, bg=P.bg_primary)
        self._scroll.pack(fill="both", expand=True)
        self._list_frame = self._scroll.inner

    # ── helpers ───────────────────────────────────────────────────────────────
    def _load_categories(self):
        self._categories = db.get_all_categories()
        names = [c["name"] for c in self._categories]
        self._cat_cb["values"] = names
        if names and not self._v_cat.get():
            self._v_cat.set(names[0])

    def _add_recurring(self):
        desc  = self._v_desc.get().strip()
        amt_s = self._v_amt.get().strip()
        cat   = self._v_cat.get()
        freq  = self._v_freq.get()
        pay   = self._v_pay.get()
        dom_s = self._v_dom.get().strip()
        start = self._v_start.get().strip()
        notes = self._v_notes.get().strip()

        errs = []
        if not desc: errs.append("Description required.")
        try:
            amt = float(amt_s); assert amt > 0
        except Exception:
            errs.append("Amount must be positive number.")
            amt = 0
        try:
            from datetime import datetime
            datetime.strptime(start, "%Y-%m-%d")
        except ValueError:
            errs.append("Start date must be YYYY-MM-DD.")
        try:
            dom = int(dom_s)
            assert 1 <= dom <= 28
        except Exception:
            errs.append("Day of month must be 1-28.")
            dom = 1

        if errs:
            messagebox.showerror("Validation", "\n".join(errs))
            return

        cat_id = next((c["id"] for c in self._categories
                       if c["name"] == cat), None)
        if not cat_id:
            messagebox.showerror("Error", "Invalid category.")
            return

        db.add_recurring(desc, amt, cat_id, pay, freq, dom, start, notes)
        self._v_desc.set(""); self._v_amt.set("")
        Toast(self.winfo_toplevel(), "Recurring expense added!", "success")
        self._render_list()

    def _render_list(self):
        for w in self._list_frame.winfo_children():
            w.destroy()

        rows = db.get_recurring()
        if not rows:
            tk.Label(self._list_frame,
                     text="No recurring expenses yet.\nAdd one above.",
                     bg=P.bg_primary, fg=P.text_muted,
                     font=TY.body(), pady=SP.xl,
                     justify="center").pack()
            return

        today = date.today().isoformat()

        for i, r in enumerate(rows):
            bg    = P.bg_surface if i % 2 == 0 else P.bg_raised
            due   = r["next_due"]
            overdue = due <= today and r["active"]

            row = tk.Frame(self._list_frame, bg=bg, padx=SP.md, pady=SP.sm)
            row.pack(fill="x", pady=1)

            # colour stripe
            stripe_col = (P.danger if overdue
                          else P.success if r["active"] else P.text_muted)
            tk.Frame(row, bg=stripe_col, width=4).pack(side="left",
                                                        fill="y", padx=(0,SP.sm))

            # icon + desc
            icon_lbl = r["cat_icon"] if r["active"] else "⏸"
            tk.Label(row, text=icon_lbl, bg=bg, fg=r["cat_color"],
                     font=(TY.family, TY.size_lg)).pack(side="left", padx=(0, SP.xs))

            info = tk.Frame(row, bg=bg)
            info.pack(side="left", fill="x", expand=True)
            tk.Label(info, text=r["description"], bg=bg, fg=P.text_primary,
                     font=(TY.family, TY.size_base, "bold")).pack(anchor="w")
            meta = (f"{_fmt(r['amount'])}  ·  "
                    f"{FREQ_LABELS.get(r['frequency'], r['frequency'])}  ·  "
                    f"{r['cat_name']}  ·  {r['payment']}")
            tk.Label(info, text=meta, bg=bg, fg=P.text_secondary,
                     font=TY.caption()).pack(anchor="w")

            # next due badge
            due_col = P.danger if overdue else P.teal
            due_bg  = _blend_hex(due_col, bg, 0.80)
            badge = tk.Frame(row, bg=due_bg, padx=6, pady=2)
            badge.pack(side="right", padx=SP.sm)
            due_txt = "OVERDUE" if overdue else f"Due: {due}"
            tk.Label(badge, text=due_txt, bg=due_bg, fg=due_col,
                     font=TY.caption()).pack()

            # action buttons
            if r["active"] and overdue:
                StyledButton(row, "Post Now",
                             lambda rid=r["id"], rdesc=r["description"],
                             ramt=r["amount"], rcat=r["category_id"],
                             rpay=r["payment"], rfreq=r["frequency"],
                             rdom=r["day_of_month"] or date.today().day,
                             rnotes=r["notes"]: self._post_one(
                                 rid, rdesc, ramt, rcat, rpay, rfreq, rdom, rnotes),
                             variant="primary").pack(side="right", padx=2)

            StyledButton(row,
                         "Pause" if r["active"] else "Resume",
                         lambda rid=r["id"]: self._toggle(rid),
                         variant="ghost").pack(side="right", padx=2)
            StyledButton(row, "Del",
                         lambda rid=r["id"], rdesc=r["description"]: self._delete(rid, rdesc),
                         variant="danger").pack(side="right", padx=2)

    def _post_one(self, rec_id, desc, amount, cat_id, payment,
                  freq, dom, notes):
        today_str = date.today().isoformat()
        db.add_expense(amount, desc, cat_id, today_str, payment,
                       f"[Recurring] {notes}".strip())
        nxt = _next_due_after(freq, dom, date.today())
        db.update_recurring_next_due(rec_id, nxt.isoformat())
        Toast(self.winfo_toplevel(), f"Posted: {desc}", "success")
        self._render_list()
        if self._on_posted:
            self._on_posted()

    def _post_due_manual(self):
        n = self.check_and_post_due(silent=False)
        if n == 0:
            Toast(self.winfo_toplevel(), "No recurring expenses are due today.", "info")
        self._render_list()

    def _toggle(self, rec_id: int):
        db.toggle_recurring(rec_id)
        self._render_list()

    def _delete(self, rec_id: int, desc: str):
        if messagebox.askyesno("Delete", f'Remove recurring "{desc}"?'):
            db.delete_recurring(rec_id)
            self._render_list()