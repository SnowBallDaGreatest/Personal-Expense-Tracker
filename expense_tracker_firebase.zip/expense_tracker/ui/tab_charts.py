"""
ui/tab_charts.py
────────────────
Charts panel: 4 publication-quality Matplotlib charts.

Charts:
  1. Category breakdown – doughnut
  2. Monthly totals     – bar chart (6 months)
  3. Stacked category   – stacked bar by month
  4. Cumulative spend   – area chart for chosen month

Agile note: Each chart method is independent. Swap, add, or remove
charts without touching other panels.
"""

import tkinter as tk
from tkinter import ttk
from datetime import date, datetime
from collections import defaultdict

import matplotlib
matplotlib.use("TkAgg")
import matplotlib.pyplot as plt
import matplotlib.ticker as ticker
from matplotlib.figure import Figure
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
import matplotlib.patches as mpatches

from core.theme import P, TY, SP
from core import database as db
from ui.widgets import ScrollableFrame


def _fmt(v: float) -> str:
    from core.app_state import AppState
    return AppState.fmt_money(v)


def _apply_dark_axes(ax, fig=None):
    """Apply dark theme to a single axes."""
    ax.set_facecolor(P.bg_surface)
    if fig:
        fig.set_facecolor(P.bg_primary)
    ax.tick_params(colors=P.text_secondary, labelsize=8)
    for sp in ax.spines.values():
        sp.set_color(P.border)
    ax.xaxis.label.set_color(P.text_secondary)
    ax.yaxis.label.set_color(P.text_secondary)
    ax.title.set_color(P.text_secondary)


class ChartsTab(tk.Frame):

    def __init__(self, master, **kw):
        super().__init__(master, bg=P.bg_primary, **kw)
        self._build()

    # ── public ──────────────────────────────────────────────────────────────
    def refresh(self):
        self._load_months()
        month = self._v_month.get()
        if month:
            self._render_all(month)

    # ── build ────────────────────────────────────────────────────────────────
    def _build(self):
        # header + month selector
        hdr = tk.Frame(self, bg=P.bg_primary, padx=SP.lg, pady=SP.md)
        hdr.pack(fill="x")
        tk.Label(hdr, text="📊  Analytics & Charts", bg=P.bg_primary,
                 fg=P.text_primary, font=TY.h2()).pack(side="left")

        ctrl = tk.Frame(hdr, bg=P.bg_primary)
        ctrl.pack(side="right")
        tk.Label(ctrl, text="Month:", bg=P.bg_primary,
                 fg=P.text_secondary, font=TY.label()).pack(side="left")
        self._v_month = tk.StringVar()
        self._month_cb = tk.OptionMenu(ctrl, self._v_month, "")
        self._month_cb.configure(
            bg=P.bg_raised, fg=P.text_primary, font=TY.body(),
            activebackground=P.bg_hover, activeforeground=P.text_primary,
            highlightthickness=0, relief="flat", cursor="hand2")
        self._month_cb["menu"].configure(
            bg=P.bg_raised, fg=P.text_primary, font=TY.body())
        self._month_cb.pack(side="left", padx=(4, 0))
        self._v_month.trace_add("write", lambda *_: self._render_all(
            self._v_month.get()))

        # scrollable body
        scroll = ScrollableFrame(self, bg=P.bg_primary)
        scroll.pack(fill="both", expand=True)
        body = scroll.inner

        # ── row 1: doughnut + bar ──────────────────────────────────────────
        row1 = tk.Frame(body, bg=P.bg_primary, padx=SP.lg, pady=SP.sm)
        row1.pack(fill="x")
        row1.columnconfigure(0, weight=1)
        row1.columnconfigure(1, weight=1)

        # doughnut card
        dc = self._card(row1, "Category Breakdown")
        dc.grid(row=0, column=0, sticky="nsew", padx=(0, SP.sm))
        self._fig_donut = Figure(figsize=(4.2, 3.4), dpi=90,
                                  facecolor=P.bg_surface)
        self._ax_donut  = self._fig_donut.add_subplot(111)
        self._cv_donut  = FigureCanvasTkAgg(self._fig_donut, dc)
        self._cv_donut.get_tk_widget().pack(fill="both", expand=True)

        # monthly bar card
        bc = self._card(row1, "Monthly Totals (last 6 months)")
        bc.grid(row=0, column=1, sticky="nsew")
        self._fig_bar = Figure(figsize=(4.2, 3.4), dpi=90,
                                facecolor=P.bg_surface)
        self._ax_bar  = self._fig_bar.add_subplot(111)
        self._cv_bar  = FigureCanvasTkAgg(self._fig_bar, bc)
        self._cv_bar.get_tk_widget().pack(fill="both", expand=True)

        # ── row 2: stacked bar ────────────────────────────────────────────
        row2 = tk.Frame(body, bg=P.bg_primary, padx=SP.lg, pady=SP.sm)
        row2.pack(fill="x")
        sc = self._card(row2, "Category × Month Stacked")
        sc.pack(fill="x")
        self._fig_stack = Figure(figsize=(9, 3.2), dpi=90,
                                  facecolor=P.bg_surface)
        self._ax_stack  = self._fig_stack.add_subplot(111)
        self._cv_stack  = FigureCanvasTkAgg(self._fig_stack, sc)
        self._cv_stack.get_tk_widget().pack(fill="x")

        # ── row 3: cumulative area chart ──────────────────────────────────
        row3 = tk.Frame(body, bg=P.bg_primary, padx=SP.lg)
        row3.pack(fill="x", pady=(SP.sm, SP.lg))
        ac = self._card(row3, "Cumulative Spending (selected month)")
        ac.pack(fill="x")
        self._fig_area = Figure(figsize=(9, 2.8), dpi=90,
                                 facecolor=P.bg_surface)
        self._ax_area  = self._fig_area.add_subplot(111)
        self._cv_area  = FigureCanvasTkAgg(self._fig_area, ac)
        self._cv_area.get_tk_widget().pack(fill="x")

    def _card(self, parent, title: str) -> tk.Frame:
        outer = tk.Frame(parent, bg=P.bg_surface,
                         highlightthickness=1,
                         highlightbackground=P.border,
                         padx=4, pady=4)
        tk.Label(outer, text=title, bg=P.bg_surface, fg=P.text_secondary,
                 font=TY.label()).pack(anchor="w", padx=SP.sm)
        return outer

    # ── load months ──────────────────────────────────────────────────────────
    def _load_months(self):
        months = db.available_months()
        cur = date.today().strftime("%Y-%m")
        if cur not in months:
            months.insert(0, cur)

        menu = self._month_cb["menu"]
        menu.delete(0, "end")
        for m in months:
            menu.add_command(label=m,
                             command=lambda v=m: self._v_month.set(v))
        cur_val = self._v_month.get()
        if cur_val not in months:
            self._v_month.set(months[0] if months else cur)

    # ── render helpers ────────────────────────────────────────────────────────
    def _render_all(self, month: str):
        if not month:
            return
        self._render_donut(month)
        self._render_bar()
        self._render_stacked()
        self._render_area(month)

    def _render_donut(self, month: str):
        rows = db.monthly_by_category(month)
        ax = self._ax_donut
        ax.clear()
        if not rows:
            ax.text(0.5, 0.5, "No data", ha="center", va="center",
                    color=P.text_muted, transform=ax.transAxes)
        else:
            vals   = [r["total"] for r in rows]
            colors = [r["color"] for r in rows]
            names  = [r["name"]  for r in rows]
            total  = sum(vals)

            wedges, _ = ax.pie(
                vals, colors=colors, startangle=90,
                wedgeprops={"width": 0.55,
                            "edgecolor": P.bg_surface, "linewidth": 2.5})
            ax.text(0, 0, _fmt(total), ha="center", va="center",
                    color=P.text_primary, fontsize=11, fontweight="bold")

            patches = [mpatches.Patch(color=colors[i],
                                      label=f"{names[i]}: {vals[i]/total*100:.1f}%")
                       for i in range(len(names))]
            ax.legend(handles=patches, loc="lower center",
                      bbox_to_anchor=(0.5, -0.22),
                      ncol=2, fontsize=6.5, frameon=False,
                      labelcolor=P.text_secondary)

        ax.set_facecolor(P.bg_surface)
        self._fig_donut.set_facecolor(P.bg_surface)
        self._fig_donut.tight_layout(pad=0.5)
        self._cv_donut.draw()

    def _render_bar(self):
        rows = db.last_n_months_totals(6)
        ax = self._ax_bar
        ax.clear()
        if not rows:
            ax.text(0.5, 0.5, "No data", ha="center", va="center",
                    color=P.text_muted, transform=ax.transAxes)
        else:
            labels = [datetime.strptime(r["month"], "%Y-%m").strftime("%b '%y")
                      for r in rows]
            vals   = [r["total"] for r in rows]
            colors = [P.accent if i == len(vals) - 1 else P.teal
                      for i in range(len(vals))]

            bars = ax.bar(labels, vals, color=colors, width=0.55,
                          edgecolor=P.bg_surface, linewidth=0.5)
            for bar, v in zip(bars, vals):
                ax.text(bar.get_x() + bar.get_width() / 2,
                        bar.get_height() + max(vals) * 0.01,
                        _fmt(v), ha="center", color=P.text_secondary,
                        fontsize=7)

            ax.yaxis.set_major_formatter(
                ticker.FuncFormatter(lambda v, _: _fmt(v)))
            _apply_dark_axes(ax)
            for sp in ["top", "right"]:
                ax.spines[sp].set_visible(False)

        self._fig_bar.set_facecolor(P.bg_surface)
        self._fig_bar.tight_layout(pad=0.5)
        self._cv_bar.draw()

    def _render_stacked(self):
        rows6  = db.last_n_months_totals(6)
        months = [r["month"] for r in rows6]
        if not months:
            return

        cats  = db.get_all_categories()
        exps  = db.get_expenses()
        by_cm = defaultdict(lambda: defaultdict(float))
        for e in exps:
            m = e["expense_date"][:7]
            if m in months:
                by_cm[m][e["cat_name"]] += e["amount"]

        ax = self._ax_stack
        ax.clear()
        m_labels = [datetime.strptime(m, "%Y-%m").strftime("%b '%y")
                    for m in months]
        bottom = [0.0] * len(months)

        for cat in cats:
            vals = [by_cm[m].get(cat["name"], 0) for m in months]
            if any(v > 0 for v in vals):
                ax.bar(m_labels, vals, bottom=bottom,
                       color=cat["color"], label=cat["name"],
                       width=0.6, edgecolor=P.bg_surface, linewidth=0.3)
                bottom = [b + v for b, v in zip(bottom, vals)]

        ax.yaxis.set_major_formatter(
            ticker.FuncFormatter(lambda v, _: _fmt(v)))
        ax.legend(loc="upper left", ncol=4, fontsize=6.5,
                   frameon=False, labelcolor=P.text_secondary)
        _apply_dark_axes(ax)
        for sp in ["top", "right"]:
            ax.spines[sp].set_visible(False)

        self._fig_stack.set_facecolor(P.bg_surface)
        self._fig_stack.tight_layout(pad=0.5)
        self._cv_stack.draw()

    def _render_area(self, month: str):
        rows = db.daily_totals_for_month(month)
        ax = self._ax_area
        ax.clear()
        if not rows:
            ax.text(0.5, 0.5, "No data for this month", ha="center",
                    va="center", color=P.text_muted, transform=ax.transAxes)
        else:
            days    = [r["day"][-2:] for r in rows]
            totals  = [r["total"]    for r in rows]
            cum     = []
            running = 0.0
            for t in totals:
                running += t
                cum.append(running)

            x = range(len(days))
            ax.plot(list(x), cum, color=P.accent, linewidth=2,
                    marker="o", markersize=4, markerfacecolor=P.teal)
            ax.fill_between(list(x), cum, alpha=0.15, color=P.accent)
            ax.set_xticks(list(x))
            ax.set_xticklabels(days, fontsize=7, color=P.text_secondary)
            ax.yaxis.set_major_formatter(
                ticker.FuncFormatter(lambda v, _: _fmt(v)))
            _apply_dark_axes(ax)
            for sp in ["top", "right"]:
                ax.spines[sp].set_visible(False)

        self._fig_area.set_facecolor(P.bg_surface)
        self._fig_area.tight_layout(pad=0.5)
        self._cv_area.draw()
