"""
main.py  —  Personal Expense Tracker  (Sprint 4)
─────────────────────────────────────────────────
Sprint 4 changes
────────────────
  • Firebase Realtime DB (with SQLite offline fallback)
  • Live dark/light theme toggle   — full widget recolor, no restart
  • Live currency change           — all money labels update instantly
  • AppState event bus wires everything together

Run
───
  pip install matplotlib reportlab requests
  python main.py

Firebase setup
──────────────
  Create firebase_config.json next to main.py:
  {
    "database_url": "https://YOUR-APP-default-rtdb.firebaseio.com",
    "api_key": "YOUR_WEB_API_KEY",
    "auth_email": "user@example.com",
    "auth_password": "yourpassword"
  }
  Without this file the app runs on local SQLite automatically.
"""

import tkinter as tk
from tkinter import ttk, messagebox
from datetime import date

# ── Init AppState FIRST (before any theme import) ────────────────────────────
from core.app_state import AppState, apply_theme_to_widget
from ui.tab_settings import load_settings

# Apply persisted theme before building any widgets
_saved = load_settings()
AppState.set_theme(_saved.get("theme", "dark"))
AppState.set_currency(_saved.get("currency", "₹"))

# ── Now safe to import theme + UI ─────────────────────────────────────────────
from core.theme import P, TY, SP

# Single database module — handles Firebase + SQLite fallback internally
import core.database as db
db.init_db()
db.init_recurring_table()

from ui.tab_dashboard    import DashboardTab
from ui.tab_add_expense  import AddExpenseTab
from ui.tab_history      import HistoryTab
from ui.tab_charts       import ChartsTab
from ui.tab_budget       import BudgetTab
from ui.tab_categories   import CategoriesTab
from ui.tab_export       import ExportTab
from ui.tab_settings     import SettingsTab
from ui.tab_recurring    import RecurringTab
from ui.tab_summary      import SummaryTab
from ui.tab_search       import SearchTab
from ui.tab_import       import ImportTab


class AppShell(tk.Tk):
    APP_TITLE = "💸 Personal Expense Tracker"
    WIN_SIZE  = "1180x760"
    MIN_SIZE  = (920, 600)

    def __init__(self):
        super().__init__()
        self.title(self.APP_TITLE)
        self.geometry(self.WIN_SIZE)
        self.minsize(*self.MIN_SIZE)
        self.configure(bg=P.bg_primary)

        self._configure_ttk_style()
        self._build_tabs()
        self._wire_callbacks()
        self._build_statusbar()

        self.tab_dashboard.refresh()
        self.after(800, self._auto_post_recurring)
        self.protocol("WM_DELETE_WINDOW", self.destroy)

    # ── ttk style ─────────────────────────────────────────────────────────────
    def _configure_ttk_style(self, theme: str = None):
        s = ttk.Style(self)
        s.theme_use("clam")
        s.configure("App.TNotebook",
                    background=P.bg_surface, borderwidth=0,
                    tabmargins=[0, 0, 0, 0])
        s.configure("App.TNotebook.Tab",
                    background=P.bg_raised, foreground=P.text_secondary,
                    font=TY.body(), padding=[SP.md, SP.sm], borderwidth=0)
        s.map("App.TNotebook.Tab",
              background=[("selected", P.bg_primary),
                          ("active",   P.bg_hover)],
              foreground=[("selected", P.accent),
                          ("active",   P.text_primary)])
        s.configure("Vertical.TScrollbar",
                    background=P.bg_raised, troughcolor=P.bg_surface,
                    arrowcolor=P.text_muted, borderwidth=0)
        s.configure("Horizontal.TScrollbar",
                    background=P.bg_raised, troughcolor=P.bg_surface,
                    arrowcolor=P.text_muted, borderwidth=0)
        s.configure("Treeview",
                    background=P.bg_surface, fieldbackground=P.bg_surface,
                    foreground=P.text_primary, rowheight=28, borderwidth=0)
        s.configure("Treeview.Heading",
                    background=P.bg_raised, foreground=P.text_secondary,
                    borderwidth=0)
        s.map("Treeview",
              background=[("selected", P.bg_hover)],
              foreground=[("selected", P.accent)])

    # ── tabs ──────────────────────────────────────────────────────────────────
    def _build_tabs(self):
        self.nb = ttk.Notebook(self, style="App.TNotebook")
        self.nb.pack(fill="both", expand=True)

        self.tab_dashboard  = DashboardTab(self.nb,
                                           on_add_expense=self._go_to_add)
        self.tab_add        = AddExpenseTab(self.nb)
        self.tab_history    = HistoryTab(self.nb)
        self.tab_charts     = ChartsTab(self.nb)
        self.tab_summary    = SummaryTab(self.nb)
        self.tab_budget     = BudgetTab(self.nb)
        self.tab_recurring  = RecurringTab(self.nb)
        self.tab_search     = SearchTab(self.nb)
        self.tab_categories = CategoriesTab(self.nb)
        self.tab_export     = ExportTab(self.nb)
        self.tab_import     = ImportTab(self.nb)
        self.tab_settings   = SettingsTab(
            self.nb,
            on_theme_change=self._on_theme_change,
            on_currency_change=self._on_currency_change)

        self.nb.add(self.tab_dashboard,  text="  Dashboard  ")
        self.nb.add(self.tab_add,        text="  + Add  ")
        self.nb.add(self.tab_history,    text="  History  ")
        self.nb.add(self.tab_charts,     text="  Charts  ")
        self.nb.add(self.tab_summary,    text="  Summary  ")
        self.nb.add(self.tab_budget,     text="  Budget  ")
        self.nb.add(self.tab_recurring,  text="  Recurring  ")
        self.nb.add(self.tab_search,     text="  Search  ")
        self.nb.add(self.tab_categories, text="  Categories  ")
        self.nb.add(self.tab_export,     text="  Export  ")
        self.nb.add(self.tab_import,     text="  Import  ")
        self.nb.add(self.tab_settings,   text="  Settings  ")

        self.nb.bind("<<NotebookTabChanged>>", self._on_tab_change)

    # ── status bar ────────────────────────────────────────────────────────────
    def _build_statusbar(self):
        bar = tk.Frame(self, bg=P.bg_surface, height=22)
        bar.pack(fill="x", side="bottom")
        bar.pack_propagate(False)

        # DB mode indicator
        try:
            online = db.is_online()
            db_lbl = "🔥 Firebase" if online else "💽 SQLite"
            db_col = P.success if online else P.warning
        except Exception:
            db_lbl = "💽 SQLite"; db_col = P.warning

        self._db_indicator = tk.Label(bar, text=f"  {db_lbl}",
                                       bg=P.bg_surface, fg=db_col,
                                       font=TY.caption())
        self._db_indicator.pack(side="left", padx=SP.sm)

        tk.Label(bar, text="Personal Expense Tracker · Sprint 4",
                 bg=P.bg_surface, fg=P.text_muted,
                 font=TY.caption()).pack(side="left", padx=SP.sm)

        self._status_rhs = tk.Label(bar, text="",
                                     bg=P.bg_surface, fg=P.text_muted,
                                     font=TY.caption())
        self._status_rhs.pack(side="right", padx=SP.sm)
        self._update_statusbar()

    def _update_statusbar(self):
        try:
            months = db.available_months()
            total  = len(db.get_expenses())
            cats   = len(db.get_all_categories())
            self._status_rhs.configure(
                text=f"{total} transactions · {cats} categories · "
                     f"{len(months)} months · {date.today().strftime('%d %b %Y')}  ")
        except Exception:
            pass

    # ── callbacks ─────────────────────────────────────────────────────────────
    def _wire_callbacks(self):
        self.tab_add._on_saved          = self._on_expense_saved
        self.tab_history._on_edit       = self._on_edit_expense
        self.tab_categories._on_changed  = self._on_categories_changed
        self.tab_recurring._on_posted    = self._on_expense_saved
        self.tab_import._on_imported     = self._on_expense_saved
        self.tab_search._on_edit         = self._on_edit_expense

    def _go_to_add(self):
        self.nb.select(self.tab_add)

    def _on_expense_saved(self):
        self.tab_dashboard.refresh()
        self.tab_history.refresh()
        self.tab_charts.refresh()
        self.tab_budget.refresh()
        self.tab_export.refresh()
        self._update_statusbar()

    def _on_edit_expense(self, row):
        self.tab_add.load_for_edit(row)
        self.nb.select(self.tab_add)

    def _on_categories_changed(self):
        for tab in [self.tab_add, self.tab_history, self.tab_budget,
                    self.tab_export, self.tab_recurring]:
            tab.refresh()

    def _on_tab_change(self, _event):
        widget = self.nametowidget(self.nb.select())
        refresh_map = {
            self.tab_dashboard:  self.tab_dashboard.refresh,
            self.tab_add:        self.tab_add.refresh,
            self.tab_history:    self.tab_history.refresh,
            self.tab_charts:     self.tab_charts.refresh,
            self.tab_budget:     self.tab_budget.refresh,
            self.tab_categories: self.tab_categories.refresh,
            self.tab_export:     self.tab_export.refresh,
            self.tab_settings:   self.tab_settings.refresh,
            self.tab_recurring:  self.tab_recurring.refresh,
            self.tab_summary:    self.tab_summary.refresh,
            self.tab_search:     self.tab_search.refresh,
            self.tab_import:     self.tab_import.refresh,
        }
        if widget in refresh_map:
            refresh_map[widget]()

    def _auto_post_recurring(self):
        try:
            self.tab_recurring.check_and_post_due(silent=False)
        except Exception:
            pass

    # ── LIVE THEME CHANGE ─────────────────────────────────────────────────────
    def _on_theme_change(self, new_theme: str):
        """
        Called after AppState.set_theme() fired.
        1. Recolor the root window background
        2. Re-apply ttk notebook/scrollbar styles
        3. Redraw the current tab's charts
        """
        # Root window bg
        self.configure(bg=P.bg_primary)

        # Re-apply ttk styles with new colours
        self._configure_ttk_style(new_theme)

        # Refresh the currently-visible tab (redraws charts with new bg)
        try:
            widget = self.nametowidget(self.nb.select())
            if hasattr(widget, "refresh"):
                widget.refresh()
        except Exception:
            pass

        # Update status bar colours explicitly
        try:
            self._db_indicator.configure(
                bg=P.bg_surface, fg=P.success if "Firebase" in self._db_indicator.cget("text") else P.warning)
            self._status_rhs.configure(bg=P.bg_surface, fg=P.text_muted)
        except Exception:
            pass

    # ── LIVE CURRENCY CHANGE ──────────────────────────────────────────────────
    def _on_currency_change(self, sym: str):
        """
        Refresh all tabs that display monetary values.
        AppState.fmt_money() is already updated by AppState.set_currency().
        """
        for tab in [self.tab_dashboard, self.tab_history,
                    self.tab_budget, self.tab_summary,
                    self.tab_export, self.tab_charts]:
            try:
                tab.refresh()
            except Exception:
                pass


# ── Seed (first run only) ─────────────────────────────────────────────────────
def _maybe_seed():
    import random
    from datetime import timedelta

    cats = db.get_all_categories()
    if not cats or db.available_months():
        return

    descs = {
        "Food & Dining":  ["Lunch canteen","Chai samosa","Biryani","Breakfast"],
        "Transport":      ["Auto-rickshaw","Metro pass","Ola ride","Bus"],
        "Groceries":      ["Big Basket","Kirana shop","Vegetables","Fruits"],
        "Entertainment":  ["Movie tickets","Spotify","Netflix","Cricket"],
        "Utilities":      ["Electricity","Jio recharge","Water bill","Gas"],
        "Health":         ["Pharmacy","Gym fee","Doctor visit","Vitamins"],
        "Housing / Rent": ["Rent","Maintenance","Society charges"],
        "Shopping":       ["Clothes","Footwear","Amazon","Stationery"],
        "Dining Out":     ["Restaurant","Pizza","Cafe","Burger"],
        "Investments":    ["SIP","RD deposit","Gold savings"],
    }
    today = date.today()
    for days_ago in range(90, -1, -1):
        day = today - timedelta(days=days_ago)
        for _ in range(random.randint(0, 4)):
            cat  = random.choice(cats)
            pool = descs.get(cat["name"], ["Expense"])
            db.add_expense(
                amount=round(random.uniform(30, 3500), 2),
                description=random.choice(pool),
                category_id=cat["id"],
                expense_date=day.isoformat(),
                payment=random.choice(["UPI","Cash","Card","Net Banking"]),
                notes="",
            )


# ── Entry point ───────────────────────────────────────────────────────────────
if __name__ == "__main__":
    _maybe_seed()
    app = AppShell()
    app.mainloop()
